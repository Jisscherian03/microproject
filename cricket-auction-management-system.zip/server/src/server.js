const http = require('http');
const dotenv = require('dotenv');
const path = require('path');
const { Server } = require('socket.io');

// Load environment variables before anything else
dotenv.config({ path: path.join(__dirname, '../.env') });

const app = require('./app');
const { testConnection } = require('./config/db');
const { initSocket } = require('./sockets/auctionSocket');

const PORT = parseInt(process.env.PORT, 10) || 5000;
const server = http.createServer(app);

// Setup Socket.IO
const io = new Server(server, {
  cors: {
    origin: [
      process.env.CLIENT_URL || 'http://localhost:5173',
      'http://localhost:5173',
      'http://127.0.0.1:5173'
    ],
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// Initialize socket handlers
initSocket(io);

// Start server
server.listen(PORT, async () => {
  console.log('====================================================');
  console.log(`🏏 Cricket Auction Management Server Running`);
  console.log(`📡 URL: http://localhost:${PORT}`);
  console.log(`🏥 Health: http://localhost:${PORT}/api/health`);
  console.log(`⚡ Socket.IO Ready on port ${PORT}`);
  console.log('====================================================');

  // Test database connection
  await testConnection();
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received. Closing HTTP server...');
  server.close(() => {
    console.log('HTTP server closed.');
    process.exit(0);
  });
});
