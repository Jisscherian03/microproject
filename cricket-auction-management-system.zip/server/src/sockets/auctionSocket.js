const jwt = require('jsonwebtoken');
const { JWT_SECRET } = require('../middleware/auth');

let ioInstance = null;

function initSocket(io) {
  ioInstance = io;

  // Optional socket authentication
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.headers?.authorization?.split(' ')[1];
    if (token) {
      try {
        const decoded = jwt.verify(token, JWT_SECRET);
        socket.user = decoded;
      } catch (err) {
        // Allow anonymous connection for public auction viewers, but tag unauthenticated
        socket.user = null;
      }
    }
    next();
  });

  io.on('connection', (socket) => {
    console.log(`[Socket.IO] Client connected: ${socket.id} (User: ${socket.user ? socket.user.username : 'Guest'})`);

    // Join room for auction live feed
    socket.join('auction-room');

    socket.on('join:team', (teamId) => {
      if (teamId) {
        socket.join(`team-${teamId}`);
      }
    });

    socket.on('disconnect', () => {
      console.log(`[Socket.IO] Client disconnected: ${socket.id}`);
    });
  });

  return io;
}

function getIO() {
  return ioInstance;
}

function emitAuctionEvent(eventName, payload) {
  if (ioInstance) {
    ioInstance.to('auction-room').emit(eventName, payload);
    // Also broadcast general dashboard stats update trigger
    ioInstance.emit('dashboard:refresh');
  }
}

module.exports = {
  initSocket,
  getIO,
  emitAuctionEvent
};
