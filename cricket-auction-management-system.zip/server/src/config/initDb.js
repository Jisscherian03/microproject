const mysql = require('mysql2/promise');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config({ path: path.join(__dirname, '../../.env') });

async function initDatabase() {
  console.log('[InitDB] Initializing Cricket Auction Management Database...');

  const host = process.env.DB_HOST || '127.0.0.1';
  const port = parseInt(process.env.DB_PORT, 10) || 3306;
  const user = process.env.DB_USER || 'root';
  const password = process.env.DB_PASSWORD || '';
  const dbName = process.env.DB_NAME || 'cricket_auction_db';

  let connection;
  try {
    // 1. Connect without selecting database
    connection = await mysql.createConnection({ host, port, user, password, multipleStatements: true });
    console.log(`[InitDB] Connected to MySQL server at ${host}:${port}`);

    // 2. Create database if it doesn't exist
    await connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`);
    console.log(`[InitDB] Database \`${dbName}\` ensured.`);

    await connection.query(`USE \`${dbName}\`;`);

    // 3. Read schema.sql
    const schemaPath = path.join(__dirname, '../../../database/schema.sql');
    if (!fs.existsSync(schemaPath)) {
      throw new Error(`schema.sql not found at ${schemaPath}`);
    }

    const schemaSql = fs.readFileSync(schemaPath, 'utf8');
    await connection.query(schemaSql);
    console.log('[InitDB] Schema created successfully!');

    // 4. Now run seed
    const seedScript = require('./seed');
    await seedScript.runSeed(connection);

    console.log('[InitDB] Database setup and seeding complete!');
  } catch (err) {
    console.error('[InitDB Error]', err.message);
    process.exit(1);
  } finally {
    if (connection) await connection.end();
  }
}

if (require.main === module) {
  initDatabase();
}

module.exports = { initDatabase };
