const mysql = require('mysql2/promise');
const dotenv = require('dotenv');
const path = require('path');

dotenv.config({ path: path.join(__dirname, '../../.env') });

let pool = null;
let isConnected = false;

function createDbPool() {
  if (pool) return pool;

  pool = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    port: parseInt(process.env.DB_PORT, 10) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'cricket_auction_db',
    waitForConnections: true,
    connectionLimit: parseInt(process.env.DB_CONNECTION_LIMIT, 10) || 10,
    queueLimit: 0,
    decimalNumbers: true, // Parse MySQL DECIMAL as JavaScript numbers/strings accurately
    timezone: '+05:30' // Standard Indian Standard Time for auction
  });

  return pool;
}

async function testConnection() {
  try {
    const p = getPool();
    const conn = await p.getConnection();
    await conn.ping();
    conn.release();
    isConnected = true;
    console.log(`[Database] Successfully connected to MySQL (${process.env.DB_NAME || 'cricket_auction_db'})`);
    return true;
  } catch (err) {
    isConnected = false;
    console.warn(`[Database Warning] Unable to connect to MySQL database at ${process.env.DB_HOST}:${process.env.DB_PORT}. Error: ${err.message}`);
    console.warn(`[Database Note] Ensure MySQL is running and execute 'database/schema.sql' and 'database/seed.sql' or 'npm run db:init'.`);
    return false;
  }
}

function getPool() {
  if (!pool) {
    createDbPool();
  }
  return pool;
}

async function query(sql, params = []) {
  const p = getPool();
  const [rows] = await p.execute(sql, params);
  return rows;
}

async function getConnection() {
  const p = getPool();
  return await p.getConnection();
}

/**
 * Execute callback within a database transaction with automatic rollback on error
 * @param {Function} callback (connection) => Promise<any>
 */
async function withTransaction(callback) {
  const conn = await getConnection();
  try {
    await conn.beginTransaction();
    const result = await callback(conn);
    await conn.commit();
    return result;
  } catch (error) {
    await conn.rollback();
    throw error;
  } finally {
    conn.release();
  }
}

module.exports = {
  createDbPool,
  getPool,
  getConnection,
  query,
  withTransaction,
  testConnection,
  getIsConnected: () => isConnected
};
