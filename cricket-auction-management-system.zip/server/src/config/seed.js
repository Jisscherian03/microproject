const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config({ path: path.join(__dirname, '../../.env') });

async function runSeed(existingConn = null) {
  let connection = existingConn;
  let closeOnFinish = false;

  try {
    if (!connection) {
      connection = await mysql.createConnection({
        host: process.env.DB_HOST || '127.0.0.1',
        port: parseInt(process.env.DB_PORT, 10) || 3306,
        user: process.env.DB_USER || 'root',
        password: process.env.DB_PASSWORD || '',
        database: process.env.DB_NAME || 'cricket_auction_db',
        multipleStatements: true
      });
      closeOnFinish = true;
    }

    console.log('[Seed] Seeding database with realistic cricket auction data...');

    // 1. Generate bcrypt hashes
    const adminHash = await bcrypt.hash('Admin@123', 10);
    const teamHash = await bcrypt.hash('Team@123', 10);

    // 2. Read seed.sql
    const seedPath = path.join(__dirname, '../../../database/seed.sql');
    let seedSql = fs.readFileSync(seedPath, 'utf8');

    // Replace dummy hashes with real bcrypt hashes
    // Replace admin hash
    seedSql = seedSql.replace(
      "'$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'ADMIN'",
      `'${adminHash}', 'ADMIN'`
    );
    // Replace all team user hashes
    seedSql = seedSql.replaceAll(
      "'$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER'",
      `'${teamHash}', 'TEAM_USER'`
    );

    // 3. Execute seed script
    await connection.query(seedSql);

    console.log('[Seed] Database seeded successfully!');
    console.log('[Seed] Default credentials:');
    console.log('       ADMIN: username="admin", password="Admin@123"');
    console.log('       TEAM USERS: username="csk_owner", "mi_owner", "rcb_owner", etc., password="Team@123"');
  } catch (err) {
    console.error('[Seed Error]', err.message);
    if (closeOnFinish) process.exit(1);
    throw err;
  } finally {
    if (closeOnFinish && connection) {
      await connection.end();
    }
  }
}

if (require.main === module) {
  runSeed();
}

module.exports = { runSeed };
