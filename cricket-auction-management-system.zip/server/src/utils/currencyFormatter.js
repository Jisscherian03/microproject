/**
 * Indian Cricket Auction Currency Formatter Utility
 * Formats numbers into standard IPL auction notation (₹ Cr / ₹ L)
 */

function formatIndianCurrency(amount) {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return '₹0.00';
  }

  const num = Number(amount);
  const isNegative = num < 0;
  const absNum = Math.abs(num);

  let formatted = '';

  // 1 Crore = 10,000,000 (10^7)
  if (absNum >= 10000000) {
    const inCr = (absNum / 10000000).toFixed(2);
    formatted = `₹${inCr} Cr`;
  }
  // 1 Lakh = 100,000 (10^5)
  else if (absNum >= 100000) {
    const inLakh = (absNum / 100000).toFixed(2);
    formatted = `₹${inLakh} L`;
  }
  // Less than 1 Lakh
  else {
    formatted = `₹${absNum.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  }

  return isNegative ? `-${formatted}` : formatted;
}

module.exports = {
  formatIndianCurrency
};
