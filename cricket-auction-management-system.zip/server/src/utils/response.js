/**
 * Standard API Response Handlers
 */

function sendSuccess(res, data = null, message = 'Success', statusCode = 200) {
  return res.status(statusCode).json({
    success: true,
    message,
    data
  });
}

function sendError(res, error = 'An error occurred', statusCode = 500, details = null) {
  const response = {
    success: false,
    error: typeof error === 'string' ? error : (error.message || 'Internal server error')
  };

  if (details) {
    response.details = details;
  }

  return res.status(statusCode).json(response);
}

module.exports = {
  sendSuccess,
  sendError
};
