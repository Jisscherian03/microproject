const { query } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/response');
const { logAudit } = require('../middleware/auditLogger');

/**
 * Get all players with search, filtering, sorting, and pagination
 */
async function getAllPlayers(req, res, next) {
  try {
    const {
      search = '',
      role = '',
      nationality = '',
      status = '',
      sort_by = 'player_name',
      order = 'ASC',
      page = 1,
      limit = 12
    } = req.query;

    let whereClauses = ['1=1'];
    let params = [];

    if (search.trim()) {
      whereClauses.push('(p.player_name LIKE ? OR p.nationality LIKE ?)');
      params.push(`%${search.trim()}%`, `%${search.trim()}%`);
    }

    if (role.trim()) {
      whereClauses.push('p.role = ?');
      params.push(role.trim());
    }

    if (nationality.trim()) {
      whereClauses.push('p.nationality = ?');
      params.push(nationality.trim());
    }

    if (status.trim()) {
      whereClauses.push('p.status = ?');
      params.push(status.trim().toUpperCase());
    }

    const whereSql = whereClauses.join(' AND ');

    // Validate sort column to prevent SQL injection
    const allowedSortFields = {
      player_name: 'p.player_name',
      base_price: 'p.base_price',
      age: 'p.age',
      role: 'p.role',
      status: 'p.status',
      created_at: 'p.created_at'
    };
    const sortField = allowedSortFields[sort_by] || 'p.player_name';
    const sortOrder = order.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

    // Count total matching players
    const [countResult] = await query(
      `SELECT COUNT(*) as total FROM players p WHERE ${whereSql}`,
      params
    );
    const totalCount = countResult.total;

    // Pagination
    const pageNum = Math.max(1, parseInt(page, 10));
    const pageSize = Math.max(1, Math.min(100, parseInt(limit, 10)));
    const offset = (pageNum - 1) * pageSize;

    // Fetch players with purchase/team info if sold
    const players = await query(`
      SELECT p.id, p.player_name, p.image_url, p.nationality, p.age, p.role,
             p.batting_style, p.bowling_style, p.base_price, p.status,
             p.matches_played, p.runs_scored, p.wickets_taken,
             p.created_at, p.updated_at,
             pur.final_price, pur.purchased_at,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo
      FROM players p
      LEFT JOIN purchases pur ON p.id = pur.player_id
      LEFT JOIN teams t ON pur.team_id = t.id
      WHERE ${whereSql}
      ORDER BY ${sortField} ${sortOrder}
      LIMIT ? OFFSET ?
    `, [...params, pageSize, offset]);

    return sendSuccess(res, {
      players: players.map(p => ({
        id: p.id,
        name: p.player_name,
        image_url: p.image_url,
        nationality: p.nationality,
        age: p.age,
        role: p.role,
        batting_style: p.batting_style,
        bowling_style: p.bowling_style,
        base_price: Number(p.base_price),
        status: p.status,
        matches: p.matches_played,
        runs: p.runs_scored,
        wickets: p.wickets_taken,
        purchase: p.final_price ? {
          final_price: Number(p.final_price),
          purchased_at: p.purchased_at,
          team: {
            id: p.team_id,
            name: p.team_name,
            code: p.team_code,
            logo_url: p.team_logo
          }
        } : null,
        created_at: p.created_at,
        updated_at: p.updated_at
      })),
      pagination: {
        page: pageNum,
        limit: pageSize,
        total: totalCount,
        totalPages: Math.ceil(totalCount / pageSize)
      }
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Get player by ID
 */
async function getPlayerById(req, res, next) {
  try {
    const playerId = parseInt(req.params.id, 10);
    const rows = await query(`
      SELECT p.id, p.player_name, p.image_url, p.nationality, p.age, p.role,
             p.batting_style, p.bowling_style, p.base_price, p.status,
             p.matches_played, p.runs_scored, p.wickets_taken,
             p.created_at, p.updated_at,
             pur.final_price, pur.purchased_at,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo
      FROM players p
      LEFT JOIN purchases pur ON p.id = pur.player_id
      LEFT JOIN teams t ON pur.team_id = t.id
      WHERE p.id = ?
    `, [playerId]);

    if (rows.length === 0) {
      return sendError(res, 'Player not found.', 404);
    }

    const p = rows[0];

    // Fetch bidding history across auctions for this player
    const bidHistory = await query(`
      SELECT b.id, b.bid_amount, b.bid_status, b.created_at,
             t.team_name, t.team_code
      FROM bids b
      JOIN auctions a ON b.auction_id = a.id
      JOIN teams t ON b.team_id = t.id
      WHERE a.player_id = ?
      ORDER BY b.created_at DESC
    `, [playerId]);

    return sendSuccess(res, {
      id: p.id,
      name: p.player_name,
      image_url: p.image_url,
      nationality: p.nationality,
      age: p.age,
      role: p.role,
      batting_style: p.batting_style,
      bowling_style: p.bowling_style,
      base_price: Number(p.base_price),
      status: p.status,
      matches: p.matches_played,
      runs: p.runs_scored,
      wickets: p.wickets_taken,
      purchase: p.final_price ? {
        final_price: Number(p.final_price),
        purchased_at: p.purchased_at,
        team: {
          id: p.team_id,
          name: p.team_name,
          code: p.team_code,
          logo_url: p.team_logo
        }
      } : null,
      bids: bidHistory.map(b => ({
        id: b.id,
        amount: Number(b.bid_amount),
        status: b.bid_status,
        created_at: b.created_at,
        team_name: b.team_name,
        team_code: b.team_code
      })),
      created_at: p.created_at,
      updated_at: p.updated_at
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Add a new player (Admin only)
 */
async function createPlayer(req, res, next) {
  try {
    const {
      player_name,
      image_url,
      nationality,
      age,
      role,
      batting_style,
      bowling_style,
      base_price,
      matches_played,
      runs_scored,
      wickets_taken
    } = req.body;

    const validRoles = ['Batter', 'Bowler', 'All-rounder', 'Wicketkeeper'];
    if (!validRoles.includes(role)) {
      return sendError(res, `Invalid role. Must be one of: ${validRoles.join(', ')}`, 400);
    }

    const price = Number(base_price);
    if (isNaN(price) || price < 0) {
      return sendError(res, 'Base price must be a valid positive number.', 400);
    }

    const result = await query(`
      INSERT INTO players (
        player_name, image_url, nationality, age, role,
        batting_style, bowling_style, base_price, status,
        matches_played, runs_scored, wickets_taken
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'AVAILABLE', ?, ?, ?)
    `, [
      player_name.trim(),
      image_url || null,
      nationality.trim(),
      age ? parseInt(age, 10) : null,
      role,
      batting_style || null,
      bowling_style || null,
      price,
      matches_played ? parseInt(matches_played, 10) : 0,
      runs_scored ? parseInt(runs_scored, 10) : 0,
      wickets_taken ? parseInt(wickets_taken, 10) : 0
    ]);

    await logAudit(req.user.id, 'PLAYER_CREATED', 'PLAYER', result.insertId, {
      player_name,
      role,
      nationality,
      base_price: price
    });

    return sendSuccess(res, {
      id: result.insertId,
      name: player_name.trim(),
      role,
      nationality: nationality.trim(),
      base_price: price,
      status: 'AVAILABLE'
    }, 'Player created successfully', 201);
  } catch (err) {
    next(err);
  }
}

/**
 * Update player details (Admin only)
 */
async function updatePlayer(req, res, next) {
  try {
    const playerId = parseInt(req.params.id, 10);
    const {
      player_name,
      image_url,
      nationality,
      age,
      role,
      batting_style,
      bowling_style,
      base_price,
      status,
      matches_played,
      runs_scored,
      wickets_taken
    } = req.body;

    const [player] = await query('SELECT * FROM players WHERE id = ?', [playerId]);
    if (!player) {
      return sendError(res, 'Player not found.', 404);
    }

    // A player who has already been sold must not become available again through an ordinary edit operation
    if (player.status === 'SOLD' && status && status !== 'SOLD') {
      return sendError(res, 'A SOLD player cannot be changed to another status via edit. The player is already committed to a team squad.', 400);
    }

    // If player is currently IN_AUCTION, do not allow changing base price or role
    if (player.status === 'IN_AUCTION' && (base_price !== undefined || role !== undefined)) {
      return sendError(res, 'Cannot change base price or role of a player currently in an active auction.', 400);
    }

    await query(`
      UPDATE players
      SET player_name = COALESCE(?, player_name),
          image_url = COALESCE(?, image_url),
          nationality = COALESCE(?, nationality),
          age = COALESCE(?, age),
          role = COALESCE(?, role),
          batting_style = COALESCE(?, batting_style),
          bowling_style = COALESCE(?, bowling_style),
          base_price = COALESCE(?, base_price),
          status = COALESCE(?, status),
          matches_played = COALESCE(?, matches_played),
          runs_scored = COALESCE(?, runs_scored),
          wickets_taken = COALESCE(?, wickets_taken)
      WHERE id = ?
    `, [
      player_name ? player_name.trim() : null,
      image_url !== undefined ? image_url : null,
      nationality ? nationality.trim() : null,
      age !== undefined ? parseInt(age, 10) : null,
      role || null,
      batting_style !== undefined ? batting_style : null,
      bowling_style !== undefined ? bowling_style : null,
      base_price !== undefined ? Number(base_price) : null,
      status || null,
      matches_played !== undefined ? parseInt(matches_played, 10) : null,
      runs_scored !== undefined ? parseInt(runs_scored, 10) : null,
      wickets_taken !== undefined ? parseInt(wickets_taken, 10) : null,
      playerId
    ]);

    await logAudit(req.user.id, 'PLAYER_UPDATED', 'PLAYER', playerId, {
      player_name,
      base_price,
      status
    });

    return sendSuccess(res, null, 'Player updated successfully');
  } catch (err) {
    next(err);
  }
}

/**
 * Delete player (Admin only - with integrity check)
 */
async function deletePlayer(req, res, next) {
  try {
    const playerId = parseInt(req.params.id, 10);

    // Check if player has purchase records
    const purchases = await query('SELECT id FROM purchases WHERE player_id = ? LIMIT 1', [playerId]);
    if (purchases.length > 0) {
      return sendError(res, 'Cannot delete player because they have purchase history. Archive or mark unsold instead.', 400);
    }

    // Check if player has auctions
    const auctions = await query('SELECT id FROM auctions WHERE player_id = ? LIMIT 1', [playerId]);
    if (auctions.length > 0) {
      return sendError(res, 'Cannot delete player because auction records exist for this player.', 400);
    }

    await query('DELETE FROM players WHERE id = ?', [playerId]);
    await logAudit(req.user.id, 'PLAYER_DELETED', 'PLAYER', playerId);

    return sendSuccess(res, null, 'Player deleted successfully');
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllPlayers,
  getPlayerById,
  createPlayer,
  updatePlayer,
  deletePlayer
};
