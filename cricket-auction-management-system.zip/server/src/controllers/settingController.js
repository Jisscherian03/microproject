const { query } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/response');
const { logAudit } = require('../middleware/auditLogger');

/**
 * Get auction configuration settings
 */
async function getSettings(req, res, next) {
  try {
    const rows = await query('SELECT * FROM auction_settings LIMIT 1');
    if (rows.length === 0) {
      // Return defaults if table is empty
      return sendSuccess(res, {
        id: 1,
        minimum_bid_increment: 2000000.00,
        maximum_squad_size: 25,
        min_batters: 4,
        min_bowlers: 4,
        min_allrounders: 2,
        min_wicketkeepers: 1,
        allow_self_outbid: false
      });
    }

    const s = rows[0];
    return sendSuccess(res, {
      id: s.id,
      minimum_bid_increment: Number(s.minimum_bid_increment),
      maximum_squad_size: s.maximum_squad_size,
      min_batters: s.min_batters,
      min_bowlers: s.min_bowlers,
      min_allrounders: s.min_allrounders,
      min_wicketkeepers: s.min_wicketkeepers,
      allow_self_outbid: Boolean(s.allow_self_outbid),
      updated_at: s.updated_at
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Update auction settings (Admin only)
 */
async function updateSettings(req, res, next) {
  try {
    const {
      minimum_bid_increment,
      maximum_squad_size,
      min_batters,
      min_bowlers,
      min_allrounders,
      min_wicketkeepers,
      allow_self_outbid
    } = req.body;

    const minIncrement = Number(minimum_bid_increment);
    const maxSquad = parseInt(maximum_squad_size, 10);

    if (minimum_bid_increment !== undefined && (isNaN(minIncrement) || minIncrement <= 0)) {
      return sendError(res, 'Minimum bid increment must be a positive number.', 400);
    }

    if (maximum_squad_size !== undefined && (isNaN(maxSquad) || maxSquad < 11)) {
      return sendError(res, 'Maximum squad size must be at least 11 players.', 400);
    }

    // Check if row exists
    const existing = await query('SELECT id FROM auction_settings LIMIT 1');

    if (existing.length === 0) {
      await query(`
        INSERT INTO auction_settings (
          id, minimum_bid_increment, maximum_squad_size,
          min_batters, min_bowlers, min_allrounders, min_wicketkeepers, allow_self_outbid
        ) VALUES (1, ?, ?, ?, ?, ?, ?, ?)
      `, [
        minIncrement || 2000000.00,
        maxSquad || 25,
        min_batters || 4,
        min_bowlers || 4,
        min_allrounders || 2,
        min_wicketkeepers || 1,
        allow_self_outbid ? 1 : 0
      ]);
    } else {
      await query(`
        UPDATE auction_settings
        SET minimum_bid_increment = COALESCE(?, minimum_bid_increment),
            maximum_squad_size = COALESCE(?, maximum_squad_size),
            min_batters = COALESCE(?, min_batters),
            min_bowlers = COALESCE(?, min_bowlers),
            min_allrounders = COALESCE(?, min_allrounders),
            min_wicketkeepers = COALESCE(?, min_wicketkeepers),
            allow_self_outbid = COALESCE(?, allow_self_outbid)
        WHERE id = ?
      `, [
        minIncrement || null,
        maxSquad || null,
        min_batters || null,
        min_bowlers || null,
        min_allrounders || null,
        min_wicketkeepers || null,
        allow_self_outbid !== undefined ? (allow_self_outbid ? 1 : 0) : null,
        existing[0].id
      ]);
    }

    await logAudit(req.user.id, 'SETTINGS_UPDATED', 'SETTINGS', 1, req.body);

    return sendSuccess(res, null, 'Auction settings updated successfully');
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getSettings,
  updateSettings
};
