const { query, withTransaction } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/response');
const { logAudit } = require('../middleware/auditLogger');

/**
 * Get all teams with their current squad count and financial status
 */
async function getAllTeams(req, res, next) {
  try {
    const teams = await query(`
      SELECT t.id, t.team_name, t.team_code, t.logo_url,
             t.initial_purse, t.remaining_purse,
             (t.initial_purse - t.remaining_purse) as total_spent,
             COUNT(DISTINCT p.id) as squad_count,
             t.created_at, t.updated_at
      FROM teams t
      LEFT JOIN purchases p ON t.id = p.team_id
      GROUP BY t.id
      ORDER BY t.team_name ASC
    `);

    return sendSuccess(res, teams.map(t => ({
      id: t.id,
      name: t.team_name,
      code: t.team_code,
      logo_url: t.logo_url,
      initial_purse: Number(t.initial_purse),
      remaining_purse: Number(t.remaining_purse),
      total_spent: Number(t.total_spent),
      squad_count: Number(t.squad_count),
      created_at: t.created_at,
      updated_at: t.updated_at
    })));
  } catch (err) {
    next(err);
  }
}

/**
 * Get single team by ID with detailed stats
 */
async function getTeamById(req, res, next) {
  try {
    const teamId = parseInt(req.params.id, 10);
    const rows = await query(`
      SELECT t.id, t.team_name, t.team_code, t.logo_url,
             t.initial_purse, t.remaining_purse,
             (t.initial_purse - t.remaining_purse) as total_spent,
             COUNT(DISTINCT p.id) as squad_count,
             t.created_at, t.updated_at
      FROM teams t
      LEFT JOIN purchases p ON t.id = p.team_id
      WHERE t.id = ?
      GROUP BY t.id
    `, [teamId]);

    if (rows.length === 0) {
      return sendError(res, 'Team not found.', 404);
    }

    const t = rows[0];
    return sendSuccess(res, {
      id: t.id,
      name: t.team_name,
      code: t.team_code,
      logo_url: t.logo_url,
      initial_purse: Number(t.initial_purse),
      remaining_purse: Number(t.remaining_purse),
      total_spent: Number(t.total_spent),
      squad_count: Number(t.squad_count),
      created_at: t.created_at,
      updated_at: t.updated_at
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Create a new team (Admin only)
 */
async function createTeam(req, res, next) {
  try {
    const { team_name, team_code, logo_url, initial_purse } = req.body;

    // Check unique team code
    const existing = await query('SELECT id FROM teams WHERE team_code = ?', [team_code.toUpperCase().trim()]);
    if (existing.length > 0) {
      return sendError(res, `Team code '${team_code.toUpperCase()}' is already taken.`, 400);
    }

    const purse = initial_purse ? Number(initial_purse) : 1000000000.00;

    const result = await query(`
      INSERT INTO teams (team_name, team_code, logo_url, initial_purse, remaining_purse)
      VALUES (?, ?, ?, ?, ?)
    `, [team_name.trim(), team_code.toUpperCase().trim(), logo_url || null, purse, purse]);

    await logAudit(req.user.id, 'TEAM_CREATED', 'TEAM', result.insertId, {
      team_name,
      team_code: team_code.toUpperCase(),
      initial_purse: purse
    });

    return sendSuccess(res, {
      id: result.insertId,
      name: team_name.trim(),
      code: team_code.toUpperCase().trim(),
      logo_url: logo_url || null,
      initial_purse: purse,
      remaining_purse: purse
    }, 'Team created successfully', 201);
  } catch (err) {
    next(err);
  }
}

/**
 * Update team (Admin only)
 */
async function updateTeam(req, res, next) {
  try {
    const teamId = parseInt(req.params.id, 10);
    const { team_name, team_code, logo_url, initial_purse } = req.body;

    const existingRows = await query('SELECT * FROM teams WHERE id = ?', [teamId]);
    if (existingRows.length === 0) {
      return sendError(res, 'Team not found.', 404);
    }

    const currentTeam = existingRows[0];

    // Check code uniqueness
    if (team_code && team_code.toUpperCase().trim() !== currentTeam.team_code) {
      const codeCheck = await query('SELECT id FROM teams WHERE team_code = ? AND id != ?', [team_code.toUpperCase().trim(), teamId]);
      if (codeCheck.length > 0) {
        return sendError(res, `Team code '${team_code.toUpperCase()}' is already in use by another team.`, 400);
      }
    }

    // If initial purse changes, reconcile remaining purse: remaining = new_initial - total_spent
    let newInitialPurse = currentTeam.initial_purse;
    let newRemainingPurse = currentTeam.remaining_purse;

    if (initial_purse !== undefined && initial_purse !== null) {
      const parsedInitial = Number(initial_purse);
      const [spentRow] = await query('SELECT COALESCE(SUM(final_price), 0) as total_spent FROM purchases WHERE team_id = ?', [teamId]);
      const totalSpent = Number(spentRow.total_spent || 0);

      if (parsedInitial < totalSpent) {
        return sendError(res, `Initial purse cannot be less than already spent amount (₹${(totalSpent / 10000000).toFixed(2)} Cr).`, 400);
      }

      newInitialPurse = parsedInitial;
      newRemainingPurse = parsedInitial - totalSpent;
    }

    await query(`
      UPDATE teams
      SET team_name = COALESCE(?, team_name),
          team_code = COALESCE(?, team_code),
          logo_url = COALESCE(?, logo_url),
          initial_purse = ?,
          remaining_purse = ?
      WHERE id = ?
    `, [
      team_name ? team_name.trim() : null,
      team_code ? team_code.toUpperCase().trim() : null,
      logo_url !== undefined ? logo_url : null,
      newInitialPurse,
      newRemainingPurse,
      teamId
    ]);

    await logAudit(req.user.id, 'TEAM_UPDATED', 'TEAM', teamId, {
      team_name,
      team_code: team_code ? team_code.toUpperCase() : undefined,
      newInitialPurse,
      newRemainingPurse
    });

    return sendSuccess(res, null, 'Team updated successfully');
  } catch (err) {
    next(err);
  }
}

/**
 * Delete team (Admin only - with integrity protection)
 */
async function deleteTeam(req, res, next) {
  try {
    const teamId = parseInt(req.params.id, 10);

    // Verify no linked purchases
    const purchases = await query('SELECT id FROM purchases WHERE team_id = ? LIMIT 1', [teamId]);
    if (purchases.length > 0) {
      return sendError(res, 'Cannot delete team because it has purchased players. Archive the team or remove purchases first.', 400);
    }

    // Verify no linked bids
    const bids = await query('SELECT id FROM bids WHERE team_id = ? LIMIT 1', [teamId]);
    if (bids.length > 0) {
      return sendError(res, 'Cannot delete team because it has active or historical bids.', 400);
    }

    // Verify no linked users
    const users = await query('SELECT id FROM users WHERE team_id = ? LIMIT 1', [teamId]);
    if (users.length > 0) {
      return sendError(res, 'Cannot delete team because it is assigned to one or more user accounts.', 400);
    }

    await query('DELETE FROM teams WHERE id = ?', [teamId]);
    await logAudit(req.user.id, 'TEAM_DELETED', 'TEAM', teamId);

    return sendSuccess(res, null, 'Team deleted successfully');
  } catch (err) {
    next(err);
  }
}

/**
 * Get purchased squad for a team
 */
async function getTeamSquad(req, res, next) {
  try {
    const teamId = parseInt(req.params.id, 10);

    const squad = await query(`
      SELECT p.id, p.player_name, p.nationality, p.age, p.role,
             p.batting_style, p.bowling_style, p.base_price, p.image_url,
             p.matches_played, p.runs_scored, p.wickets_taken,
             pur.final_price, pur.purchased_at, pur.id as purchase_id
      FROM purchases pur
      JOIN players p ON pur.player_id = p.id
      WHERE pur.team_id = ?
      ORDER BY pur.final_price DESC
    `, [teamId]);

    // Role breakdown
    const roleStats = {
      Batter: 0,
      Bowler: 0,
      'All-rounder': 0,
      Wicketkeeper: 0
    };

    let totalSpent = 0;
    squad.forEach(item => {
      if (roleStats[item.role] !== undefined) {
        roleStats[item.role]++;
      }
      totalSpent += Number(item.final_price);
    });

    return sendSuccess(res, {
      players: squad.map(s => ({
        id: s.id,
        purchase_id: s.purchase_id,
        name: s.player_name,
        nationality: s.nationality,
        age: s.age,
        role: s.role,
        batting_style: s.batting_style,
        bowling_style: s.bowling_style,
        base_price: Number(s.base_price),
        image_url: s.image_url,
        final_price: Number(s.final_price),
        purchased_at: s.purchased_at,
        matches: s.matches_played,
        runs: s.runs_scored,
        wickets: s.wickets_taken
      })),
      total_players: squad.length,
      total_spent: totalSpent,
      role_breakdown: roleStats
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Get team financial and squad summary
 */
async function getTeamSummary(req, res, next) {
  try {
    const teamId = parseInt(req.params.id, 10);

    const [team] = await query('SELECT * FROM teams WHERE id = ?', [teamId]);
    if (!team) {
      return sendError(res, 'Team not found.', 404);
    }

    const [purchaseSummary] = await query(`
      SELECT COUNT(*) as player_count, COALESCE(SUM(final_price), 0) as total_spent
      FROM purchases
      WHERE team_id = ?
    `, [teamId]);

    const [bidSummary] = await query(`
      SELECT COUNT(*) as total_bids, COALESCE(MAX(bid_amount), 0) as highest_bid
      FROM bids
      WHERE team_id = ?
    `, [teamId]);

    return sendSuccess(res, {
      team: {
        id: team.id,
        name: team.team_name,
        code: team.team_code,
        logo_url: team.logo_url,
        initial_purse: Number(team.initial_purse),
        remaining_purse: Number(team.remaining_purse),
        total_spent: Number(purchaseSummary.total_spent || 0),
        player_count: Number(purchaseSummary.player_count || 0),
        total_bids: Number(bidSummary.total_bids || 0),
        highest_bid: Number(bidSummary.highest_bid || 0)
      }
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllTeams,
  getTeamById,
  createTeam,
  updateTeam,
  deleteTeam,
  getTeamSquad,
  getTeamSummary
};
