const { query } = require('../config/db');
const { sendSuccess } = require('../utils/response');

/**
 * High-level overview statistics for reports
 */
async function getOverview(req, res, next) {
  try {
    // Total spent & average selling price
    const [spentAvgRow] = await query(`
      SELECT
        COUNT(*) as total_sold,
        COALESCE(SUM(final_price), 0) as total_spending,
        COALESCE(AVG(final_price), 0) as average_price
      FROM purchases
    `);

    // Total unsold
    const [unsoldRow] = await query(`
      SELECT COUNT(*) as total_unsold FROM players WHERE status = 'UNSOLD'
    `);

    // Most expensive player
    const mostExpensiveRows = await query(`
      SELECT pur.final_price, p.player_name, p.role, p.nationality, p.image_url,
             t.team_name, t.team_code, t.logo_url as team_logo
      FROM purchases pur
      JOIN players p ON pur.player_id = p.id
      JOIN teams t ON pur.team_id = t.id
      ORDER BY pur.final_price DESC
      LIMIT 1
    `);

    // Highest-spending team
    const highestSpendingTeamRows = await query(`
      SELECT t.id, t.team_name, t.team_code, t.logo_url,
             t.initial_purse, t.remaining_purse,
             COALESCE(SUM(pur.final_price), 0) as total_spent,
             COUNT(pur.id) as squad_count
      FROM teams t
      LEFT JOIN purchases pur ON t.id = pur.team_id
      GROUP BY t.id
      ORDER BY total_spent DESC
      LIMIT 1
    `);

    return sendSuccess(res, {
      total_sold: Number(spentAvgRow.total_sold || 0),
      total_unsold: Number(unsoldRow.total_unsold || 0),
      total_spending: Number(spentAvgRow.total_spending || 0),
      average_price: Number(spentAvgRow.average_price || 0),
      most_expensive_player: mostExpensiveRows.length > 0 ? {
        player_name: mostExpensiveRows[0].player_name,
        role: mostExpensiveRows[0].role,
        nationality: mostExpensiveRows[0].nationality,
        image_url: mostExpensiveRows[0].image_url,
        final_price: Number(mostExpensiveRows[0].final_price),
        team_name: mostExpensiveRows[0].team_name,
        team_code: mostExpensiveRows[0].team_code,
        team_logo: mostExpensiveRows[0].team_logo
      } : null,
      highest_spending_team: highestSpendingTeamRows.length > 0 ? {
        team_name: highestSpendingTeamRows[0].team_name,
        team_code: highestSpendingTeamRows[0].team_code,
        logo_url: highestSpendingTeamRows[0].logo_url,
        total_spent: Number(highestSpendingTeamRows[0].total_spent),
        remaining_purse: Number(highestSpendingTeamRows[0].remaining_purse),
        squad_count: Number(highestSpendingTeamRows[0].squad_count)
      } : null
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Team-wise spending analysis
 */
async function getTeamSpending(req, res, next) {
  try {
    const teams = await query(`
      SELECT t.id, t.team_name, t.team_code, t.logo_url,
             t.initial_purse, t.remaining_purse,
             COALESCE(SUM(pur.final_price), 0) as total_spent,
             COUNT(pur.id) as squad_count,
             COALESCE(AVG(pur.final_price), 0) as average_player_cost
      FROM teams t
      LEFT JOIN purchases pur ON t.id = pur.team_id
      GROUP BY t.id
      ORDER BY total_spent DESC, t.team_name ASC
    `);

    return sendSuccess(res, teams.map(t => ({
      id: t.id,
      name: t.team_name,
      code: t.team_code,
      logo_url: t.logo_url,
      initial_purse: Number(t.initial_purse),
      remaining_purse: Number(t.remaining_purse),
      total_spent: Number(t.total_spent),
      squad_count: Number(t.squad_count),
      average_player_cost: Number(t.average_player_cost)
    })));
  } catch (err) {
    next(err);
  }
}

/**
 * All sold players with price analysis
 */
async function getSoldPlayers(req, res, next) {
  try {
    const sold = await query(`
      SELECT pur.id as purchase_id, pur.final_price, pur.purchased_at,
             p.id as player_id, p.player_name, p.role, p.nationality, p.base_price, p.image_url,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo,
             (pur.final_price - p.base_price) as price_jump,
             ROUND(((pur.final_price - p.base_price) / p.base_price) * 100, 2) as percentage_increase
      FROM purchases pur
      JOIN players p ON pur.player_id = p.id
      JOIN teams t ON pur.team_id = t.id
      ORDER BY pur.final_price DESC
    `);

    return sendSuccess(res, sold.map(s => ({
      purchase_id: s.purchase_id,
      player: {
        id: s.player_id,
        name: s.player_name,
        role: s.role,
        nationality: s.nationality,
        base_price: Number(s.base_price),
        image_url: s.image_url
      },
      team: {
        id: s.team_id,
        name: s.team_name,
        code: s.team_code,
        logo_url: s.team_logo
      },
      final_price: Number(s.final_price),
      price_jump: Number(s.price_jump),
      percentage_increase: Number(s.percentage_increase),
      purchased_at: s.purchased_at
    })));
  } catch (err) {
    next(err);
  }
}

/**
 * All unsold players report
 */
async function getUnsoldPlayers(req, res, next) {
  try {
    const unsold = await query(`
      SELECT id, player_name, role, nationality, age, base_price,
             matches_played, runs_scored, wickets_taken, image_url, updated_at
      FROM players
      WHERE status = 'UNSOLD'
      ORDER BY base_price DESC, player_name ASC
    `);

    return sendSuccess(res, unsold.map(p => ({
      id: p.id,
      name: p.player_name,
      role: p.role,
      nationality: p.nationality,
      age: p.age,
      base_price: Number(p.base_price),
      image_url: p.image_url,
      matches: p.matches_played,
      runs: p.runs_scored,
      wickets: p.wickets_taken,
      marked_at: p.updated_at
    })));
  } catch (err) {
    next(err);
  }
}

/**
 * Role-wise purchase breakdown
 */
async function getRoleBreakdown(req, res, next) {
  try {
    const roles = await query(`
      SELECT p.role,
             COUNT(pur.id) as sold_count,
             COALESCE(SUM(pur.final_price), 0) as total_spent,
             COALESCE(AVG(pur.final_price), 0) as average_price,
             COALESCE(MAX(pur.final_price), 0) as max_price,
             COALESCE(MIN(pur.final_price), 0) as min_price
      FROM players p
      LEFT JOIN purchases pur ON p.id = pur.player_id
      GROUP BY p.role
      ORDER BY total_spent DESC
    `);

    return sendSuccess(res, roles.map(r => ({
      role: r.role,
      sold_count: Number(r.sold_count),
      total_spent: Number(r.total_spent),
      average_price: Number(r.average_price),
      max_price: Number(r.max_price),
      min_price: Number(r.min_price)
    })));
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getOverview,
  getTeamSpending,
  getSoldPlayers,
  getUnsoldPlayers,
  getRoleBreakdown
};
