const { query, getConnection, withTransaction } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/response');
const { logAudit } = require('../middleware/auditLogger');
const { emitAuctionEvent } = require('../sockets/auctionSocket');

/**
 * Get all auctions (with player, leading team, and creator details)
 */
async function getAllAuctions(req, res, next) {
  try {
    const auctions = await query(`
      SELECT a.id, a.current_bid, a.status, a.started_at, a.closed_at, a.created_at,
             p.id as player_id, p.player_name, p.role, p.nationality, p.base_price, p.image_url,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo,
             u.username as created_by_username
      FROM auctions a
      JOIN players p ON a.player_id = p.id
      LEFT JOIN teams t ON a.highest_bid_team_id = t.id
      JOIN users u ON a.created_by = u.id
      ORDER BY a.created_at DESC
    `);

    return sendSuccess(res, auctions.map(a => ({
      id: a.id,
      status: a.status,
      current_bid: Number(a.current_bid),
      started_at: a.started_at,
      closed_at: a.closed_at,
      created_at: a.created_at,
      player: {
        id: a.player_id,
        name: a.player_name,
        role: a.role,
        nationality: a.nationality,
        base_price: Number(a.base_price),
        image_url: a.image_url
      },
      leading_team: a.team_id ? {
        id: a.team_id,
        name: a.team_name,
        code: a.team_code,
        logo_url: a.team_logo
      } : null,
      created_by: a.created_by_username
    })));
  } catch (err) {
    next(err);
  }
}

/**
 * Get the currently active auction (OPEN, PAUSED, READY, or most recent)
 */
async function getCurrentAuction(req, res, next) {
  try {
    const rows = await query(`
      SELECT a.id, a.current_bid, a.status, a.started_at, a.closed_at, a.created_at,
             p.id as player_id, p.player_name, p.role, p.nationality, p.age,
             p.batting_style, p.bowling_style, p.base_price, p.image_url,
             p.matches_played, p.runs_scored, p.wickets_taken,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo,
             u.username as created_by_username
      FROM auctions a
      JOIN players p ON a.player_id = p.id
      LEFT JOIN teams t ON a.highest_bid_team_id = t.id
      JOIN users u ON a.created_by = u.id
      WHERE a.status IN ('OPEN', 'PAUSED', 'READY', 'DRAFT')
      ORDER BY FIELD(a.status, 'OPEN', 'PAUSED', 'READY', 'DRAFT'), a.updated_at DESC
      LIMIT 1
    `);

    if (rows.length === 0) {
      return sendSuccess(res, null, 'No active auction currently in progress');
    }

    const a = rows[0];

    // Fetch recent bids for this current auction
    const bids = await query(`
      SELECT b.id, b.bid_amount, b.bid_status, b.created_at,
             t.id as team_id, t.team_name, t.team_code, t.logo_url
      FROM bids b
      JOIN teams t ON b.team_id = t.id
      WHERE b.auction_id = ?
      ORDER BY b.created_at DESC
      LIMIT 30
    `, [a.id]);

    // Fetch auction settings
    const [settings] = await query('SELECT * FROM auction_settings LIMIT 1');

    return sendSuccess(res, {
      id: a.id,
      status: a.status,
      current_bid: Number(a.current_bid),
      started_at: a.started_at,
      closed_at: a.closed_at,
      created_at: a.created_at,
      player: {
        id: a.player_id,
        name: a.player_name,
        role: a.role,
        nationality: a.nationality,
        age: a.age,
        batting_style: a.batting_style,
        bowling_style: a.bowling_style,
        base_price: Number(a.base_price),
        image_url: a.image_url,
        matches: a.matches_played,
        runs: a.runs_scored,
        wickets: a.wickets_taken
      },
      leading_team: a.team_id ? {
        id: a.team_id,
        name: a.team_name,
        code: a.team_code,
        logo_url: a.team_logo
      } : null,
      created_by: a.created_by_username,
      bids: bids.map(b => ({
        id: b.id,
        bid_amount: Number(b.bid_amount),
        bid_status: b.bid_status,
        created_at: b.created_at,
        team: {
          id: b.team_id,
          name: b.team_name,
          code: b.team_code,
          logo_url: b.logo_url
        }
      })),
      settings: settings ? {
        minimum_bid_increment: Number(settings.minimum_bid_increment),
        maximum_squad_size: settings.maximum_squad_size,
        allow_self_outbid: Boolean(settings.allow_self_outbid)
      } : {
        minimum_bid_increment: 2000000,
        maximum_squad_size: 25,
        allow_self_outbid: false
      }
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Get auction by ID
 */
async function getAuctionById(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);
    const rows = await query(`
      SELECT a.id, a.current_bid, a.status, a.started_at, a.closed_at, a.created_at,
             p.id as player_id, p.player_name, p.role, p.nationality, p.age,
             p.batting_style, p.bowling_style, p.base_price, p.image_url,
             p.matches_played, p.runs_scored, p.wickets_taken,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo,
             u.username as created_by_username
      FROM auctions a
      JOIN players p ON a.player_id = p.id
      LEFT JOIN teams t ON a.highest_bid_team_id = t.id
      JOIN users u ON a.created_by = u.id
      WHERE a.id = ?
    `, [auctionId]);

    if (rows.length === 0) {
      return sendError(res, 'Auction not found.', 404);
    }

    const a = rows[0];

    const bids = await query(`
      SELECT b.id, b.bid_amount, b.bid_status, b.created_at,
             t.id as team_id, t.team_name, t.team_code, t.logo_url
      FROM bids b
      JOIN teams t ON b.team_id = t.id
      WHERE b.auction_id = ?
      ORDER BY b.created_at DESC
    `, [auctionId]);

    return sendSuccess(res, {
      id: a.id,
      status: a.status,
      current_bid: Number(a.current_bid),
      started_at: a.started_at,
      closed_at: a.closed_at,
      created_at: a.created_at,
      player: {
        id: a.player_id,
        name: a.player_name,
        role: a.role,
        nationality: a.nationality,
        age: a.age,
        batting_style: a.batting_style,
        bowling_style: a.bowling_style,
        base_price: Number(a.base_price),
        image_url: a.image_url,
        matches: a.matches_played,
        runs: a.runs_scored,
        wickets: a.wickets_taken
      },
      leading_team: a.team_id ? {
        id: a.team_id,
        name: a.team_name,
        code: a.team_code,
        logo_url: a.team_logo
      } : null,
      created_by: a.created_by_username,
      bids: bids.map(b => ({
        id: b.id,
        bid_amount: Number(b.bid_amount),
        bid_status: b.bid_status,
        created_at: b.created_at,
        team: {
          id: b.team_id,
          name: b.team_name,
          code: b.team_code,
          logo_url: b.logo_url
        }
      }))
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Create a new auction for an available player (Admin only)
 */
async function createAuction(req, res, next) {
  try {
    const { player_id } = req.body;
    const playerId = parseInt(player_id, 10);

    if (!playerId) {
      return sendError(res, 'Valid player_id is required.', 400);
    }

    const conn = await getConnection();
    try {
      await conn.beginTransaction();

      // Lock player record to verify availability
      const [players] = await conn.execute(
        'SELECT id, player_name, base_price, status FROM players WHERE id = ? FOR UPDATE',
        [playerId]
      );

      if (players.length === 0) {
        await conn.rollback();
        return sendError(res, 'Player not found.', 404);
      }

      const player = players[0];

      if (player.status === 'SOLD') {
        await conn.rollback();
        return sendError(res, 'This player has already been sold and cannot be auctioned again.', 400);
      }

      if (player.status === 'IN_AUCTION') {
        await conn.rollback();
        return sendError(res, 'This player is already in an active auction.', 400);
      }

      // Check if there is an active conflicting auction for this player
      const [existingActive] = await conn.execute(
        "SELECT id FROM auctions WHERE player_id = ? AND status IN ('DRAFT', 'READY', 'OPEN', 'PAUSED') FOR UPDATE",
        [playerId]
      );

      if (existingActive.length > 0) {
        await conn.rollback();
        return sendError(res, 'An active auction already exists for this player.', 400);
      }

      // Check if another auction is already OPEN (to maintain one live auction block at a time)
      const [openAuctions] = await conn.execute(
        "SELECT id FROM auctions WHERE status = 'OPEN' FOR UPDATE"
      );

      const initialStatus = openAuctions.length > 0 ? 'READY' : 'OPEN';
      const startedAt = initialStatus === 'OPEN' ? new Date() : null;

      // Update player status to IN_AUCTION
      await conn.execute("UPDATE players SET status = 'IN_AUCTION' WHERE id = ?", [playerId]);

      // Insert new auction record
      const [result] = await conn.execute(`
        INSERT INTO auctions (player_id, current_bid, highest_bid_team_id, status, started_at, created_by)
        VALUES (?, 0.00, NULL, ?, ?, ?)
      `, [playerId, initialStatus, startedAt, req.user.id]);

      const auctionId = result.insertId;

      await logAudit(req.user.id, 'AUCTION_CREATED', 'AUCTION', auctionId, {
        player_id: playerId,
        player_name: player.player_name,
        initial_status: initialStatus
      }, conn);

      await conn.commit();

      const newAuctionData = {
        id: auctionId,
        player_id: playerId,
        player_name: player.player_name,
        base_price: Number(player.base_price),
        status: initialStatus,
        current_bid: 0
      };

      emitAuctionEvent('auction:created', newAuctionData);

      return sendSuccess(res, newAuctionData, 'Auction created successfully', 201);
    } catch (error) {
      await conn.rollback();
      throw error;
    } finally {
      conn.release();
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Start or Open an auction (Admin only)
 */
async function startAuction(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);

    const result = await withTransaction(async (conn) => {
      const [auctions] = await conn.execute(
        'SELECT * FROM auctions WHERE id = ? FOR UPDATE',
        [auctionId]
      );

      if (auctions.length === 0) {
        throw { statusCode: 404, message: 'Auction not found' };
      }

      const auction = auctions[0];
      if (auction.status === 'SOLD' || auction.status === 'UNSOLD') {
        throw { statusCode: 400, message: `Cannot start an auction that is already finalized as ${auction.status}` };
      }

      await conn.execute(`
        UPDATE auctions
        SET status = 'OPEN', started_at = COALESCE(started_at, NOW())
        WHERE id = ?
      `, [auctionId]);

      await conn.execute("UPDATE players SET status = 'IN_AUCTION' WHERE id = ?", [auction.player_id]);

      await logAudit(req.user.id, 'AUCTION_STARTED', 'AUCTION', auctionId, { status: 'OPEN' }, conn);

      return { id: auctionId, status: 'OPEN' };
    });

    emitAuctionEvent('auction:status_changed', { id: auctionId, status: 'OPEN' });
    return sendSuccess(res, result, 'Auction started. Bidding is now OPEN.');
  } catch (err) {
    next(err);
  }
}

/**
 * Pause bidding (Admin only)
 */
async function pauseAuction(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);

    const result = await withTransaction(async (conn) => {
      const [auctions] = await conn.execute('SELECT * FROM auctions WHERE id = ? FOR UPDATE', [auctionId]);
      if (auctions.length === 0) throw { statusCode: 404, message: 'Auction not found' };

      const auction = auctions[0];
      if (auction.status !== 'OPEN') {
        throw { statusCode: 400, message: `Can only pause an auction in OPEN status (current: ${auction.status})` };
      }

      await conn.execute("UPDATE auctions SET status = 'PAUSED' WHERE id = ?", [auctionId]);
      await logAudit(req.user.id, 'AUCTION_PAUSED', 'AUCTION', auctionId, { status: 'PAUSED' }, conn);

      return { id: auctionId, status: 'PAUSED' };
    });

    emitAuctionEvent('auction:status_changed', { id: auctionId, status: 'PAUSED' });
    return sendSuccess(res, result, 'Auction paused');
  } catch (err) {
    next(err);
  }
}

/**
 * Resume bidding (Admin only)
 */
async function resumeAuction(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);

    const result = await withTransaction(async (conn) => {
      const [auctions] = await conn.execute('SELECT * FROM auctions WHERE id = ? FOR UPDATE', [auctionId]);
      if (auctions.length === 0) throw { statusCode: 404, message: 'Auction not found' };

      const auction = auctions[0];
      if (auction.status !== 'PAUSED') {
        throw { statusCode: 400, message: `Can only resume a PAUSED auction (current: ${auction.status})` };
      }

      await conn.execute("UPDATE auctions SET status = 'OPEN' WHERE id = ?", [auctionId]);
      await logAudit(req.user.id, 'AUCTION_RESUMED', 'AUCTION', auctionId, { status: 'OPEN' }, conn);

      return { id: auctionId, status: 'OPEN' };
    });

    emitAuctionEvent('auction:status_changed', { id: auctionId, status: 'OPEN' });
    return sendSuccess(res, result, 'Auction resumed. Bidding is now OPEN.');
  } catch (err) {
    next(err);
  }
}

/**
 * Close bidding (Admin only)
 */
async function closeAuction(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);

    const result = await withTransaction(async (conn) => {
      const [auctions] = await conn.execute('SELECT * FROM auctions WHERE id = ? FOR UPDATE', [auctionId]);
      if (auctions.length === 0) throw { statusCode: 404, message: 'Auction not found' };

      const auction = auctions[0];
      if (['SOLD', 'UNSOLD'].includes(auction.status)) {
        throw { statusCode: 400, message: `Auction is already finalized as ${auction.status}` };
      }

      await conn.execute("UPDATE auctions SET status = 'CLOSED' WHERE id = ?", [auctionId]);
      await logAudit(req.user.id, 'AUCTION_CLOSED', 'AUCTION', auctionId, { status: 'CLOSED' }, conn);

      return { id: auctionId, status: 'CLOSED' };
    });

    emitAuctionEvent('auction:status_changed', { id: auctionId, status: 'CLOSED' });
    return sendSuccess(res, result, 'Auction bidding closed. Ready for final hammer/decision.');
  } catch (err) {
    next(err);
  }
}

/**
 * Sell player to the highest bidder (Admin only)
 * Executes fully atomic transaction with row locking
 */
async function sellPlayer(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);

    const conn = await getConnection();
    try {
      await conn.beginTransaction();

      // 1. Lock auction record
      const [auctions] = await conn.execute(
        'SELECT * FROM auctions WHERE id = ? FOR UPDATE',
        [auctionId]
      );

      if (auctions.length === 0) {
        await conn.rollback();
        return sendError(res, 'Auction not found.', 404);
      }

      const auction = auctions[0];

      // Verify auction is eligible for selling
      if (auction.status === 'SOLD') {
        await conn.rollback();
        return sendError(res, 'This auction has already been finalized as SOLD. Duplicate sale prevented.', 400);
      }

      if (auction.status === 'UNSOLD') {
        await conn.rollback();
        return sendError(res, 'This auction was already marked UNSOLD.', 400);
      }

      if (!auction.highest_bid_team_id || Number(auction.current_bid) <= 0) {
        await conn.rollback();
        return sendError(res, 'Cannot sell player because no valid bids have been placed. You may mark the player UNSOLD instead.', 400);
      }

      const winningTeamId = auction.highest_bid_team_id;
      const finalPrice = Number(auction.current_bid);
      const playerId = auction.player_id;

      // 2. Lock player record and verify not already purchased
      const [players] = await conn.execute('SELECT * FROM players WHERE id = ? FOR UPDATE', [playerId]);
      if (players.length === 0) {
        await conn.rollback();
        return sendError(res, 'Player record not found.', 404);
      }

      const player = players[0];
      if (player.status === 'SOLD') {
        await conn.rollback();
        return sendError(res, 'This player is already recorded as SOLD in another purchase.', 400);
      }

      const [existingPurchase] = await conn.execute('SELECT id FROM purchases WHERE player_id = ? FOR UPDATE', [playerId]);
      if (existingPurchase.length > 0) {
        await conn.rollback();
        return sendError(res, 'A purchase ledger entry already exists for this player.', 400);
      }

      // 3. Lock team record and verify purse
      const [teams] = await conn.execute('SELECT * FROM teams WHERE id = ? FOR UPDATE', [winningTeamId]);
      if (teams.length === 0) {
        await conn.rollback();
        return sendError(res, 'Winning team not found.', 404);
      }

      const team = teams[0];
      const remainingPurse = Number(team.remaining_purse);

      if (remainingPurse < finalPrice) {
        await conn.rollback();
        return sendError(res, `Winning team ${team.team_name} does not have sufficient remaining purse (Remaining: ₹${(remainingPurse/10000000).toFixed(2)} Cr, Final Price: ₹${(finalPrice/10000000).toFixed(2)} Cr).`, 400);
      }

      // 4. Insert purchase record
      const [purchaseResult] = await conn.execute(`
        INSERT INTO purchases (auction_id, player_id, team_id, final_price, purchased_at)
        VALUES (?, ?, ?, ?, NOW())
      `, [auctionId, playerId, winningTeamId, finalPrice]);

      // 5. Deduct purse from team
      const newRemainingPurse = remainingPurse - finalPrice;
      await conn.execute('UPDATE teams SET remaining_purse = ? WHERE id = ?', [newRemainingPurse, winningTeamId]);

      // 6. Update player status to SOLD
      await conn.execute("UPDATE players SET status = 'SOLD' WHERE id = ?", [playerId]);

      // 7. Update auction status to SOLD
      await conn.execute("UPDATE auctions SET status = 'SOLD', closed_at = NOW() WHERE id = ?", [auctionId]);

      // 8. Mark highest bid as WINNING
      await conn.execute(
        "UPDATE bids SET bid_status = 'WINNING' WHERE auction_id = ? AND team_id = ? AND bid_amount = ?",
        [auctionId, winningTeamId, finalPrice]
      );

      // 9. Audit log
      await logAudit(req.user.id, 'PLAYER_SOLD', 'PURCHASE', purchaseResult.insertId, {
        auction_id: auctionId,
        player_id: playerId,
        player_name: player.player_name,
        team_id: winningTeamId,
        team_name: team.team_name,
        final_price: finalPrice,
        remaining_purse: newRemainingPurse
      }, conn);

      await conn.commit();

      const soldPayload = {
        auction_id: auctionId,
        purchase_id: purchaseResult.insertId,
        player: {
          id: player.id,
          name: player.player_name,
          role: player.role,
          image_url: player.image_url
        },
        winning_team: {
          id: team.id,
          name: team.team_name,
          code: team.team_code,
          logo_url: team.logo_url,
          remaining_purse: newRemainingPurse
        },
        final_price: finalPrice
      };

      emitAuctionEvent('auction:player_sold', soldPayload);

      return sendSuccess(res, soldPayload, `Player ${player.player_name} SOLD to ${team.team_name} for ₹${(finalPrice/10000000).toFixed(2)} Cr!`);
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Mark player UNSOLD (Admin only)
 */
async function markUnsold(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);

    const conn = await getConnection();
    try {
      await conn.beginTransaction();

      const [auctions] = await conn.execute('SELECT * FROM auctions WHERE id = ? FOR UPDATE', [auctionId]);
      if (auctions.length === 0) {
        await conn.rollback();
        return sendError(res, 'Auction not found.', 404);
      }

      const auction = auctions[0];
      if (auction.status === 'SOLD') {
        await conn.rollback();
        return sendError(res, 'Cannot mark as unsold because this player has already been sold.', 400);
      }

      // Update player to UNSOLD
      await conn.execute("UPDATE players SET status = 'UNSOLD' WHERE id = ?", [auction.player_id]);

      // Update auction to UNSOLD
      await conn.execute("UPDATE auctions SET status = 'UNSOLD', closed_at = NOW() WHERE id = ?", [auctionId]);

      // Audit log
      await logAudit(req.user.id, 'PLAYER_UNSOLD', 'AUCTION', auctionId, {
        player_id: auction.player_id
      }, conn);

      await conn.commit();

      const unsoldPayload = {
        auction_id: auctionId,
        player_id: auction.player_id,
        status: 'UNSOLD'
      };

      emitAuctionEvent('auction:player_unsold', unsoldPayload);

      return sendSuccess(res, unsoldPayload, 'Player marked as UNSOLD.');
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Place a bid on an auction (Team User or Admin on behalf of authorized team)
 * Strict row-level transaction safety with pessimistic locking
 */
async function placeBid(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);
    const { team_id, bid_amount } = req.body;

    const teamId = parseInt(team_id, 10);
    const bidAmount = Number(bid_amount);

    if (!teamId || isNaN(teamId)) {
      return sendError(res, 'A valid team_id is required to place a bid.', 400);
    }

    if (!bidAmount || isNaN(bidAmount) || bidAmount <= 0) {
      return sendError(res, 'A valid positive bid_amount is required.', 400);
    }

    // Role check: TEAM_USER can ONLY bid for their assigned team
    if (req.user.role === 'TEAM_USER' && req.user.team_id !== teamId) {
      return sendError(res, 'Access denied. You cannot place bids for another team.', 403);
    }

    const conn = await getConnection();
    try {
      await conn.beginTransaction();

      // 1. Lock auction record
      const [auctions] = await conn.execute(
        'SELECT a.*, p.player_name, p.base_price FROM auctions a JOIN players p ON a.player_id = p.id WHERE a.id = ? FOR UPDATE',
        [auctionId]
      );

      if (auctions.length === 0) {
        await conn.rollback();
        return sendError(res, 'Auction not found.', 404);
      }

      const auction = auctions[0];

      // 2. Verify auction is OPEN
      if (auction.status !== 'OPEN') {
        await conn.rollback();
        return sendError(res, `Cannot place bid. Bidding is currently ${auction.status}. Bids are only accepted when auction is OPEN.`, 400);
      }

      // 3. Fetch auction settings
      const [settingsRows] = await conn.execute('SELECT * FROM auction_settings LIMIT 1 FOR UPDATE');
      const settings = settingsRows[0] || {
        minimum_bid_increment: 2000000.00,
        maximum_squad_size: 25,
        allow_self_outbid: 0
      };

      const minIncrement = Number(settings.minimum_bid_increment);
      const maxSquadSize = Number(settings.maximum_squad_size);
      const allowSelfOutbid = Boolean(settings.allow_self_outbid);

      // 4. Verify team is not outbidding itself
      if (!allowSelfOutbid && auction.highest_bid_team_id === teamId) {
        await conn.rollback();
        return sendError(res, 'Your team is already the highest bidder for this player.', 400);
      }

      const currentBid = Number(auction.current_bid);
      const basePrice = Number(auction.base_price);

      // 5. Validate bid amount against base price and minimum increment
      let minimumRequiredBid = 0;
      if (currentBid === 0) {
        minimumRequiredBid = basePrice;
      } else {
        minimumRequiredBid = currentBid + minIncrement;
      }

      if (bidAmount < minimumRequiredBid) {
        await conn.rollback();
        return sendError(res, `Bid of ₹${(bidAmount/10000000).toFixed(2)} Cr is too low. Minimum required bid is ₹${(minimumRequiredBid/10000000).toFixed(2)} Cr (Current: ₹${(currentBid/10000000).toFixed(2)} Cr, Increment: ₹${(minIncrement/100000).toFixed(2)} L).`, 400);
      }

      // 6. Lock and validate team budget
      const [teams] = await conn.execute(
        'SELECT id, team_name, team_code, remaining_purse FROM teams WHERE id = ? FOR UPDATE',
        [teamId]
      );

      if (teams.length === 0) {
        await conn.rollback();
        return sendError(res, 'Team not found.', 404);
      }

      const team = teams[0];
      const remainingPurse = Number(team.remaining_purse);

      if (bidAmount > remainingPurse) {
        await conn.rollback();
        return sendError(res, `Insufficient funds! Team ${team.team_name} only has ₹${(remainingPurse/10000000).toFixed(2)} Cr remaining in purse.`, 400);
      }

      // 7. Check squad limit
      const [squadRows] = await conn.execute(
        'SELECT COUNT(*) as squad_count FROM purchases WHERE team_id = ? FOR UPDATE',
        [teamId]
      );
      const currentSquadCount = Number(squadRows[0].squad_count || 0);

      if (currentSquadCount >= maxSquadSize) {
        await conn.rollback();
        return sendError(res, `Team ${team.team_name} has reached the maximum squad limit of ${maxSquadSize} players.`, 400);
      }

      // 8. Mark previous bids as OUTBID
      await conn.execute(
        "UPDATE bids SET bid_status = 'OUTBID' WHERE auction_id = ? AND bid_status = 'VALID'",
        [auctionId]
      );

      // 9. Insert new bid record
      const [bidResult] = await conn.execute(`
        INSERT INTO bids (auction_id, team_id, bid_amount, bid_status, created_at)
        VALUES (?, ?, ?, 'VALID', NOW())
      `, [auctionId, teamId, bidAmount]);

      // 10. Update auction highest bid and team
      await conn.execute(`
        UPDATE auctions
        SET current_bid = ?, highest_bid_team_id = ?
        WHERE id = ?
      `, [bidAmount, teamId, auctionId]);

      // 11. Audit log
      await logAudit(req.user.id, 'BID_PLACED', 'BID', bidResult.insertId, {
        auction_id: auctionId,
        team_id: teamId,
        team_name: team.team_name,
        bid_amount: bidAmount
      }, conn);

      await conn.commit();

      const acceptedBidData = {
        bid_id: bidResult.insertId,
        auction_id: auctionId,
        bid_amount: bidAmount,
        team: {
          id: team.id,
          name: team.team_name,
          code: team.team_code
        },
        player_name: auction.player_name,
        created_at: new Date()
      };

      // Broadcast bid to all connected clients via Socket.IO
      emitAuctionEvent('auction:bid_placed', acceptedBidData);

      return sendSuccess(res, acceptedBidData, `Bid of ₹${(bidAmount/10000000).toFixed(2)} Cr by ${team.team_name} accepted!`, 201);
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    next(err);
  }
}

/**
 * Get bid history for a specific auction
 */
async function getAuctionBids(req, res, next) {
  try {
    const auctionId = parseInt(req.params.id, 10);
    const bids = await query(`
      SELECT b.id, b.auction_id, b.bid_amount, b.bid_status, b.created_at,
             t.id as team_id, t.team_name, t.team_code, t.logo_url
      FROM bids b
      JOIN teams t ON b.team_id = t.id
      WHERE b.auction_id = ?
      ORDER BY b.created_at DESC
    `, [auctionId]);

    return sendSuccess(res, bids.map(b => ({
      id: b.id,
      auction_id: b.auction_id,
      bid_amount: Number(b.bid_amount),
      bid_status: b.bid_status,
      created_at: b.created_at,
      team: {
        id: b.team_id,
        name: b.team_name,
        code: b.team_code,
        logo_url: b.logo_url
      }
    })));
  } catch (err) {
    next(err);
  }
}

/**
 * Get global bid history across auctions
 */
async function getAllBidsHistory(req, res, next) {
  try {
    const { team_id, auction_id, limit = 100 } = req.query;
    let sql = `
      SELECT b.id, b.auction_id, b.bid_amount, b.bid_status, b.created_at,
             t.id as team_id, t.team_name, t.team_code, t.logo_url,
             p.id as player_id, p.player_name, p.role as player_role, p.image_url as player_image
      FROM bids b
      JOIN teams t ON b.team_id = t.id
      JOIN auctions a ON b.auction_id = a.id
      JOIN players p ON a.player_id = p.id
      WHERE 1=1
    `;
    const params = [];
    if (team_id) {
      sql += ' AND b.team_id = ?';
      params.push(parseInt(team_id, 10));
    }
    if (auction_id) {
      sql += ' AND b.auction_id = ?';
      params.push(parseInt(auction_id, 10));
    }
    sql += ' ORDER BY b.created_at DESC LIMIT ?';
    params.push(parseInt(limit, 10) || 100);

    const rows = await query(sql, params);
    return sendSuccess(res, rows.map(b => ({
      id: b.id,
      auction_id: b.auction_id,
      bid_amount: Number(b.bid_amount),
      bid_status: b.bid_status,
      created_at: b.created_at,
      team: {
        id: b.team_id,
        name: b.team_name,
        code: b.team_code,
        logo_url: b.logo_url
      },
      player: {
        id: b.player_id,
        name: b.player_name,
        role: b.player_role,
        image_url: b.player_image
      }
    })));
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllAuctions,
  getCurrentAuction,
  getAuctionById,
  createAuction,
  startAuction,
  pauseAuction,
  resumeAuction,
  closeAuction,
  sellPlayer,
  markUnsold,
  placeBid,
  getAuctionBids,
  getAllBidsHistory
};
