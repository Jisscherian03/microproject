const { query } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/response');

/**
 * Get all purchase ledger records with search and filter
 */
async function getAllPurchases(req, res, next) {
  try {
    const { team_id, role, search = '', page = 1, limit = 50 } = req.query;

    let whereClauses = ['1=1'];
    let params = [];

    if (team_id) {
      whereClauses.push('pur.team_id = ?');
      params.push(parseInt(team_id, 10));
    }

    if (role) {
      whereClauses.push('p.role = ?');
      params.push(role.trim());
    }

    if (search.trim()) {
      whereClauses.push('(p.player_name LIKE ? OR t.team_name LIKE ? OR t.team_code LIKE ?)');
      params.push(`%${search.trim()}%`, `%${search.trim()}%`, `%${search.trim()}%`);
    }

    const whereSql = whereClauses.join(' AND ');

    // Total count
    const [countRow] = await query(`
      SELECT COUNT(*) as total
      FROM purchases pur
      JOIN players p ON pur.player_id = p.id
      JOIN teams t ON pur.team_id = t.id
      WHERE ${whereSql}
    `, params);

    const total = countRow.total;
    const pageNum = Math.max(1, parseInt(page, 10));
    const pageSize = Math.max(1, Math.min(100, parseInt(limit, 10)));
    const offset = (pageNum - 1) * pageSize;

    const purchases = await query(`
      SELECT pur.id, pur.auction_id, pur.final_price, pur.purchased_at,
             p.id as player_id, p.player_name, p.role, p.nationality, p.base_price, p.image_url,
             t.id as team_id, t.team_name, t.team_code, t.logo_url as team_logo
      FROM purchases pur
      JOIN players p ON pur.player_id = p.id
      JOIN teams t ON pur.team_id = t.id
      WHERE ${whereSql}
      ORDER BY pur.purchased_at DESC
      LIMIT ? OFFSET ?
    `, [...params, pageSize, offset]);

    return sendSuccess(res, {
      purchases: purchases.map(pur => ({
        id: pur.id,
        auction_id: pur.auction_id,
        final_price: Number(pur.final_price),
        purchased_at: pur.purchased_at,
        player: {
          id: pur.player_id,
          name: pur.player_name,
          role: pur.role,
          nationality: pur.nationality,
          base_price: Number(pur.base_price),
          image_url: pur.image_url
        },
        team: {
          id: pur.team_id,
          name: pur.team_name,
          code: pur.team_code,
          logo_url: pur.team_logo
        }
      })),
      pagination: {
        page: pageNum,
        limit: pageSize,
        total,
        totalPages: Math.ceil(total / pageSize)
      }
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getAllPurchases
};
