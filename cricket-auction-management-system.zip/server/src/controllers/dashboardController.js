const { query } = require('../config/db');
const { sendSuccess } = require('../utils/response');

/**
 * Get aggregated live dashboard statistics from database
 */
async function getStats(req, res, next) {
  try {
    // 1. Teams count
    const [teamCountRow] = await query('SELECT COUNT(*) as total_teams FROM teams');
    const totalTeams = teamCountRow.total_teams;

    // 2. Players counts
    const [playerCountRow] = await query(`
      SELECT
        COUNT(*) as total_players,
        SUM(CASE WHEN status = 'SOLD' THEN 1 ELSE 0 END) as players_sold,
        SUM(CASE WHEN status = 'UNSOLD' THEN 1 ELSE 0 END) as players_unsold,
        SUM(CASE WHEN status = 'AVAILABLE' THEN 1 ELSE 0 END) as players_available,
        SUM(CASE WHEN status = 'IN_AUCTION' THEN 1 ELSE 0 END) as players_in_auction
      FROM players
    `);

    const totalPlayers = playerCountRow.total_players || 0;
    const playersSold = playerCountRow.players_sold || 0;
    const playersUnsold = playerCountRow.players_unsold || 0;
    const playersRemaining = (playerCountRow.players_available || 0) + (playerCountRow.players_in_auction || 0);

    // 3. Total auction spending from purchases
    const [spendingRow] = await query('SELECT COALESCE(SUM(final_price), 0) as total_spending FROM purchases');
    const totalSpending = Number(spendingRow.total_spending || 0);

    // 4. Current auction status
    const currentAuctionRows = await query(`
      SELECT a.id, a.status, a.current_bid, a.player_id, a.highest_bid_team_id,
             p.player_name, p.role, p.nationality, p.base_price, p.image_url,
             t.team_name as leading_team_name, t.team_code as leading_team_code
      FROM auctions a
      JOIN players p ON a.player_id = p.id
      LEFT JOIN teams t ON a.highest_bid_team_id = t.id
      WHERE a.status IN ('OPEN', 'PAUSED', 'READY', 'DRAFT')
      ORDER BY a.updated_at DESC
      LIMIT 1
    `);

    const currentAuction = currentAuctionRows.length > 0 ? {
      id: currentAuctionRows[0].id,
      status: currentAuctionRows[0].status,
      current_bid: Number(currentAuctionRows[0].current_bid),
      player: {
        id: currentAuctionRows[0].player_id,
        name: currentAuctionRows[0].player_name,
        role: currentAuctionRows[0].role,
        nationality: currentAuctionRows[0].nationality,
        base_price: Number(currentAuctionRows[0].base_price),
        image_url: currentAuctionRows[0].image_url
      },
      leading_team: currentAuctionRows[0].highest_bid_team_id ? {
        id: currentAuctionRows[0].highest_bid_team_id,
        name: currentAuctionRows[0].leading_team_name,
        code: currentAuctionRows[0].leading_team_code
      } : null
    } : null;

    // 5. Team purses & spending overview
    const teamsOverview = await query(`
      SELECT t.id, t.team_name, t.team_code, t.logo_url,
             t.initial_purse, t.remaining_purse,
             (t.initial_purse - t.remaining_purse) as total_spent,
             COUNT(p.id) as squad_count
      FROM teams t
      LEFT JOIN purchases p ON t.id = p.team_id
      GROUP BY t.id
      ORDER BY total_spent DESC, t.team_name ASC
    `);

    return sendSuccess(res, {
      summary: {
        total_teams: totalTeams,
        total_players: totalPlayers,
        players_sold: playersSold,
        players_unsold: playersUnsold,
        players_remaining: playersRemaining,
        total_spending: totalSpending,
        auction_status: currentAuction ? currentAuction.status : 'IDLE'
      },
      current_auction: currentAuction,
      teams_overview: teamsOverview.map(t => ({
        id: t.id,
        name: t.team_name,
        code: t.team_code,
        logo_url: t.logo_url,
        initial_purse: Number(t.initial_purse),
        remaining_purse: Number(t.remaining_purse),
        total_spent: Number(t.total_spent),
        squad_count: Number(t.squad_count)
      }))
    });
  } catch (err) {
    next(err);
  }
}

/**
 * Get recent activity log (recent bids and auction milestones)
 */
async function getActivity(req, res, next) {
  try {
    const limit = parseInt(req.query.limit, 10) || 15;

    const recentBids = await query(`
      SELECT b.id, b.auction_id, b.bid_amount, b.bid_status, b.created_at,
             t.team_name, t.team_code,
             p.player_name, p.role
      FROM bids b
      JOIN teams t ON b.team_id = t.id
      JOIN auctions a ON b.auction_id = a.id
      JOIN players p ON a.player_id = p.id
      ORDER BY b.created_at DESC
      LIMIT ?
    `, [limit]);

    const recentAuditLogs = await query(`
      SELECT a.id, a.action, a.entity_type, a.entity_id, a.details, a.created_at,
             u.username
      FROM audit_logs a
      LEFT JOIN users u ON a.user_id = u.id
      ORDER BY a.created_at DESC
      LIMIT ?
    `, [limit]);

    return sendSuccess(res, {
      recent_bids: recentBids.map(b => ({
        id: b.id,
        auction_id: b.auction_id,
        bid_amount: Number(b.bid_amount),
        bid_status: b.bid_status,
        created_at: b.created_at,
        team_name: b.team_name,
        team_code: b.team_code,
        player_name: b.player_name,
        player_role: b.role
      })),
      recent_logs: recentAuditLogs.map(l => ({
        id: l.id,
        action: l.action,
        entity_type: l.entity_type,
        entity_id: l.entity_id,
        details: typeof l.details === 'string' ? JSON.parse(l.details || '{}') : l.details,
        created_at: l.created_at,
        username: l.username || 'System'
      }))
    });
  } catch (err) {
    next(err);
  }
}

module.exports = {
  getStats,
  getActivity
};
