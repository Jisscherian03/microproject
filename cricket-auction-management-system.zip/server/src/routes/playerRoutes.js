const express = require('express');
const router = express.Router();
const playerController = require('../controllers/playerController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { body } = require('express-validator');
const { validateRequest } = require('../middleware/validator');

router.get('/', playerController.getAllPlayers);
router.get('/:id', playerController.getPlayerById);

router.post(
  '/',
  authenticateToken,
  requireAdmin,
  [
    body('player_name').trim().notEmpty().withMessage('Player name is required'),
    body('nationality').trim().notEmpty().withMessage('Nationality is required'),
    body('role').isIn(['Batter', 'Bowler', 'All-rounder', 'Wicketkeeper']).withMessage('Role must be Batter, Bowler, All-rounder, or Wicketkeeper'),
    body('base_price').isNumeric().withMessage('Base price must be a valid number'),
    validateRequest
  ],
  playerController.createPlayer
);

router.put(
  '/:id',
  authenticateToken,
  requireAdmin,
  [
    body('player_name').optional().trim().notEmpty().withMessage('Player name cannot be empty'),
    body('role').optional().isIn(['Batter', 'Bowler', 'All-rounder', 'Wicketkeeper']).withMessage('Invalid role'),
    body('base_price').optional().isNumeric().withMessage('Base price must be a valid number'),
    validateRequest
  ],
  playerController.updatePlayer
);

router.delete('/:id', authenticateToken, requireAdmin, playerController.deletePlayer);

module.exports = router;
