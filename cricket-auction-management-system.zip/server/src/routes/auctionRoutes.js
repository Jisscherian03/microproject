const express = require('express');
const router = express.Router();
const auctionController = require('../controllers/auctionController');
const { authenticateToken, requireAdmin, requireTeamAccess } = require('../middleware/auth');
const { body } = require('express-validator');
const { validateRequest } = require('../middleware/validator');

// Current auction endpoint (placed before :id route)
router.get('/current', auctionController.getCurrentAuction);

// All bids history endpoint
router.get('/bids/history', auctionController.getAllBidsHistory);

// All auctions
router.get('/', auctionController.getAllAuctions);

// Single auction details & bids
router.get('/:id', auctionController.getAuctionById);
router.get('/:id/bids', auctionController.getAuctionBids);

// Admin controls
router.post(
  '/',
  authenticateToken,
  requireAdmin,
  [
    body('player_id').isInt({ min: 1 }).withMessage('Valid player_id is required'),
    validateRequest
  ],
  auctionController.createAuction
);

router.post('/:id/start', authenticateToken, requireAdmin, auctionController.startAuction);
router.post('/:id/pause', authenticateToken, requireAdmin, auctionController.pauseAuction);
router.post('/:id/resume', authenticateToken, requireAdmin, auctionController.resumeAuction);
router.post('/:id/close', authenticateToken, requireAdmin, auctionController.closeAuction);
router.post('/:id/sell', authenticateToken, requireAdmin, auctionController.sellPlayer);
router.post('/:id/unsold', authenticateToken, requireAdmin, auctionController.markUnsold);

// Place a bid (Authenticated team users or admin)
router.post(
  '/:id/bids',
  authenticateToken,
  requireTeamAccess('team_id'),
  [
    body('team_id').isInt({ min: 1 }).withMessage('team_id must be a valid integer'),
    body('bid_amount').isNumeric().withMessage('bid_amount must be a valid number'),
    validateRequest
  ],
  auctionController.placeBid
);

module.exports = router;
