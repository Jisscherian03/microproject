const express = require('express');
const router = express.Router();
const teamController = require('../controllers/teamController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { body } = require('express-validator');
const { validateRequest } = require('../middleware/validator');

router.get('/', teamController.getAllTeams);
router.get('/:id', teamController.getTeamById);
router.get('/:id/squad', teamController.getTeamSquad);
router.get('/:id/summary', teamController.getTeamSummary);

router.post(
  '/',
  authenticateToken,
  requireAdmin,
  [
    body('team_name').trim().notEmpty().withMessage('Team name is required'),
    body('team_code').trim().isLength({ min: 2, max: 10 }).withMessage('Team code must be between 2 and 10 characters'),
    body('initial_purse').optional().isNumeric().withMessage('Initial purse must be a valid number'),
    validateRequest
  ],
  teamController.createTeam
);

router.put(
  '/:id',
  authenticateToken,
  requireAdmin,
  [
    body('team_name').optional().trim().notEmpty().withMessage('Team name cannot be empty'),
    body('team_code').optional().trim().isLength({ min: 2, max: 10 }).withMessage('Team code must be between 2 and 10 characters'),
    body('initial_purse').optional().isNumeric().withMessage('Initial purse must be a valid number'),
    validateRequest
  ],
  teamController.updateTeam
);

router.delete('/:id', authenticateToken, requireAdmin, teamController.deleteTeam);

module.exports = router;
