const express = require('express');
const router = express.Router();
const reportController = require('../controllers/reportController');

router.get('/overview', reportController.getOverview);
router.get('/team-spending', reportController.getTeamSpending);
router.get('/sold-players', reportController.getSoldPlayers);
router.get('/unsold-players', reportController.getUnsoldPlayers);
router.get('/role-breakdown', reportController.getRoleBreakdown);

module.exports = router;
