const express = require('express');
const router = express.Router();
const settingController = require('../controllers/settingController');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { body } = require('express-validator');
const { validateRequest } = require('../middleware/validator');

router.get('/', settingController.getSettings);

router.put(
  '/',
  authenticateToken,
  requireAdmin,
  [
    body('minimum_bid_increment').optional().isNumeric().withMessage('Minimum bid increment must be numeric'),
    body('maximum_squad_size').optional().isInt({ min: 11 }).withMessage('Maximum squad size must be at least 11'),
    body('allow_self_outbid').optional().isBoolean().withMessage('allow_self_outbid must be a boolean'),
    validateRequest
  ],
  settingController.updateSettings
);

module.exports = router;
