const express = require('express');
const router = express.Router();

const authRoutes = require('./authRoutes');
const dashboardRoutes = require('./dashboardRoutes');
const teamRoutes = require('./teamRoutes');
const playerRoutes = require('./playerRoutes');
const auctionRoutes = require('./auctionRoutes');
const purchaseRoutes = require('./purchaseRoutes');
const reportRoutes = require('./reportRoutes');
const settingRoutes = require('./settingRoutes');
const { getIsConnected } = require('../config/db');

// Health Check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    database: {
      connected: getIsConnected(),
      name: process.env.DB_NAME || 'cricket_auction_db'
    }
  });
});

// Mount modular sub-routers
router.use('/auth', authRoutes);
router.use('/dashboard', dashboardRoutes);
router.use('/teams', teamRoutes);
router.use('/players', playerRoutes);
router.use('/auctions', auctionRoutes);
router.use('/purchases', purchaseRoutes);
router.use('/reports', reportRoutes);
router.use('/settings', settingRoutes);

module.exports = router;
