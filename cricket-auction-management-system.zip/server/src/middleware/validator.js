const { validationResult } = require('express-validator');
const { sendError } = require('../utils/response');

function validateRequest(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const extractedErrors = errors.array().map(err => ({
      field: err.path || err.param,
      message: err.msg
    }));
    return sendError(res, 'Validation failed: ' + extractedErrors.map(e => e.message).join(', '), 400, extractedErrors);
  }
  next();
}

module.exports = {
  validateRequest
};
