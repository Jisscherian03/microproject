const { sendError } = require('../utils/response');

function errorHandler(err, req, res, next) {
  console.error('[API Error]', {
    method: req.method,
    url: req.originalUrl,
    error: err.message,
    code: err.code
  });

  // Handle MySQL specific errors gracefully
  if (err.code === 'ER_DUP_ENTRY') {
    return sendError(res, 'A record with that unique value (e.g. username, team code, or player purchase) already exists.', 409);
  }

  if (err.code === 'ER_ROW_IS_REFERENCED_2' || err.code === 'ER_NO_REFERENCED_ROW_2') {
    return sendError(res, 'Database integrity violation: Cannot delete or update a record that is linked to existing bids, auctions, or purchases.', 400);
  }

  if (err.code === 'ECONNREFUSED' || err.code === 'PROTOCOL_CONNECTION_LOST') {
    return sendError(res, 'Database connection error. Please ensure the MySQL server is running.', 503);
  }

  const statusCode = err.statusCode || err.status || 500;
  const message = err.message || 'An unexpected internal server error occurred.';

  return sendError(res, message, statusCode);
}

module.exports = errorHandler;
