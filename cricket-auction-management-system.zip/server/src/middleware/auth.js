const jwt = require('jsonwebtoken');
const { sendError } = require('../utils/response');

const JWT_SECRET = process.env.JWT_SECRET || 'cricket_auction_secret_key_change_in_production_mca_2026';

/**
 * Authenticate incoming requests via Bearer JWT token
 */
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  let token = null;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    token = authHeader.split(' ')[1];
  } else if (req.query && req.query.token) {
    token = req.query.token;
  }

  if (!token) {
    return sendError(res, 'Authentication required. No token provided.', 401);
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded; // { id, username, role, team_id }
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return sendError(res, 'Session expired. Please log in again.', 401);
    }
    return sendError(res, 'Invalid authentication token.', 401);
  }
}

/**
 * Require ADMIN role
 */
function requireAdmin(req, res, next) {
  if (!req.user) {
    return sendError(res, 'Authentication required.', 401);
  }

  if (req.user.role !== 'ADMIN') {
    return sendError(res, 'Access denied. Administrator privileges required.', 403);
  }

  next();
}

/**
 * Authorize team user access.
 * ADMIN has universal access.
 * TEAM_USER can only access their assigned team.
 */
function requireTeamAccess(paramName = 'team_id') {
  return (req, res, next) => {
    if (!req.user) {
      return sendError(res, 'Authentication required.', 401);
    }

    if (req.user.role === 'ADMIN') {
      return next();
    }

    const requestedTeamId = parseInt(req.body[paramName] || req.params[paramName] || req.query[paramName], 10);

    if (!req.user.team_id) {
      return sendError(res, 'Your user account is not associated with any team.', 403);
    }

    if (requestedTeamId && requestedTeamId !== req.user.team_id) {
      return sendError(res, 'Access denied. You can only perform actions for your assigned team.', 403);
    }

    next();
  };
}

module.exports = {
  authenticateToken,
  requireAdmin,
  requireTeamAccess,
  JWT_SECRET
};
