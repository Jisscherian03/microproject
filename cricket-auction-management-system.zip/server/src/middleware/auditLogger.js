const { query } = require('../config/db');

async function logAudit(userId, action, entityType, entityId, details = {}, connection = null) {
  try {
    const detailsJson = typeof details === 'object' ? JSON.stringify(details) : details;
    const sql = `
      INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details)
      VALUES (?, ?, ?, ?, ?)
    `;
    const params = [userId || null, action, entityType, entityId || null, detailsJson];

    if (connection) {
      await connection.execute(sql, params);
    } else {
      await query(sql, params);
    }
  } catch (err) {
    console.warn('[AuditLog Warning] Failed to record audit log:', err.message);
  }
}

module.exports = {
  logAudit
};
