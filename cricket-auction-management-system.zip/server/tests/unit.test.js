import { describe, it, expect } from 'vitest';
const { formatIndianCurrency } = require('../src/utils/currencyFormatter');

describe('Currency Formatter Utility', () => {
  it('formats amounts in Crores (>= ₹1 Cr) correctly', () => {
    expect(formatIndianCurrency(10000000)).toBe('₹1.00 Cr');
    expect(formatIndianCurrency(125000000)).toBe('₹12.50 Cr');
    expect(formatIndianCurrency(1000000000)).toBe('₹100.00 Cr');
    expect(formatIndianCurrency(247500000)).toBe('₹24.75 Cr');
  });

  it('formats amounts in Lakhs (>= ₹1 L and < ₹1 Cr) correctly', () => {
    expect(formatIndianCurrency(100000)).toBe('₹1.00 L');
    expect(formatIndianCurrency(2000000)).toBe('₹20.00 L');
    expect(formatIndianCurrency(5000000)).toBe('₹50.00 L');
    expect(formatIndianCurrency(7500000)).toBe('₹75.00 L');
  });

  it('formats small amounts (< ₹1 L) with standard comma formatting', () => {
    expect(formatIndianCurrency(50000)).toBe('₹50,000.00');
    expect(formatIndianCurrency(0)).toBe('₹0.00');
  });

  it('handles null, undefined, or invalid inputs safely without throwing', () => {
    expect(formatIndianCurrency(null)).toBe('₹0.00');
    expect(formatIndianCurrency(undefined)).toBe('₹0.00');
    expect(formatIndianCurrency(NaN)).toBe('₹0.00');
  });

  it('formats negative balances with minus sign correctly', () => {
    expect(formatIndianCurrency(-50000000)).toBe('-₹5.00 Cr');
  });
});
