import { describe, it, expect, vi } from 'vitest';
const jwt = require('jsonwebtoken');
const { authenticateToken, requireAdmin, requireTeamAccess, JWT_SECRET } = require('../src/middleware/auth');

describe('Authentication & Authorization Middleware', () => {
  const adminPayload = { id: 1, username: 'admin', role: 'ADMIN', team_id: null };
  const cskUserPayload = { id: 2, username: 'csk_owner', role: 'TEAM_USER', team_id: 1 };
  const miUserPayload = { id: 3, username: 'mi_owner', role: 'TEAM_USER', team_id: 2 };

  it('rejects requests without authentication token with 401', () => {
    const req = { headers: {} };
    const res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn()
    };
    const next = vi.fn();

    authenticateToken(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ success: false }));
    expect(next).not.toHaveBeenCalled();
  });

  it('rejects requests with an invalid token with 401', () => {
    const req = { headers: { authorization: 'Bearer invalid.fake.token' } };
    const res = {
      status: vi.fn().mockReturnThis(),
      json: vi.fn()
    };
    const next = vi.fn();

    authenticateToken(req, res, next);

    expect(res.status).toHaveBeenCalledWith(401);
    expect(next).not.toHaveBeenCalled();
  });

  it('authenticates valid JWT token and sets req.user', () => {
    const validToken = jwt.sign(adminPayload, JWT_SECRET, { expiresIn: '1h' });
    const req = { headers: { authorization: `Bearer ${validToken}` } };
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    const next = vi.fn();

    authenticateToken(req, res, next);

    expect(next).toHaveBeenCalled();
    expect(req.user).toBeDefined();
    expect(req.user.username).toBe('admin');
    expect(req.user.role).toBe('ADMIN');
  });

  it('requireAdmin allows ADMIN role to proceed', () => {
    const req = { user: adminPayload };
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    const next = vi.fn();

    requireAdmin(req, res, next);

    expect(next).toHaveBeenCalled();
  });

  it('requireAdmin blocks TEAM_USER role with 403 Forbidden', () => {
    const req = { user: cskUserPayload };
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    const next = vi.fn();

    requireAdmin(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
      success: false,
      error: expect.stringContaining('Administrator privileges required')
    }));
    expect(next).not.toHaveBeenCalled();
  });

  it('requireTeamAccess blocks team user trying to bid for another team', () => {
    const guard = requireTeamAccess('team_id');
    // CSK owner trying to act on team_id 2 (MI)
    const req = {
      user: cskUserPayload,
      body: { team_id: 2 },
      params: {},
      query: {}
    };
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    const next = vi.fn();

    guard(req, res, next);

    expect(res.status).toHaveBeenCalledWith(403);
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({
      success: false,
      error: expect.stringContaining('You can only perform actions for your assigned team')
    }));
    expect(next).not.toHaveBeenCalled();
  });

  it('requireTeamAccess permits team user acting on their own team', () => {
    const guard = requireTeamAccess('team_id');
    // CSK owner acting on team_id 1 (CSK)
    const req = {
      user: cskUserPayload,
      body: { team_id: 1 },
      params: {},
      query: {}
    };
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    const next = vi.fn();

    guard(req, res, next);

    expect(next).toHaveBeenCalled();
  });

  it('requireTeamAccess allows ADMIN to act for any team', () => {
    const guard = requireTeamAccess('team_id');
    const req = {
      user: adminPayload,
      body: { team_id: 2 },
      params: {},
      query: {}
    };
    const res = { status: vi.fn().mockReturnThis(), json: vi.fn() };
    const next = vi.fn();

    guard(req, res, next);

    expect(next).toHaveBeenCalled();
  });
});
