import api from './api';

export const auctionService = {
  getCurrent: () => api.get('/auctions/current'),
  getAll: () => api.get('/auctions'),
  getById: (id) => api.get(`/auctions/${id}`),
  getBids: (id) => api.get(`/auctions/${id}/bids`),
  getAllBids: (params = {}) => {
    const query = new URLSearchParams();
    Object.entries(params).forEach(([key, val]) => {
      if (val !== undefined && val !== null && val !== '') {
        query.append(key, val);
      }
    });
    return api.get(`/auctions/bids/history?${query.toString()}`);
  },
  create: (playerId) => api.post('/auctions', { player_id: playerId }),
  start: (id) => api.post(`/auctions/${id}/start`),
  pause: (id) => api.post(`/auctions/${id}/pause`),
  resume: (id) => api.post(`/auctions/${id}/resume`),
  close: (id) => api.post(`/auctions/${id}/close`),
  sell: (id) => api.post(`/auctions/${id}/sell`),
  markUnsold: (id) => api.post(`/auctions/${id}/unsold`),
  placeBid: (id, teamId, bidAmount) => api.post(`/auctions/${id}/bids`, { team_id: teamId, bid_amount: bidAmount })
};
