import api from './api';

export const dashboardService = {
  getStats: () => api.get('/dashboard/stats'),
  getActivity: (limit = 15) => api.get(`/dashboard/activity?limit=${limit}`)
};
