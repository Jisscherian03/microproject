import api from './api';

export const reportService = {
  getOverview: () => api.get('/reports/overview'),
  getTeamSpending: () => api.get('/reports/team-spending'),
  getSoldPlayers: () => api.get('/reports/sold-players'),
  getUnsoldPlayers: () => api.get('/reports/unsold-players'),
  getRoleBreakdown: () => api.get('/reports/role-breakdown')
};
