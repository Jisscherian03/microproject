import api from './api';

export const teamService = {
  getAll: () => api.get('/teams'),
  getById: (id) => api.get(`/teams/${id}`),
  getSquad: (id) => api.get(`/teams/${id}/squad`),
  getSummary: (id) => api.get(`/teams/${id}/summary`),
  create: (data) => api.post('/teams', data),
  update: (id, data) => api.put(`/teams/${id}`, data),
  delete: (id) => api.delete(`/teams/${id}`)
};
