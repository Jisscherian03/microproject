import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { io } from 'socket.io-client';
import confetti from 'canvas-confetti';
import { auctionService } from '../services/auctionService';
import { teamService } from '../services/teamService';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';

const AuctionContext = createContext(null);

export function AuctionProvider({ children }) {
  const { token, refreshUser } = useAuth();
  const { showToast } = useToast();

  const [currentAuction, setCurrentAuction] = useState(null);
  const [bids, setBids] = useState([]);
  const [teams, setTeams] = useState([]);
  const [socket, setSocket] = useState(null);
  const [isConnected, setIsConnected] = useState(false);
  const [loading, setLoading] = useState(true);

  // Fetch Authoritative Current Auction
  const fetchCurrentAuction = useCallback(async () => {
    try {
      const res = await auctionService.getCurrent();
      if (res.success && res.data) {
        setCurrentAuction(res.data);
        setBids(res.data.bids || []);
      } else {
        setCurrentAuction(null);
        setBids([]);
      }
    } catch (err) {
      console.warn('Failed to load current auction:', err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  // Fetch Teams for purse references
  const fetchTeams = useCallback(async () => {
    try {
      const res = await teamService.getAll();
      if (res.success && res.data) {
        setTeams(res.data);
      }
    } catch (err) {
      console.warn('Failed to load teams:', err.message);
    }
  }, []);

  // Initialize Socket.IO connection
  useEffect(() => {
    const socketInstance = io('/', {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 5,
      reconnectionDelay: 1000
    });

    socketInstance.on('connect', () => {
      setIsConnected(true);
      console.log('[Socket.IO] Connected to live auction feed');
    });

    socketInstance.on('disconnect', () => {
      setIsConnected(false);
      console.log('[Socket.IO] Disconnected from live auction feed');
    });

    // Real-time Event Listeners
    socketInstance.on('auction:bid_placed', (bidData) => {
      showToast(`⚡ New Bid: ₹${(bidData.bid_amount / 10000000).toFixed(2)} Cr by ${bidData.team.name}`, 'info');
      fetchCurrentAuction();
      fetchTeams();
      refreshUser();
    });

    socketInstance.on('auction:status_changed', (data) => {
      showToast(`Auction status changed to ${data.status}`, 'warning');
      fetchCurrentAuction();
    });

    socketInstance.on('auction:player_sold', (soldData) => {
      // Fire victory confetti!
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 }
      });
      showToast(`🔨 SOLD! ${soldData.player.name} bought by ${soldData.winning_team.name} for ₹${(soldData.final_price / 10000000).toFixed(2)} Cr!`, 'success', 6000);
      fetchCurrentAuction();
      fetchTeams();
      refreshUser();
    });

    socketInstance.on('auction:player_unsold', (unsoldData) => {
      showToast('Player marked as UNSOLD', 'warning');
      fetchCurrentAuction();
    });

    socketInstance.on('auction:created', () => {
      showToast('A new player has been brought to the auction block!', 'info');
      fetchCurrentAuction();
    });

    socketInstance.on('dashboard:refresh', () => {
      fetchTeams();
    });

    setSocket(socketInstance);

    return () => {
      socketInstance.disconnect();
    };
  }, [token, fetchCurrentAuction, fetchTeams, refreshUser, showToast]);

  // Initial Load & Fallback Polling (polls every 5s)
  useEffect(() => {
    fetchCurrentAuction();
    fetchTeams();

    const interval = setInterval(() => {
      fetchCurrentAuction();
      fetchTeams();
    }, 5000);

    return () => clearInterval(interval);
  }, [fetchCurrentAuction, fetchTeams]);

  const value = {
    currentAuction,
    bids,
    teams,
    socket,
    isConnected,
    loading,
    refreshAuction: fetchCurrentAuction,
    refreshTeams: fetchTeams
  };

  return (
    <AuctionContext.Provider value={value}>
      {children}
    </AuctionContext.Provider>
  );
}

export function useAuction() {
  const context = useContext(AuctionContext);
  if (!context) {
    throw new Error('useAuction must be used within an AuctionProvider');
  }
  return context;
}
