import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Gavel,
  Lock,
  User,
  AlertCircle,
  ArrowRight,
  Eye,
  EyeOff,
  Zap,
  ChevronDown,
  Sparkles,
  HelpCircle,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import './Login.css';

export default function Login() {
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { showToast } = useToast();

  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [selectedDemoId, setSelectedDemoId] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);

  // Accounts list for the Centered Quick Login Dropdown
  const allAccounts = [
    { id: 'admin', label: 'System Administrator (admin)', username: 'admin', password: 'Admin@123' },
    { id: 'csk', label: 'Chennai Super Kings (CSK)', username: 'csk_owner', password: 'Team@123' },
    { id: 'mi', label: 'Mumbai Indians (MI)', username: 'mi_owner', password: 'Team@123' },
    { id: 'rcb', label: 'Royal Challengers Bengaluru (RCB)', username: 'rcb_owner', password: 'Team@123' },
    { id: 'kkr', label: 'Kolkata Knight Riders (KKR)', username: 'kkr_owner', password: 'Team@123' },
    { id: 'rr', label: 'Rajasthan Royals (RR)', username: 'rr_owner', password: 'Team@123' },
    { id: 'srh', label: 'Sunrisers Hyderabad (SRH)', username: 'srh_owner', password: 'Team@123' },
    { id: 'dc', label: 'Delhi Capitals (DC)', username: 'dc_owner', password: 'Team@123' },
    { id: 'gt', label: 'Gujarat Titans (GT)', username: 'gt_owner', password: 'Team@123' }
  ];

  const from = location.state?.from?.pathname || '/dashboard';

  const handleLogin = async (e, customUser, customPass) => {
    if (e) e.preventDefault();
    const loginUser = (customUser || username).trim();
    const loginPass = customPass || password;

    if (!loginUser || !loginPass) {
      setErrorMsg('Please enter both username and password.');
      return;
    }

    setLoading(true);
    setErrorMsg('');

    try {
      const user = await login(loginUser, loginPass);
      showToast(`Welcome to Arena, ${user.username}!`, 'success');
      navigate(from, { replace: true });
    } catch (err) {
      setErrorMsg(err.message || 'Invalid username or password.');
    } finally {
      setLoading(false);
    }
  };

  const handleSelectAccount = (accountKey, autoSubmit = false) => {
    setSelectedDemoId(accountKey);
    if (!accountKey) return;

    const account = allAccounts.find(a => a.id === accountKey || a.username === accountKey);
    if (account) {
      setUsername(account.username);
      setPassword(account.password);
      setErrorMsg('');

      if (autoSubmit) {
        handleLogin(null, account.username, account.password);
      }
    }
  };

  return (
    <div className="arena-login-wrapper">
      {/* Stadium Lighting Effects */}
      <div className="arena-glow-blue" />
      <div className="arena-glow-gold" />
      <div className="arena-glow-crimson" />
      <div className="arena-grid-watermark" />

      {/* Centered Frosted-Glass Card */}
      <div className="arena-card">
        {/* Stadium Arena Header */}
        <div className="arena-header">
          {/* Live Arena Pill */}
          <div className="arena-live-pill">
            <span className="arena-live-dot" />
            <span className="arena-live-text">
              Live Sports Auction Arena
            </span>
          </div>

          {/* Gavel Logo */}
          <div className="arena-logo-box">
            <Gavel size={30} color="#FFFFFF" strokeWidth={2.2} />
          </div>

          <h1 className="arena-title">
            CRICKET AUCTION
          </h1>
          <p className="arena-subtitle">
            Auction Control & Franchise Hub
          </p>
        </div>

        {/* Error Alert Box */}
        {errorMsg && (
          <div className="arena-alert">
            <AlertCircle size={18} style={{ flexShrink: 0 }} />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Login Form */}
        <form onSubmit={handleLogin} className="arena-form">
          {/* Username Field with Inside User Icon */}
          <div className="arena-field">
            <label className="arena-label" style={{ marginBottom: '7px' }}>
              Username
            </label>
            <div className="arena-input-wrap">
              <input
                type="text"
                className="arena-input"
                placeholder="Enter username (e.g. admin)"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setSelectedDemoId('');
                }}
                disabled={loading}
              />
              <div className="arena-input-icon">
                <User size={18} />
              </div>
            </div>
          </div>

          {/* Password Field with Inside Lock Icon & Show/Hide Toggle */}
          <div className="arena-field">
            <div className="arena-label-row">
              <label className="arena-label">
                Password
              </label>
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="arena-toggle-pwd"
              >
                {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                <span>{showPassword ? 'Hide' : 'Show'}</span>
              </button>
            </div>
            <div className="arena-input-wrap">
              <input
                type={showPassword ? 'text' : 'password'}
                className="arena-input"
                placeholder="Enter password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  setSelectedDemoId('');
                }}
                disabled={loading}
              />
              <div className="arena-input-icon">
                <Lock size={18} />
              </div>
            </div>
          </div>

          {/* Options Row: Forgot Password */}
          <div className="arena-options-row">
            <button
              type="button"
              onClick={() => setShowForgotModal(true)}
              className="arena-forgot-link"
            >
              Forgot password?
            </button>
          </div>

          {/* High-Energy Vibrant Gradient Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="arena-btn-primary"
          >
            {loading ? (
              <span>Authenticating...</span>
            ) : (
              <>
                <span>Sign In to Arena</span>
                <ArrowRight size={18} />
              </>
            )}
          </button>
        </form>

        {/* CENTERED QUICK LOGIN SECTION */}
        <div className="arena-quick-section">
          {/* Centered Header */}
          <div className="arena-quick-header">
            <div className="arena-quick-title">
              <Zap size={16} color="#F59E0B" />
              <span>QUICK LOGIN</span>
            </div>
          </div>

          {/* Centered Dropdown Selector */}
          <div className="arena-dropdown-wrap">
            <select
              className="arena-quick-select"
              value={selectedDemoId}
              onChange={(e) => handleSelectAccount(e.target.value, false)}
              disabled={loading}
            >
              <option value="">Choose Account to Quick Login</option>
              <optgroup label="System Administrator">
                <option value="admin">System Administrator (admin)</option>
              </optgroup>
              <optgroup label="Franchise Teams">
                <option value="csk">Chennai Super Kings (CSK)</option>
                <option value="mi">Mumbai Indians (MI)</option>
                <option value="rcb">Royal Challengers Bengaluru (RCB)</option>
                <option value="kkr">Kolkata Knight Riders (KKR)</option>
                <option value="rr">Rajasthan Royals (RR)</option>
                <option value="srh">Sunrisers Hyderabad (SRH)</option>
                <option value="dc">Delhi Capitals (DC)</option>
                <option value="gt">Gujarat Titans (GT)</option>
              </optgroup>
            </select>
            <div className="arena-dropdown-arrow">
              <ChevronDown size={16} />
            </div>
          </div>

          {/* Active selection feedback banner */}
          {selectedDemoId && (
            <div className="arena-autofill-banner">
              <div className="arena-autofill-text">
                <Sparkles size={14} color="#F59E0B" />
                <span>Selected: <strong>{username}</strong></span>
              </div>
              <button
                type="button"
                onClick={() => handleLogin(null, username, password)}
                disabled={loading}
                className="arena-autofill-action"
              >
                Instant Login ➔
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="arena-modal-overlay">
          <div className="arena-modal-box">
            <div className="arena-modal-header">
              <div className="arena-modal-title">
                <HelpCircle size={18} color="#F59E0B" />
                <span>Password Assistance</span>
              </div>
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="arena-modal-close"
              >
                <X size={18} />
              </button>
            </div>

            <div className="arena-modal-body">
              <p style={{ margin: '0 0 10px 0' }}>
                Franchise account credentials are managed securely by the <strong>System Administrator</strong>.
              </p>
              <p style={{ margin: 0 }}>
                To reset credentials, please contact the administrator at <strong>admin@cricketauction.local</strong> or use Quick Login to sign in as <strong>Admin</strong>.
              </p>
            </div>

            <div className="arena-modal-footer">
              <button
                type="button"
                onClick={() => setShowForgotModal(false)}
                className="arena-modal-btn"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
