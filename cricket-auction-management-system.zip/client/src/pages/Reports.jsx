import React, { useState, useEffect, useCallback } from 'react';
import {
  BarChart3,
  TrendingUp,
  Award,
  Users,
  DollarSign,
  Shield,
  Layers,
  RefreshCw,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import { reportService } from '../services/reportService';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { useToast } from '../context/ToastContext';
import { formatCurrency, formatDateTime, getRoleBadgeClass } from '../utils/formatters';

export default function Reports() {
  const { showToast } = useToast();

  const [overview, setOverview] = useState(null);
  const [teamSpending, setTeamSpending] = useState([]);
  const [soldPlayers, setSoldPlayers] = useState([]);
  const [unsoldPlayers, setUnsoldPlayers] = useState([]);
  const [roleBreakdown, setRoleBreakdown] = useState([]);
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' | 'teams' | 'sold' | 'unsold' | 'roles'
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchReports = useCallback(async () => {
    try {
      const [overRes, teamRes, soldRes, unsoldRes, roleRes] = await Promise.all([
        reportService.getOverview(),
        reportService.getTeamSpending(),
        reportService.getSoldPlayers(),
        reportService.getUnsoldPlayers(),
        reportService.getRoleBreakdown()
      ]);

      if (overRes.success) setOverview(overRes.data);
      if (teamRes.success) setTeamSpending(Array.isArray(teamRes.data) ? teamRes.data : []);
      if (soldRes.success) setSoldPlayers(Array.isArray(soldRes.data) ? soldRes.data : []);
      if (unsoldRes.success) setUnsoldPlayers(Array.isArray(unsoldRes.data) ? unsoldRes.data : []);
      if (roleRes.success) setRoleBreakdown(Array.isArray(roleRes.data) ? roleRes.data : []);
    } catch (err) {
      showToast(err.message || 'Failed to load auction reports', 'error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchReports();
  }, [fetchReports]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchReports();
  };

  if (loading) {
    return <LoadingSpinner message="Calculating relational SQL analytics & charts..." />;
  }

  const spendingList = Array.isArray(teamSpending) ? teamSpending : [];
  const maxTeamSpent = spendingList.length > 0
    ? Math.max(...spendingList.map((t) => Number(t.total_spent || 0)), 1)
    : 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header Bar */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '10px',
            backgroundColor: 'rgba(225, 6, 0, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--crimson-primary)'
          }}>
            <BarChart3 size={22} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
              REPORTS & AUCTION ANALYTICS
            </h2>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Comprehensive SQL aggregate computations across teams, players, roles, and financial expenditures.
            </p>
          </div>
        </div>

        <button
          onClick={handleRefresh}
          className="btn btn-secondary"
          disabled={refreshing}
          style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          <span>Refresh Analytics</span>
        </button>
      </div>

      {/* Top 4 Spotlight KPI Cards */}
      {overview && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '16px'
        }}>
          <div className="card" style={{ padding: '18px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Total Auction Expenditure
            </span>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--crimson-primary)', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(overview.total_spending)}
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              {overview.total_sold_players} players acquired
            </span>
          </div>

          <div className="card" style={{ padding: '18px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Average Selling Price
            </span>
            <div style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--gold-primary)', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(overview.average_selling_price)}
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              Per player average
            </span>
          </div>

          <div className="card" style={{ padding: '18px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Most Expensive Player
            </span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#10B981', fontFamily: 'var(--font-heading)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {overview.most_expensive_player ? formatCurrency(overview.most_expensive_player.final_price) : 'None'}
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              {overview.most_expensive_player ? `${overview.most_expensive_player.name} (${overview.most_expensive_player.team})` : 'Awaiting sales'}
            </span>
          </div>

          <div className="card" style={{ padding: '18px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Highest Spending Franchise
            </span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#3B82F6', fontFamily: 'var(--font-heading)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
              {overview.highest_spending_team ? formatCurrency(overview.highest_spending_team.total_spent) : 'None'}
            </div>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
              {overview.highest_spending_team ? `${overview.highest_spending_team.name} (${overview.highest_spending_team.code})` : 'Awaiting sales'}
            </span>
          </div>
        </div>
      )}

      {/* Navigation Tabs */}
      <div style={{
        display: 'flex',
        borderBottom: '1px solid var(--border-subtle)',
        gap: '8px',
        overflowX: 'auto',
        paddingBottom: '2px'
      }}>
        {[
          { id: 'overview', label: 'Team Spending Chart', icon: TrendingUp },
          { id: 'roles', label: 'Role Breakdown', icon: Layers },
          { id: 'sold', label: `Sold Players (${soldPlayers.length})`, icon: CheckCircle2 },
          { id: 'unsold', label: `Unsold Pool (${unsoldPlayers.length})`, icon: AlertCircle }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                padding: '12px 18px',
                borderRadius: '8px 8px 0 0',
                border: 'none',
                backgroundColor: isActive ? '#0F172A' : 'transparent',
                color: isActive ? '#FFFFFF' : 'var(--text-muted)',
                fontWeight: isActive ? 700 : 500,
                borderBottom: isActive ? '3px solid var(--crimson-primary)' : '3px solid transparent',
                cursor: 'pointer',
                fontSize: '0.9rem',
                whiteSpace: 'nowrap'
              }}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Team Spending Comparison Chart */}
      {activeTab === 'overview' && (
        <div className="card">
          <div style={{ marginBottom: '20px' }}>
            <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF', fontWeight: 700 }}>
              FRANCHISE EXPENDITURE DISTRIBUTION
            </h3>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Visual SQL comparison of total amount invested vs initial purse allocation.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
            {spendingList.map((team) => {
              const spent = Number(team.total_spent || 0);
              const percentage = Math.min(100, (spent / maxTeamSpent) * 100);

              return (
                <div key={team.id || team.name} style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{
                        padding: '2px 6px',
                        backgroundColor: '#1E293B',
                        borderRadius: '4px',
                        fontSize: '0.75rem',
                        fontWeight: 700,
                        color: 'var(--text-gold)'
                      }}>
                        {team.code}
                      </span>
                      <strong style={{ fontSize: '0.95rem', color: '#FFFFFF' }}>{team.name}</strong>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        ({team.squad_count || 0} players acquired)
                      </span>
                    </div>

                    <strong style={{ fontSize: '1rem', color: 'var(--gold-primary)', fontFamily: 'var(--font-heading)' }}>
                      {formatCurrency(spent)}
                    </strong>
                  </div>

                  {/* Visual Bar */}
                  <div style={{
                    height: '14px',
                    backgroundColor: '#1E293B',
                    borderRadius: '7px',
                    overflow: 'hidden'
                  }}>
                    <div style={{
                      height: '100%',
                      width: `${Math.max(percentage, spent > 0 ? 3 : 0)}%`,
                      background: 'linear-gradient(90deg, #E10600, #F59E0B)',
                      borderRadius: '7px',
                      transition: 'width 0.4s ease'
                    }} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Role Breakdown */}
      {activeTab === 'roles' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
            gap: '16px'
          }}>
            {roleBreakdown.map((r) => (
              <div key={r.role} className="card" style={{ padding: '20px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <span className={`badge ${getRoleBadgeClass(r.role)}`}>
                    {r.role}
                  </span>
                  <strong style={{ fontSize: '1.4rem', color: '#FFFFFF' }}>{r.total_sold} Sold</strong>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', fontSize: '0.85rem' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Total Money Spent:</span>
                    <strong style={{ color: 'var(--crimson-primary)' }}>{formatCurrency(r.total_spending)}</strong>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                    <span style={{ color: 'var(--text-muted)' }}>Average Final Price:</span>
                    <strong style={{ color: 'var(--gold-primary)' }}>{formatCurrency(r.average_price)}</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Sold Players Table */}
      {activeTab === 'sold' && (
        <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Player Name</th>
                  <th>Role</th>
                  <th>Nationality</th>
                  <th>Acquired By</th>
                  <th>Final Hammer Price</th>
                  <th>Date & Time</th>
                </tr>
              </thead>
              <tbody>
                {soldPlayers.map((p, index) => (
                  <tr key={p.id || index}>
                    <td>
                      <strong style={{ color: '#FFFFFF' }}>{p.player_name || p.name}</strong>
                    </td>
                    <td>
                      <span className={`badge ${getRoleBadgeClass(p.role)}`}>
                        {p.role}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>{p.nationality}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{
                          padding: '2px 6px',
                          backgroundColor: '#1E293B',
                          borderRadius: '4px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                          color: 'var(--text-gold)'
                        }}>
                          {p.team_code}
                        </span>
                        <span style={{ color: '#FFFFFF' }}>{p.team_name}</span>
                      </div>
                    </td>
                    <td>
                      <strong style={{ color: 'var(--gold-primary)', fontFamily: 'var(--font-heading)', fontSize: '1rem' }}>
                        {formatCurrency(p.final_price)}
                      </strong>
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      {formatDateTime(p.purchased_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Unsold Players Table */}
      {activeTab === 'unsold' && (
        <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Player Name</th>
                  <th>Role</th>
                  <th>Nationality</th>
                  <th>Base Price</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {unsoldPlayers.map((p, index) => (
                  <tr key={p.id || index}>
                    <td>
                      <strong style={{ color: '#FFFFFF' }}>{p.player_name || p.name}</strong>
                    </td>
                    <td>
                      <span className={`badge ${getRoleBadgeClass(p.role)}`}>
                        {p.role}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)' }}>{p.nationality}</td>
                    <td>
                      <strong style={{ color: '#FFFFFF', fontFamily: 'var(--font-heading)' }}>
                        {formatCurrency(p.base_price)}
                      </strong>
                    </td>
                    <td>
                      <span className="badge status-unsold">UNSOLD</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
