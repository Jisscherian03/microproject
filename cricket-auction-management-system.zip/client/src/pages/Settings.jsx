import React, { useState, useEffect, useCallback } from 'react';
import { Settings as SettingsIcon, Save, RefreshCw, AlertCircle, CheckCircle, Shield } from 'lucide-react';
import { settingService } from '../services/settingService';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { useToast } from '../context/ToastContext';
import { formatCurrency } from '../utils/formatters';

export default function Settings() {
  const { showToast } = useToast();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState({
    minimum_bid_increment: '2000000',
    maximum_squad_size: '25',
    min_batters: '4',
    min_bowlers: '4',
    min_allrounders: '2',
    min_wicketkeepers: '1',
    allow_self_outbid: false
  });
  const [errorMsg, setErrorMsg] = useState('');

  const fetchSettings = useCallback(async () => {
    setLoading(true);
    try {
      const res = await settingService.get();
      if (res.success && res.data) {
        setSettings({
          minimum_bid_increment: res.data.minimum_bid_increment?.toString() || '2000000',
          maximum_squad_size: res.data.maximum_squad_size?.toString() || '25',
          min_batters: res.data.min_batters?.toString() || '4',
          min_bowlers: res.data.min_bowlers?.toString() || '4',
          min_allrounders: res.data.min_allrounders?.toString() || '2',
          min_wicketkeepers: res.data.min_wicketkeepers?.toString() || '1',
          allow_self_outbid: Boolean(res.data.allow_self_outbid)
        });
      }
    } catch (err) {
      showToast(err.message || 'Failed to load settings', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchSettings();
  }, [fetchSettings]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    const inc = Number(settings.minimum_bid_increment);
    const squadSize = Number(settings.maximum_squad_size);

    if (!inc || inc <= 0) {
      setErrorMsg('Minimum bid increment must be greater than zero.');
      return;
    }
    if (!squadSize || squadSize < 11) {
      setErrorMsg('Maximum squad size must be at least 11 players.');
      return;
    }

    setSaving(true);
    try {
      await settingService.update({
        minimum_bid_increment: inc,
        maximum_squad_size: squadSize,
        min_batters: Number(settings.min_batters),
        min_bowlers: Number(settings.min_bowlers),
        min_allrounders: Number(settings.min_allrounders),
        min_wicketkeepers: Number(settings.min_wicketkeepers),
        allow_self_outbid: settings.allow_self_outbid
      });
      showToast('Auction settings saved successfully!', 'success');
    } catch (err) {
      setErrorMsg(err.message || 'Failed to update settings');
      showToast(err.message || 'Update failed', 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <LoadingSpinner message="Loading auction engine settings..." />;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px', maxWidth: '800px' }}>
      {/* Header Bar */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        gap: '14px'
      }}>
        <div style={{
          width: '44px',
          height: '44px',
          borderRadius: '10px',
          backgroundColor: 'rgba(225, 6, 0, 0.2)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'var(--crimson-primary)'
        }}>
          <SettingsIcon size={24} />
        </div>
        <div>
          <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
            AUCTION SYSTEM CONFIGURATION
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Admin controls for bid increment rules, maximum squad ceilings, and bidding validation.
          </p>
        </div>
      </div>

      {errorMsg && (
        <div style={{
          padding: '12px 18px',
          backgroundColor: 'rgba(239, 68, 68, 0.15)',
          border: '1px solid #EF4444',
          borderRadius: '8px',
          color: '#EF4444',
          display: 'flex',
          alignItems: 'center',
          gap: '10px'
        }}>
          <AlertCircle size={20} />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Form Card */}
      <form onSubmit={handleSubmit} className="card" style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
        {/* Section 1: Bidding Increments */}
        <div>
          <h3 style={{ fontSize: '1.1rem', color: '#FFFFFF', fontWeight: 700, marginBottom: '6px' }}>
            Bidding Increment Engine
          </h3>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '16px' }}>
            Enforce the mandatory step jump required between consecutive valid bids.
          </p>

          <div className="form-group">
            <label className="form-label">Minimum Bid Increment (in ₹) *</label>
            <div style={{ position: 'relative' }}>
              <input
                type="number"
                className="form-input"
                value={settings.minimum_bid_increment}
                onChange={(e) => setSettings({ ...settings, minimum_bid_increment: e.target.value })}
                min="100000"
                step="500000"
                required
                style={{ paddingRight: '120px' }}
              />
              <span style={{
                position: 'absolute',
                right: '12px',
                top: '50%',
                transform: 'translateY(-50%)',
                fontSize: '0.85rem',
                color: 'var(--text-gold)',
                fontWeight: 700
              }}>
                {formatCurrency(Number(settings.minimum_bid_increment))}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginTop: '12px' }}>
            <input
              type="checkbox"
              id="selfOutbid"
              checked={settings.allow_self_outbid}
              onChange={(e) => setSettings({ ...settings, allow_self_outbid: e.target.checked })}
              style={{ width: '18px', height: '18px', accentColor: 'var(--crimson-primary)', cursor: 'pointer' }}
            />
            <label htmlFor="selfOutbid" style={{ fontSize: '0.9rem', color: '#FFFFFF', cursor: 'pointer' }}>
              Allow teams to outbid themselves (Default: disabled in official IPL)
            </label>
          </div>
        </div>

        <hr style={{ border: 'none', borderTop: '1px solid var(--border-subtle)' }} />

        {/* Section 2: Squad Limits */}
        <div>
          <h3 style={{ fontSize: '1.1rem', color: '#FFFFFF', fontWeight: 700, marginBottom: '6px' }}>
            Squad Composition & Limits
          </h3>
          <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '16px' }}>
            Configure maximum player squad size per franchise and recommended category baselines.
          </p>

          <div className="form-group">
            <label className="form-label">Maximum Squad Size (Default: 25) *</label>
            <input
              type="number"
              className="form-input"
              value={settings.maximum_squad_size}
              onChange={(e) => setSettings({ ...settings, maximum_squad_size: e.target.value })}
              min="11"
              max="35"
              required
            />
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '14px', marginTop: '12px' }}>
            <div>
              <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Min Batters</label>
              <input
                type="number"
                className="form-input"
                value={settings.min_batters}
                onChange={(e) => setSettings({ ...settings, min_batters: e.target.value })}
                min="1"
              />
            </div>
            <div>
              <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Min Bowlers</label>
              <input
                type="number"
                className="form-input"
                value={settings.min_bowlers}
                onChange={(e) => setSettings({ ...settings, min_bowlers: e.target.value })}
                min="1"
              />
            </div>
            <div>
              <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Min All-rounders</label>
              <input
                type="number"
                className="form-input"
                value={settings.min_allrounders}
                onChange={(e) => setSettings({ ...settings, min_allrounders: e.target.value })}
                min="1"
              />
            </div>
            <div>
              <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Min Wicketkeepers</label>
              <input
                type="number"
                className="form-input"
                value={settings.min_wicketkeepers}
                onChange={(e) => setSettings({ ...settings, min_wicketkeepers: e.target.value })}
                min="1"
              />
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div style={{
          paddingTop: '16px',
          borderTop: '1px solid var(--border-subtle)',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '12px'
        }}>
          <button
            type="button"
            className="btn btn-secondary"
            onClick={fetchSettings}
            disabled={saving}
          >
            Reset
          </button>
          <button
            type="submit"
            className="btn btn-primary"
            disabled={saving}
            style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
          >
            <Save size={18} />
            <span>{saving ? 'Saving...' : 'Save Configuration'}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
