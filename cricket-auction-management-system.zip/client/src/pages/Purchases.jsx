import React, { useState, useEffect, useCallback } from 'react';
import {
  ShoppingBag,
  Search,
  Filter,
  TrendingUp,
  Award,
  Users,
  RefreshCw,
  FileSpreadsheet
} from 'lucide-react';
import { purchaseService } from '../services/purchaseService';
import { teamService } from '../services/teamService';
import LoadingSpinner from '../components/common/LoadingSpinner';
import EmptyState from '../components/common/EmptyState';
import { useToast } from '../context/ToastContext';
import { formatCurrency, formatDateTime, getRoleBadgeClass } from '../utils/formatters';

export default function Purchases() {
  const { showToast } = useToast();

  const [purchases, setPurchases] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState('');
  const [selectedRole, setSelectedRole] = useState('');

  const fetchPurchasesData = useCallback(async () => {
    try {
      const [purchasesRes, teamsRes] = await Promise.all([
        purchaseService.getAll({
          team_id: selectedTeamId || undefined,
          role: selectedRole || undefined
        }),
        teamService.getAll()
      ]);

      if (purchasesRes.success && purchasesRes.data) {
        const list = purchasesRes.data.purchases || (Array.isArray(purchasesRes.data) ? purchasesRes.data : []);
        setPurchases(Array.isArray(list) ? list : []);
      }
      if (teamsRes.success && teamsRes.data) {
        setTeams(Array.isArray(teamsRes.data) ? teamsRes.data : []);
      }
    } catch (err) {
      showToast(err.message || 'Failed to load purchase ledger', 'error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [selectedTeamId, selectedRole, showToast]);

  useEffect(() => {
    fetchPurchasesData();
  }, [fetchPurchasesData]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchPurchasesData();
  };

  const purchaseList = Array.isArray(purchases) ? purchases : [];

  const filteredPurchases = purchaseList.filter((p) => {
    const term = search.toLowerCase();
    const playerName = (p.player_name || p.player?.name || '').toLowerCase();
    const teamName = (p.team_name || p.team?.name || '').toLowerCase();
    const teamCode = (p.team_code || p.team?.code || '').toLowerCase();

    return !search || playerName.includes(term) || teamName.includes(term) || teamCode.includes(term);
  });

  const totalSpent = purchaseList.reduce((sum, p) => sum + Number(p.final_price || 0), 0);
  const avgPrice = purchaseList.length > 0 ? totalSpent / purchaseList.length : 0;
  const maxPurchase = purchaseList.length > 0
    ? purchaseList.reduce((max, p) => Number(p.final_price) > Number(max.final_price) ? p : max, purchaseList[0])
    : null;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header Bar */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '10px',
            backgroundColor: 'rgba(16, 185, 129, 0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#10B981'
          }}>
            <ShoppingBag size={22} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
              OFFICIAL PURCHASE LEDGER
            </h2>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Permanent immutable transaction records of all finalized player acquisitions.
            </p>
          </div>
        </div>

        <button
          onClick={handleRefresh}
          className="btn btn-secondary"
          disabled={refreshing}
          style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          <span>Refresh Ledger</span>
        </button>
      </div>

      {/* Top 4 Summary Metrics */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '16px'
      }}>
        <div className="card" style={{ padding: '16px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Total Players Acquired
          </span>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#FFFFFF', fontFamily: 'var(--font-heading)' }}>
            {purchases.length}
          </div>
        </div>

        <div className="card" style={{ padding: '16px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Total Money Disbursed
          </span>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--crimson-primary)', fontFamily: 'var(--font-heading)' }}>
            {formatCurrency(totalSpent)}
          </div>
        </div>

        <div className="card" style={{ padding: '16px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Average Player Price
          </span>
          <div style={{ fontSize: '1.6rem', fontWeight: 800, color: 'var(--gold-primary)', fontFamily: 'var(--font-heading)' }}>
            {formatCurrency(avgPrice)}
          </div>
        </div>

        <div className="card" style={{ padding: '16px' }}>
          <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
            Most Expensive Deal
          </span>
          <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#10B981', fontFamily: 'var(--font-heading)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {maxPurchase ? `${formatCurrency(maxPurchase.final_price)} (${maxPurchase.player_name || maxPurchase.player?.name})` : 'None'}
          </div>
        </div>
      </div>

      {/* Filters Row */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '16px 20px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '14px',
        alignItems: 'center'
      }}>
        {/* Search */}
        <div style={{ position: 'relative' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Search player or franchise..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ paddingLeft: '36px', width: '100%' }}
          />
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        </div>

        {/* Filter by Team */}
        <select
          className="form-select"
          value={selectedTeamId}
          onChange={(e) => setSelectedTeamId(e.target.value)}
        >
          <option value="">All Franchises</option>
          {teams.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name} ({t.code})
            </option>
          ))}
        </select>

        {/* Filter by Role */}
        <select
          className="form-select"
          value={selectedRole}
          onChange={(e) => setSelectedRole(e.target.value)}
        >
          <option value="">All Roles</option>
          <option value="Batter">Batter</option>
          <option value="Bowler">Bowler</option>
          <option value="All-rounder">All-rounder</option>
          <option value="Wicketkeeper">Wicketkeeper</option>
        </select>
      </div>

      {/* Purchases Table */}
      {loading ? (
        <LoadingSpinner message="Querying MySQL purchases ledger..." />
      ) : filteredPurchases.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title="No Purchases Recorded"
          description="No purchase records match your search and filter criteria."
        />
      ) : (
        <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Deal #</th>
                  <th>Player Name</th>
                  <th>Playing Role</th>
                  <th>Acquiring Franchise</th>
                  <th>Final Winning Price</th>
                  <th>Execution Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {filteredPurchases.map((p, index) => (
                  <tr key={p.id || index}>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      #{p.id || index + 1}
                    </td>
                    <td>
                      <strong style={{ fontSize: '0.95rem', color: '#FFFFFF' }}>
                        {p.player_name || p.player?.name}
                      </strong>
                      <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {p.nationality || p.player?.nationality}
                      </div>
                    </td>
                    <td>
                      <span className={`badge ${getRoleBadgeClass(p.role || p.player?.role)}`}>
                        {p.role || p.player?.role}
                      </span>
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{
                          padding: '2px 6px',
                          backgroundColor: '#1E293B',
                          borderRadius: '4px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                          color: 'var(--text-gold)'
                        }}>
                          {p.team_code || p.team?.code}
                        </span>
                        <span style={{ fontSize: '0.9rem', color: '#FFFFFF', fontWeight: 600 }}>
                          {p.team_name || p.team?.name}
                        </span>
                      </div>
                    </td>
                    <td>
                      <strong style={{
                        fontSize: '1.05rem',
                        color: 'var(--gold-primary)',
                        fontFamily: 'var(--font-heading)'
                      }}>
                        {formatCurrency(p.final_price)}
                      </strong>
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      {formatDateTime(p.purchased_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
