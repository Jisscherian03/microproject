import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Shield,
  Plus,
  Search,
  Wallet,
  Users,
  ArrowRight,
  Edit,
  Trash2,
  X,
  AlertCircle
} from 'lucide-react';
import { teamService } from '../services/teamService';
import TeamCard from '../components/team/TeamCard';
import LoadingSpinner from '../components/common/LoadingSpinner';
import EmptyState from '../components/common/EmptyState';
import ConfirmationModal from '../components/common/ConfirmationModal';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatCurrency } from '../utils/formatters';

export default function Teams() {
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const { showToast } = useToast();

  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Modals state
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingTeam, setEditingTeam] = useState(null);
  const [deletingTeam, setDeletingTeam] = useState(null);
  const [saving, setSaving] = useState(false);

  // Form input state
  const [formData, setFormData] = useState({
    team_name: '',
    team_code: '',
    logo_url: '',
    initial_purse: '1000000000'
  });
  const [formError, setFormError] = useState('');

  const fetchTeams = useCallback(async () => {
    setLoading(true);
    try {
      const res = await teamService.getAll();
      if (res.success && res.data) {
        setTeams(res.data);
      }
    } catch (err) {
      showToast(err.message || 'Failed to load teams', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    fetchTeams();
  }, [fetchTeams]);

  const handleOpenAdd = () => {
    setEditingTeam(null);
    setFormData({
      team_name: '',
      team_code: '',
      logo_url: '',
      initial_purse: '1000000000'
    });
    setFormError('');
    setShowFormModal(true);
  };

  const handleOpenEdit = (team) => {
    setEditingTeam(team);
    setFormData({
      team_name: team.name || '',
      team_code: team.code || '',
      logo_url: team.logo_url || '',
      initial_purse: team.initial_purse ? team.initial_purse.toString() : '1000000000'
    });
    setFormError('');
    setShowFormModal(true);
  };

  const handleSaveTeam = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!formData.team_name.trim()) {
      setFormError('Team name is required.');
      return;
    }
    if (!formData.team_code.trim()) {
      setFormError('Team short code is required (e.g. CSK, MI, RCB).');
      return;
    }
    if (!formData.initial_purse || Number(formData.initial_purse) <= 0) {
      setFormError('Initial purse must be a positive number.');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        team_name: formData.team_name.trim(),
        team_code: formData.team_code.trim().toUpperCase(),
        logo_url: formData.logo_url.trim() || null,
        initial_purse: Number(formData.initial_purse)
      };

      if (editingTeam) {
        await teamService.update(editingTeam.id, payload);
        showToast(`Franchise ${payload.team_name} updated!`, 'success');
      } else {
        await teamService.create(payload);
        showToast(`Franchise ${payload.team_name} registered!`, 'success');
      }

      setShowFormModal(false);
      fetchTeams();
    } catch (err) {
      setFormError(err.message || 'Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteTeam = async () => {
    if (!deletingTeam) return;
    setSaving(true);
    try {
      await teamService.delete(deletingTeam.id);
      showToast(`Franchise ${deletingTeam.name} deleted.`, 'success');
      setDeletingTeam(null);
      fetchTeams();
    } catch (err) {
      showToast(err.message || 'Could not delete team', 'error');
    } finally {
      setSaving(false);
    }
  };

  const teamList = Array.isArray(teams) ? teams : (Array.isArray(teams?.teams) ? teams.teams : []);
  const filteredTeams = teamList.filter((t) =>
    (t.name || t.team_name || '').toLowerCase().includes(search.toLowerCase()) ||
    (t.code || t.team_code || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Top Header Bar */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div>
          <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
            IPL FRANCHISES & PURSES
          </h2>
          <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
            Financial ledger, squad limits, remaining budget balances, and franchise administration.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{ position: 'relative' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Search franchises..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={{ paddingLeft: '36px', minWidth: '220px' }}
            />
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          </div>

          {isAdmin && (
            <button
              onClick={handleOpenAdd}
              className="btn btn-primary"
              style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <Plus size={18} />
              <span>Add Franchise</span>
            </button>
          )}
        </div>
      </div>

      {/* Grid of Team Cards */}
      {loading ? (
        <LoadingSpinner message="Loading franchise financial records..." />
      ) : filteredTeams.length === 0 ? (
        <EmptyState
          icon={Shield}
          title="No Franchises Found"
          description="No franchises matched your search criteria."
          actionText={isAdmin ? "Add New Franchise" : undefined}
          onAction={isAdmin ? handleOpenAdd : undefined}
        />
      ) : (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))',
          gap: '24px'
        }}>
          {filteredTeams.map((team) => (
            <TeamCard
              key={team.id}
              team={team}
              isAdmin={isAdmin}
              onEdit={() => handleOpenEdit(team)}
              onViewSquad={(id) => navigate(`/teams/${id}`)}
            />
          ))}
        </div>
      )}

      {/* Add / Edit Team Modal */}
      {showFormModal && (
        <div className="modal-backdrop">
          <div className="modal-content" style={{ maxWidth: '480px' }}>
            <div style={{
              padding: '20px 24px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>
                {editingTeam ? `Edit Franchise: ${editingTeam.name}` : 'Register New IPL Franchise'}
              </h3>
              <button
                onClick={() => setShowFormModal(false)}
                disabled={saving}
                style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveTeam}>
              <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {formError && (
                  <div style={{
                    padding: '10px 14px',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    border: '1px solid #EF4444',
                    borderRadius: '8px',
                    color: '#EF4444',
                    fontSize: '0.85rem'
                  }}>
                    {formError}
                  </div>
                )}

                <div className="form-group">
                  <label className="form-label">Franchise Full Name *</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="e.g. Chennai Super Kings"
                    value={formData.team_name}
                    onChange={(e) => setFormData({ ...formData, team_name: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Team Short Code (Unique) *</label>
                  <input
                    type="text"
                    className="form-input"
                    placeholder="e.g. CSK, MI, RCB"
                    maxLength={10}
                    value={formData.team_code}
                    onChange={(e) => setFormData({ ...formData, team_code: e.target.value.toUpperCase() })}
                    required
                  />
                </div>

                <div className="form-group">
                  <label className="form-label">Initial Purse (in ₹) *</label>
                  <input
                    type="number"
                    className="form-input"
                    value={formData.initial_purse}
                    onChange={(e) => setFormData({ ...formData, initial_purse: e.target.value })}
                    min="1000000"
                    step="10000000"
                    required
                  />
                  <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', marginTop: '4px', display: 'block' }}>
                    Formatted: <strong style={{ color: 'var(--text-gold)' }}>{formatCurrency(Number(formData.initial_purse))}</strong>
                  </span>
                </div>

                <div className="form-group">
                  <label className="form-label">Logo Image URL (Optional)</label>
                  <input
                    type="url"
                    className="form-input"
                    placeholder="https://..."
                    value={formData.logo_url}
                    onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })}
                  />
                </div>
              </div>

              <div style={{
                padding: '16px 24px',
                backgroundColor: '#090D16',
                borderTop: '1px solid var(--border-subtle)',
                display: 'flex',
                justifyContent: 'flex-end',
                gap: '12px'
              }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowFormModal(false)}
                  disabled={saving}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : editingTeam ? 'Update Franchise' : 'Register Franchise'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={!!deletingTeam}
        title="Delete Franchise"
        message={`Are you sure you want to delete ${deletingTeam?.name}? The database will reject this action if this franchise has linked bids, purchases, or user accounts.`}
        confirmText="Delete Franchise"
        isDanger={true}
        loading={saving}
        onConfirm={handleDeleteTeam}
        onCancel={() => setDeletingTeam(null)}
      />
    </div>
  );
}
