import React, { useState, useEffect, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Shield,
  Wallet,
  Users,
  ArrowLeft,
  Award,
  CheckCircle,
  AlertCircle,
  Trophy,
  Activity,
  Layers
} from 'lucide-react';
import { teamService } from '../services/teamService';
import LoadingSpinner from '../components/common/LoadingSpinner';
import EmptyState from '../components/common/EmptyState';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatCurrency, formatDateTime, getRoleBadgeClass } from '../utils/formatters';

export default function TeamDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isTeamUser, user } = useAuth();
  const { showToast } = useToast();

  const [team, setTeam] = useState(null);
  const [squad, setSquad] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchTeamSquad = useCallback(async () => {
    setLoading(true);
    try {
      const [teamRes, squadRes] = await Promise.all([
        teamService.getById(id),
        teamService.getSquad(id)
      ]);

      if (teamRes.success) {
        setTeam(teamRes.data);
      }
      if (squadRes.success) {
        const rawSquad = squadRes.data;
        const squadList = Array.isArray(rawSquad)
          ? rawSquad
          : Array.isArray(rawSquad?.players)
            ? rawSquad.players
            : [];
        setSquad(squadList);
      }
    } catch (err) {
      showToast(err.message || 'Failed to load franchise details', 'error');
    } finally {
      setLoading(false);
    }
  }, [id, showToast]);

  useEffect(() => {
    fetchTeamSquad();
  }, [fetchTeamSquad]);

  if (loading) {
    return <LoadingSpinner message="Loading franchise squad & financial ledger..." />;
  }

  if (!team) {
    return (
      <EmptyState
        icon={Shield}
        title="Franchise Not Found"
        description="The requested cricket team could not be located in the database."
        actionText="Back to Teams"
        onAction={() => navigate('/teams')}
      />
    );
  }

  const initialPurse = Number(team.initial_purse || 1000000000);
  const remainingPurse = Number(team.remaining_purse || 0);
  const totalSpent = Number(team.total_spent || initialPurse - remainingPurse);

  const squadList = Array.isArray(squad) ? squad : (Array.isArray(squad?.players) ? squad.players : []);

  // Group squad by role
  const roleGroups = {
    Batter: squadList.filter((p) => p.role === 'Batter'),
    Bowler: squadList.filter((p) => p.role === 'Bowler'),
    'All-rounder': squadList.filter((p) => p.role === 'All-rounder'),
    Wicketkeeper: squadList.filter((p) => p.role === 'Wicketkeeper')
  };

  // Reconciliation check
  const calculatedSpent = squadList.reduce((sum, p) => sum + Number(p.purchase_price || p.final_price || 0), 0);
  const isBudgetReconciled = Math.abs(calculatedSpent - totalSpent) < 1;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Back button & Title */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
        <button
          onClick={() => navigate('/teams')}
          className="btn btn-secondary"
          style={{ padding: '8px 14px', display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <ArrowLeft size={16} />
          <span>All Franchises</span>
        </button>
        <span style={{ color: 'var(--text-muted)' }}>/</span>
        <span style={{ color: '#FFFFFF', fontWeight: 600 }}>{team.team_name}</span>
      </div>

      {/* Team Header & Financial Summary Banner */}
      <div style={{
        background: 'linear-gradient(135deg, #131B2E 0%, #0B101D 100%)',
        border: '1px solid var(--border-accent)',
        borderRadius: '16px',
        padding: '28px',
        boxShadow: '0 10px 30px rgba(0, 0, 0, 0.5)'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '20px',
          marginBottom: '24px',
          borderBottom: '1px solid var(--border-subtle)',
          paddingBottom: '20px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '18px' }}>
            <div style={{
              width: '64px',
              height: '64px',
              borderRadius: '14px',
              backgroundColor: '#1E293B',
              border: '2px solid var(--border-accent)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '1.5rem',
              fontWeight: 900,
              color: 'var(--text-gold)',
              fontFamily: 'var(--font-heading)'
            }}>
              {team.team_code}
            </div>

            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <h2 style={{ fontSize: '1.8rem', color: '#FFFFFF', fontWeight: 800 }}>
                  {team.team_name}
                </h2>
                {isTeamUser && user?.team_id === team.id && (
                  <span style={{
                    backgroundColor: 'rgba(37, 99, 235, 0.2)',
                    color: '#60A5FA',
                    fontSize: '0.75rem',
                    fontWeight: 700,
                    padding: '3px 8px',
                    borderRadius: '4px'
                  }}>
                    MY FRANCHISE
                  </span>
                )}
              </div>
              <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
                Squad Capacity: {squadList.length} / 25 Players Acquired
              </p>
            </div>
          </div>

          {/* Budget Reconciliation Badge */}
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            backgroundColor: isBudgetReconciled ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)',
            border: `1px solid ${isBudgetReconciled ? '#10B981' : '#EF4444'}`,
            padding: '8px 14px',
            borderRadius: '8px',
            fontSize: '0.8rem',
            color: isBudgetReconciled ? '#10B981' : '#EF4444'
          }}>
            {isBudgetReconciled ? <CheckCircle size={16} /> : <AlertCircle size={16} />}
            <span>{isBudgetReconciled ? 'Ledger Exactly Reconciled' : 'Purse Variance Detected'}</span>
          </div>
        </div>

        {/* 4 Financial Columns */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '16px'
        }}>
          <div style={{ backgroundColor: '#090D16', padding: '16px', borderRadius: '10px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Initial Allocation
            </span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#FFFFFF', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(initialPurse)}
            </div>
          </div>

          <div style={{ backgroundColor: '#090D16', padding: '16px', borderRadius: '10px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Total Spent
            </span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--crimson-primary)', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(totalSpent)}
            </div>
          </div>

          <div style={{ backgroundColor: '#090D16', padding: '16px', borderRadius: '10px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Remaining Purse
            </span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#10B981', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(remainingPurse)}
            </div>
          </div>

          <div style={{ backgroundColor: '#090D16', padding: '16px', borderRadius: '10px' }}>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Avg Cost / Player
            </span>
            <div style={{ fontSize: '1.4rem', fontWeight: 800, color: 'var(--gold-primary)', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(squadList.length > 0 ? totalSpent / squadList.length : 0)}
            </div>
          </div>
        </div>
      </div>

      {/* Role Breakdown Overview */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
        gap: '16px'
      }}>
        {Object.entries(roleGroups).map(([roleName, playersInRole]) => (
          <div key={roleName} className="card" style={{ padding: '16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '8px' }}>
              <span className={`badge ${getRoleBadgeClass(roleName)}`}>
                {roleName}
              </span>
              <strong style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>{playersInRole.length}</strong>
            </div>
            <div style={{ fontSize: '0.78rem', color: 'var(--text-muted)' }}>
              Expenditure:{' '}
              <strong style={{ color: '#FFFFFF' }}>
                {formatCurrency(playersInRole.reduce((s, p) => s + Number(p.purchase_price || p.final_price || 0), 0))}
              </strong>
            </div>
          </div>
        ))}
      </div>

      {/* Official Squad List */}
      <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
        <div style={{
          padding: '20px 24px',
          borderBottom: '1px solid var(--border-subtle)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          backgroundColor: '#0D1322'
        }}>
          <div>
            <h3 style={{ fontSize: '1.15rem', color: '#FFFFFF', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Users size={20} color="var(--crimson-primary)" />
              <span>OFFICIAL PURCHASED SQUAD ({squadList.length} Players)</span>
            </h3>
            <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Permanent player roster acquired through completed auction rounds.
            </span>
          </div>
        </div>

        {squadList.length === 0 ? (
          <div style={{ textAlign: 'center', padding: '48px 16px', color: 'var(--text-muted)' }}>
            <Trophy size={36} style={{ margin: '0 auto 12px', opacity: 0.4 }} />
            <p style={{ fontSize: '0.95rem' }}>No players have been purchased by this franchise yet.</p>
          </div>
        ) : (
          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Player Name</th>
                  <th>Role</th>
                  <th>Nationality</th>
                  <th>Batting / Bowling</th>
                  <th>Final Price</th>
                  <th>Acquired Date</th>
                </tr>
              </thead>
              <tbody>
                {squadList.map((p, index) => (
                  <tr key={p.id || index}>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      {index + 1}
                    </td>
                    <td>
                      <strong style={{ fontSize: '0.95rem', color: '#FFFFFF' }}>
                        {p.player_name || p.name}
                      </strong>
                    </td>
                    <td>
                      <span className={`badge ${getRoleBadgeClass(p.role)}`}>
                        {p.role}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      {p.nationality}
                    </td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      {p.batting_style || 'Right-hand'} • {p.bowling_style || 'None'}
                    </td>
                    <td>
                      <strong style={{
                        fontSize: '1rem',
                        color: 'var(--gold-primary)',
                        fontFamily: 'var(--font-heading)'
                      }}>
                        {formatCurrency(p.purchase_price || p.final_price)}
                      </strong>
                    </td>
                    <td style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                      {formatDateTime(p.purchased_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
