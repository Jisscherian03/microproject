import React, { useState, useEffect, useCallback } from 'react';
import { History, Search, Filter, Shield, RefreshCw } from 'lucide-react';
import { auctionService } from '../services/auctionService';
import { teamService } from '../services/teamService';
import LoadingSpinner from '../components/common/LoadingSpinner';
import EmptyState from '../components/common/EmptyState';
import { useToast } from '../context/ToastContext';
import { formatCurrency, formatDateTime } from '../utils/formatters';

export default function BidHistory() {
  const { showToast } = useToast();

  const [bids, setBids] = useState([]);
  const [teams, setTeams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [selectedTeamId, setSelectedTeamId] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  const fetchData = useCallback(async () => {
    try {
      const [bidsRes, teamsRes] = await Promise.all([
        auctionService.getAllBids({
          team_id: selectedTeamId || undefined,
          limit: 150
        }),
        teamService.getAll()
      ]);

      if (bidsRes.success && bidsRes.data) {
        const list = bidsRes.data.bids || (Array.isArray(bidsRes.data) ? bidsRes.data : []);
        setBids(Array.isArray(list) ? list : []);
      }
      if (teamsRes.success && teamsRes.data) {
        setTeams(Array.isArray(teamsRes.data) ? teamsRes.data : []);
      }
    } catch (err) {
      showToast(err.message || 'Failed to load bid history', 'error');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [selectedTeamId, showToast]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleRefresh = () => {
    setRefreshing(true);
    fetchData();
  };

  const bidList = Array.isArray(bids) ? bids : [];

  const filteredBids = bidList.filter((b) => {
    const matchesSearch = !search ||
      b.player?.name?.toLowerCase().includes(search.toLowerCase()) ||
      b.team?.name?.toLowerCase().includes(search.toLowerCase()) ||
      b.team?.code?.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = !selectedStatus || b.bid_status === selectedStatus;

    return matchesSearch && matchesStatus;
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Header Bar */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '10px',
            backgroundColor: 'rgba(245, 158, 11, 0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--gold-primary)'
          }}>
            <History size={22} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
              AUCTION BID LOG
            </h2>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Complete chronological audit trail of all bids placed across all player auctions.
            </p>
          </div>
        </div>

        <button
          onClick={handleRefresh}
          className="btn btn-secondary"
          disabled={refreshing}
          style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
        >
          <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
          <span>Refresh Feed</span>
        </button>
      </div>

      {/* Filter Row */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '16px 20px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
        gap: '14px',
        alignItems: 'center'
      }}>
        {/* Search */}
        <div style={{ position: 'relative' }}>
          <input
            type="text"
            className="form-input"
            placeholder="Search player or team..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            style={{ paddingLeft: '36px', width: '100%' }}
          />
          <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
        </div>

        {/* Filter by Team */}
        <select
          className="form-select"
          value={selectedTeamId}
          onChange={(e) => setSelectedTeamId(e.target.value)}
        >
          <option value="">All Franchises</option>
          {teams.map((t) => (
            <option key={t.id} value={t.id}>
              {t.name} ({t.code})
            </option>
          ))}
        </select>

        {/* Filter by Status */}
        <select
          className="form-select"
          value={selectedStatus}
          onChange={(e) => setSelectedStatus(e.target.value)}
        >
          <option value="">All Bid Statuses</option>
          <option value="WINNING">WINNING</option>
          <option value="VALID">VALID</option>
          <option value="OUTBID">OUTBID</option>
          <option value="REJECTED">REJECTED</option>
        </select>
      </div>

      {/* Table */}
      {loading ? (
        <LoadingSpinner message="Loading historical bids from database..." />
      ) : filteredBids.length === 0 ? (
        <EmptyState
          icon={History}
          title="No Bids Found"
          description="No bid records match the selected filter criteria."
        />
      ) : (
        <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
          <div style={{ overflowX: 'auto' }}>
            <table className="custom-table">
              <thead>
                <tr>
                  <th>Bid ID</th>
                  <th>Player</th>
                  <th>Bidding Franchise</th>
                  <th>Bid Amount</th>
                  <th>Bid Status</th>
                  <th>Timestamp</th>
                </tr>
              </thead>
              <tbody>
                {filteredBids.map((b) => (
                  <tr key={b.id}>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      #{b.id}
                    </td>
                    <td>
                      <strong style={{ fontSize: '0.95rem', color: '#FFFFFF' }}>
                        {b.player?.name || `Auction #${b.auction_id}`}
                      </strong>
                      {b.player?.role && (
                        <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          {b.player.role}
                        </div>
                      )}
                    </td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{
                          padding: '2px 6px',
                          backgroundColor: '#1E293B',
                          borderRadius: '4px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                          color: 'var(--text-gold)'
                        }}>
                          {b.team?.code}
                        </span>
                        <span style={{ fontSize: '0.9rem', color: '#FFFFFF', fontWeight: 600 }}>
                          {b.team?.name}
                        </span>
                      </div>
                    </td>
                    <td>
                      <strong style={{
                        fontSize: '1.05rem',
                        color: b.bid_status === 'WINNING' ? 'var(--gold-primary)' : '#FFFFFF',
                        fontFamily: 'var(--font-heading)'
                      }}>
                        {formatCurrency(b.bid_amount)}
                      </strong>
                    </td>
                    <td>
                      <span style={{
                        padding: '3px 10px',
                        borderRadius: '4px',
                        fontSize: '0.75rem',
                        fontWeight: 700,
                        backgroundColor:
                          b.bid_status === 'WINNING' ? 'rgba(16, 185, 129, 0.2)' :
                          b.bid_status === 'OUTBID' ? 'rgba(148, 163, 184, 0.1)' :
                          b.bid_status === 'REJECTED' ? 'rgba(239, 68, 68, 0.2)' :
                          'rgba(59, 130, 246, 0.2)',
                        color:
                          b.bid_status === 'WINNING' ? '#10B981' :
                          b.bid_status === 'OUTBID' ? '#94A3B8' :
                          b.bid_status === 'REJECTED' ? '#EF4444' :
                          '#60A5FA'
                      }}>
                        {b.bid_status}
                      </span>
                    </td>
                    <td style={{ color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                      {formatDateTime(b.created_at)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
