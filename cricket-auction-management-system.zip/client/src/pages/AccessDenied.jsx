import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert, ArrowLeft } from 'lucide-react';

export default function AccessDenied() {
  const navigate = useNavigate();

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '60vh',
      textAlign: 'center',
      gap: '18px'
    }}>
      <div style={{
        width: '64px',
        height: '64px',
        borderRadius: '50%',
        backgroundColor: 'rgba(239, 68, 68, 0.15)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: '#EF4444'
      }}>
        <ShieldAlert size={36} />
      </div>

      <h2 style={{ fontSize: '1.8rem', color: '#FFFFFF', fontWeight: 800 }}>
        403 - ACCESS RESTRICTED
      </h2>

      <p style={{ color: 'var(--text-muted)', maxWidth: '440px', fontSize: '0.95rem' }}>
        You do not have administrative privileges to access this page. This action is restricted to the auctioneer administrator.
      </p>

      <button
        onClick={() => navigate('/dashboard')}
        className="btn btn-primary"
        style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '10px' }}
      >
        <ArrowLeft size={18} />
        <span>Return to Dashboard</span>
      </button>
    </div>
  );
}
