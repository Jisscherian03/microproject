import React, { useState, useEffect, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import {
  Users,
  Search,
  Filter,
  Plus,
  ArrowUpDown,
  X,
  AlertCircle,
  Eye,
  Edit,
  Trash2,
  CheckCircle,
  Globe,
  Activity
} from 'lucide-react';
import { playerService } from '../services/playerService';
import PlayerCard from '../components/player/PlayerCard';
import LoadingSpinner from '../components/common/LoadingSpinner';
import EmptyState from '../components/common/EmptyState';
import ConfirmationModal from '../components/common/ConfirmationModal';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { formatCurrency, getRoleBadgeClass, getStatusBadgeClass } from '../utils/formatters';

export default function Players() {
  const [searchParams, setSearchParams] = useSearchParams();
  const { isAdmin } = useAuth();
  const { showToast } = useToast();

  const [players, setPlayers] = useState([]);
  const [pagination, setPagination] = useState({ page: 1, limit: 12, total: 0, totalPages: 1 });
  const [loading, setLoading] = useState(true);

  // Filter & Search states
  const [search, setSearch] = useState(searchParams.get('search') || '');
  const [role, setRole] = useState(searchParams.get('role') || '');
  const [status, setStatus] = useState(searchParams.get('status') || '');
  const [nationality, setNationality] = useState(searchParams.get('nationality') || '');
  const [sortBy, setSortBy] = useState('player_name');
  const [sortOrder, setSortOrder] = useState('ASC');
  const [page, setPage] = useState(1);

  // Modals state
  const [selectedPlayer, setSelectedPlayer] = useState(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showFormModal, setShowFormModal] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [deletingPlayer, setDeletingPlayer] = useState(null);
  const [saving, setSaving] = useState(false);

  // Form input state
  const [formData, setFormData] = useState({
    player_name: '',
    role: 'Batter',
    nationality: 'India',
    age: '',
    batting_style: 'Right-hand bat',
    bowling_style: 'None',
    base_price: '20000000',
    image_url: '',
    matches_played: '0',
    runs_scored: '0',
    wickets_taken: '0'
  });
  const [formError, setFormError] = useState('');

  const fetchPlayers = useCallback(async () => {
    setLoading(true);
    try {
      const params = {
        page,
        limit: 12,
        search: search.trim() || undefined,
        role: role || undefined,
        status: status || undefined,
        nationality: nationality || undefined,
        sort: sortBy,
        order: sortOrder
      };

      const res = await playerService.getAll(params);
      if (res.success && res.data) {
        setPlayers(res.data.players || []);
        if (res.data.pagination) {
          setPagination(res.data.pagination);
        }
      }
    } catch (err) {
      showToast(err.message || 'Failed to load players', 'error');
    } finally {
      setLoading(false);
    }
  }, [page, search, role, status, nationality, sortBy, sortOrder, showToast]);

  useEffect(() => {
    fetchPlayers();
  }, [fetchPlayers]);

  const handleOpenAddModal = () => {
    setEditingPlayer(null);
    setFormData({
      player_name: '',
      role: 'Batter',
      nationality: 'India',
      age: '25',
      batting_style: 'Right-hand bat',
      bowling_style: 'None',
      base_price: '20000000',
      image_url: '',
      matches_played: '0',
      runs_scored: '0',
      wickets_taken: '0'
    });
    setFormError('');
    setShowFormModal(true);
  };

  const handleOpenEditModal = (player) => {
    setEditingPlayer(player);
    setFormData({
      player_name: player.name || '',
      role: player.role || 'Batter',
      nationality: player.nationality || 'India',
      age: player.age ? player.age.toString() : '',
      batting_style: player.batting_style || '',
      bowling_style: player.bowling_style || '',
      base_price: player.base_price ? player.base_price.toString() : '20000000',
      image_url: player.image_url || '',
      matches_played: player.matches_played ? player.matches_played.toString() : '0',
      runs_scored: player.runs_scored ? player.runs_scored.toString() : '0',
      wickets_taken: player.wickets_taken ? player.wickets_taken.toString() : '0'
    });
    setFormError('');
    setShowFormModal(true);
  };

  const handleSavePlayer = async (e) => {
    e.preventDefault();
    setFormError('');

    if (!formData.player_name.trim()) {
      setFormError('Player name is required.');
      return;
    }
    if (!formData.nationality.trim()) {
      setFormError('Nationality is required.');
      return;
    }
    if (!formData.base_price || Number(formData.base_price) <= 0) {
      setFormError('Base price must be a valid positive amount.');
      return;
    }

    setSaving(true);
    try {
      const payload = {
        ...formData,
        age: formData.age ? parseInt(formData.age, 10) : null,
        base_price: Number(formData.base_price),
        matches_played: parseInt(formData.matches_played || '0', 10),
        runs_scored: parseInt(formData.runs_scored || '0', 10),
        wickets_taken: parseInt(formData.wickets_taken || '0', 10)
      };

      if (editingPlayer) {
        await playerService.update(editingPlayer.id, payload);
        showToast(`Player ${formData.player_name} updated successfully!`, 'success');
      } else {
        await playerService.create(payload);
        showToast(`Player ${formData.player_name} registered successfully!`, 'success');
      }

      setShowFormModal(false);
      fetchPlayers();
    } catch (err) {
      setFormError(err.message || 'Operation failed');
    } finally {
      setSaving(false);
    }
  };

  const handleDeletePlayer = async () => {
    if (!deletingPlayer) return;
    setSaving(true);
    try {
      await playerService.delete(deletingPlayer.id);
      showToast(`Player ${deletingPlayer.name} deleted.`, 'success');
      setDeletingPlayer(null);
      fetchPlayers();
    } catch (err) {
      showToast(err.message || 'Could not delete player', 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Top Action & Filter Bar */}
      <div style={{
        backgroundColor: '#0F172A',
        padding: '20px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)',
        display: 'flex',
        flexDirection: 'column',
        gap: '16px'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: '14px'
        }}>
          <div>
            <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
              CRICKET PLAYERS POOL
            </h2>
            <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
              Manage player registrations, base prices, statistics, and auction qualification status.
            </p>
          </div>

          {isAdmin && (
            <button
              onClick={handleOpenAddModal}
              className="btn btn-primary"
              style={{ display: 'flex', alignItems: 'center', gap: '8px' }}
            >
              <Plus size={18} />
              <span>Register New Player</span>
            </button>
          )}
        </div>

        {/* Filter Controls Row */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
          gap: '12px',
          alignItems: 'center'
        }}>
          {/* Search by name */}
          <div style={{ position: 'relative' }}>
            <input
              type="text"
              className="form-input"
              placeholder="Search player name..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              style={{ paddingLeft: '36px', width: '100%' }}
            />
            <Search size={16} style={{ position: 'absolute', left: '12px', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }} />
          </div>

          {/* Filter by Role */}
          <select
            className="form-select"
            value={role}
            onChange={(e) => {
              setRole(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All Roles</option>
            <option value="Batter">Batter</option>
            <option value="Bowler">Bowler</option>
            <option value="All-rounder">All-rounder</option>
            <option value="Wicketkeeper">Wicketkeeper</option>
          </select>

          {/* Filter by Status */}
          <select
            className="form-select"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All Statuses</option>
            <option value="AVAILABLE">AVAILABLE</option>
            <option value="IN_AUCTION">IN AUCTION</option>
            <option value="SOLD">SOLD</option>
            <option value="UNSOLD">UNSOLD</option>
          </select>

          {/* Sort By */}
          <select
            className="form-select"
            value={`${sortBy}_${sortOrder}`}
            onChange={(e) => {
              const [sb, so] = e.target.value.split('_');
              setSortBy(sb);
              setSortOrder(so);
              setPage(1);
            }}
          >
            <option value="player_name_ASC">Name (A-Z)</option>
            <option value="player_name_DESC">Name (Z-A)</option>
            <option value="base_price_DESC">Base Price (High to Low)</option>
            <option value="base_price_ASC">Base Price (Low to High)</option>
          </select>
        </div>
      </div>

      {/* Players List Grid */}
      {loading ? (
        <LoadingSpinner message="Loading registered players..." />
      ) : players.length === 0 ? (
        <EmptyState
          icon={Users}
          title="No Players Found"
          description="No registered players matched your search criteria or filter selections."
          actionText={isAdmin ? "Register New Player" : undefined}
          onAction={isAdmin ? handleOpenAddModal : undefined}
        />
      ) : (
        <>
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
            gap: '20px'
          }}>
            {players.map((p) => (
              <PlayerCard
                key={p.id}
                player={p}
                isAdmin={isAdmin}
                onView={() => {
                  setSelectedPlayer(p);
                  setShowDetailModal(true);
                }}
                onEdit={() => handleOpenEditModal(p)}
                onDelete={() => setDeletingPlayer(p)}
              />
            ))}
          </div>

          {/* Pagination Controls */}
          {pagination.totalPages > 1 && (
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '12px',
              padding: '16px 0'
            }}>
              <button
                className="btn btn-secondary"
                disabled={page <= 1}
                onClick={() => setPage((prev) => Math.max(1, prev - 1))}
              >
                Previous
              </button>
              <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>
                Page <strong style={{ color: '#FFFFFF' }}>{pagination.page}</strong> of{' '}
                <strong style={{ color: '#FFFFFF' }}>{pagination.totalPages}</strong> ({pagination.total} players)
              </span>
              <button
                className="btn btn-secondary"
                disabled={page >= pagination.totalPages}
                onClick={() => setPage((prev) => Math.min(pagination.totalPages, prev + 1))}
              >
                Next
              </button>
            </div>
          )}
        </>
      )}

      {/* Detail Modal */}
      {showDetailModal && selectedPlayer && (
        <div className="modal-backdrop">
          <div className="modal-content" style={{ maxWidth: '520px' }}>
            <div style={{
              padding: '20px 24px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>Player Profile & Career Stats</h3>
              <button
                onClick={() => setShowDetailModal(false)}
                style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
              >
                <X size={20} />
              </button>
            </div>

            <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '20px' }}>
              <div style={{ display: 'flex', gap: '18px', alignItems: 'center' }}>
                <div style={{
                  width: '80px',
                  height: '95px',
                  borderRadius: '10px',
                  backgroundColor: '#1E293B',
                  overflow: 'hidden',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center'
                }}>
                  {selectedPlayer.image_url ? (
                    <img src={selectedPlayer.image_url} alt={selectedPlayer.name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
                  ) : (
                    <Users size={36} color="#64748B" />
                  )}
                </div>

                <div>
                  <div style={{ display: 'flex', gap: '8px', marginBottom: '4px' }}>
                    <span className={`badge ${getStatusBadgeClass(selectedPlayer.status)}`}>
                      {selectedPlayer.status}
                    </span>
                    <span className={`badge ${getRoleBadgeClass(selectedPlayer.role)}`}>
                      {selectedPlayer.role}
                    </span>
                  </div>
                  <h3 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>{selectedPlayer.name}</h3>
                  <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                    {selectedPlayer.nationality} {selectedPlayer.age && `• Age: ${selectedPlayer.age}`}
                  </div>
                </div>
              </div>

              {/* Career Stats Grid */}
              <div style={{
                backgroundColor: '#090D16',
                borderRadius: '10px',
                padding: '16px',
                display: 'grid',
                gridTemplateColumns: 'repeat(3, 1fr)',
                gap: '12px',
                textAlign: 'center'
              }}>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Matches</div>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700, color: '#FFFFFF' }}>
                    {selectedPlayer.matches_played || 0}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Runs Scored</div>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--gold-primary)' }}>
                    {selectedPlayer.runs_scored || 0}
                  </div>
                </div>
                <div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Wickets</div>
                  <div style={{ fontSize: '1.2rem', fontWeight: 700, color: 'var(--crimson-primary)' }}>
                    {selectedPlayer.wickets_taken || 0}
                  </div>
                </div>
              </div>

              {/* Style & Financials */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '8px', fontSize: '0.9rem' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '8px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Batting Style:</span>
                  <span style={{ color: '#FFFFFF' }}>{selectedPlayer.batting_style || 'Not specified'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '8px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Bowling Style:</span>
                  <span style={{ color: '#FFFFFF' }}>{selectedPlayer.bowling_style || 'Not specified'}</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', paddingTop: '4px' }}>
                  <span style={{ color: 'var(--text-muted)' }}>Base Price:</span>
                  <strong style={{ color: 'var(--gold-primary)', fontSize: '1.1rem' }}>
                    {formatCurrency(selectedPlayer.base_price)}
                  </strong>
                </div>
              </div>
            </div>

            <div style={{ padding: '16px 24px', backgroundColor: '#090D16', borderTop: '1px solid var(--border-subtle)', textAlign: 'right' }}>
              <button className="btn btn-secondary" onClick={() => setShowDetailModal(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Player Modal */}
      {showFormModal && (
        <div className="modal-backdrop">
          <div className="modal-content" style={{ maxWidth: '580px' }}>
            <div style={{
              padding: '20px 24px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>
                {editingPlayer ? `Edit Player: ${editingPlayer.name}` : 'Register New Player for Auction'}
              </h3>
              <button
                onClick={() => setShowFormModal(false)}
                disabled={saving}
                style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSavePlayer}>
              <div style={{ padding: '24px', display: 'flex', flexDirection: 'column', gap: '16px', maxHeight: '65vh', overflowY: 'auto' }}>
                {formError && (
                  <div style={{
                    padding: '10px 14px',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    border: '1px solid #EF4444',
                    borderRadius: '8px',
                    color: '#EF4444',
                    fontSize: '0.85rem'
                  }}>
                    {formError}
                  </div>
                )}

                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input
                    type="text"
                    className="form-input"
                    value={formData.player_name}
                    onChange={(e) => setFormData({ ...formData, player_name: e.target.value })}
                    required
                  />
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div className="form-group">
                    <label className="form-label">Role *</label>
                    <select
                      className="form-select"
                      value={formData.role}
                      onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    >
                      <option value="Batter">Batter</option>
                      <option value="Bowler">Bowler</option>
                      <option value="All-rounder">All-rounder</option>
                      <option value="Wicketkeeper">Wicketkeeper</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label className="form-label">Nationality *</label>
                    <input
                      type="text"
                      className="form-input"
                      value={formData.nationality}
                      onChange={(e) => setFormData({ ...formData, nationality: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div className="form-group">
                    <label className="form-label">Age</label>
                    <input
                      type="number"
                      className="form-input"
                      value={formData.age}
                      onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                      min="15"
                      max="55"
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Base Price (in ₹) *</label>
                    <input
                      type="number"
                      className="form-input"
                      value={formData.base_price}
                      onChange={(e) => setFormData({ ...formData, base_price: e.target.value })}
                      min="1000000"
                      step="500000"
                      required
                    />
                  </div>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
                  <div className="form-group">
                    <label className="form-label">Batting Style</label>
                    <input
                      type="text"
                      className="form-input"
                      placeholder="e.g. Right-hand bat"
                      value={formData.batting_style}
                      onChange={(e) => setFormData({ ...formData, batting_style: e.target.value })}
                    />
                  </div>

                  <div className="form-group">
                    <label className="form-label">Bowling Style</label>
                    <input
                      type="text"
                      className="form-input"
                      placeholder="e.g. Right-arm fast"
                      value={formData.bowling_style}
                      onChange={(e) => setFormData({ ...formData, bowling_style: e.target.value })}
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label className="form-label">Image URL</label>
                  <input
                    type="url"
                    className="form-input"
                    placeholder="https://..."
                    value={formData.image_url}
                    onChange={(e) => setFormData({ ...formData, image_url: e.target.value })}
                  />
                </div>

                {/* Career Statistics */}
                <div style={{
                  backgroundColor: '#090D16',
                  padding: '14px',
                  borderRadius: '8px',
                  border: '1px solid var(--border-subtle)'
                }}>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '10px', fontWeight: 600 }}>
                    Career Statistics (Optional)
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Matches</label>
                      <input
                        type="number"
                        className="form-input"
                        value={formData.matches_played}
                        onChange={(e) => setFormData({ ...formData, matches_played: e.target.value })}
                        min="0"
                      />
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Runs</label>
                      <input
                        type="number"
                        className="form-input"
                        value={formData.runs_scored}
                        onChange={(e) => setFormData({ ...formData, runs_scored: e.target.value })}
                        min="0"
                      />
                    </div>
                    <div>
                      <label style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Wickets</label>
                      <input
                        type="number"
                        className="form-input"
                        value={formData.wickets_taken}
                        onChange={(e) => setFormData({ ...formData, wickets_taken: e.target.value })}
                        min="0"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div style={{
                padding: '16px 24px',
                backgroundColor: '#090D16',
                borderTop: '1px solid var(--border-subtle)',
                display: 'flex',
                justifyContent: 'flex-end',
                gap: '12px'
              }}>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={() => setShowFormModal(false)}
                  disabled={saving}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                  disabled={saving}
                >
                  {saving ? 'Saving...' : editingPlayer ? 'Update Player' : 'Register Player'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <ConfirmationModal
        isOpen={!!deletingPlayer}
        title="Delete Player"
        message={`Are you sure you want to delete ${deletingPlayer?.name}? If this player has past auction bids or purchases, the database will reject the deletion to protect ledger history.`}
        confirmText="Delete Player"
        isDanger={true}
        loading={saving}
        onConfirm={handleDeletePlayer}
        onCancel={() => setDeletingPlayer(null)}
      />
    </div>
  );
}
