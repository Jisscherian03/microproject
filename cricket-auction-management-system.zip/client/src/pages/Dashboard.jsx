import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Gavel,
  Users,
  Shield,
  TrendingUp,
  DollarSign,
  Award,
  Activity,
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Plus
} from 'lucide-react';
import { dashboardService } from '../services/dashboardService';
import SummaryCard from '../components/common/SummaryCard';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { useAuth } from '../context/AuthContext';
import { useAuction } from '../context/AuctionContext';
import { formatCurrency, formatTimeAgo, getRoleBadgeClass, getStatusBadgeClass } from '../utils/formatters';

export default function Dashboard() {
  const navigate = useNavigate();
  const { isAdmin, isTeamUser, user } = useAuth();
  const { currentAuction, isConnected } = useAuction();

  const [statsData, setStatsData] = useState(null);
  const [activities, setActivities] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState(null);

  const fetchDashboardData = useCallback(async () => {
    try {
      setError(null);
      const [statsRes, activityRes] = await Promise.all([
        dashboardService.getStats(),
        dashboardService.getActivity(10).catch(() => ({ data: [] }))
      ]);

      if (statsRes.success) {
        setStatsData(statsRes.data);
      }
      if (activityRes.success && activityRes.data) {
        const rawList = activityRes.data.recent_logs || (Array.isArray(activityRes.data) ? activityRes.data : []);
        setActivities(Array.isArray(rawList) ? rawList : []);
      }
    } catch (err) {
      console.error('Failed to load dashboard:', err);
      setError(err.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 8000);
    return () => clearInterval(interval);
  }, [fetchDashboardData]);

  const handleManualRefresh = () => {
    setRefreshing(true);
    fetchDashboardData();
  };

  if (loading) {
    return <LoadingSpinner message="Loading live IPL auction dashboard..." />;
  }

  const summary = statsData?.summary || {
    total_teams: 0,
    total_players: 0,
    players_sold: 0,
    players_unsold: 0,
    players_remaining: 0,
    total_spending: 0,
    auction_status: 'IDLE'
  };

  const teamsOverview = statsData?.teams_overview || [];
  const activeAuction = statsData?.current_auction || currentAuction;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Stadium Banner & Quick Action Header */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(225, 6, 0, 0.25) 0%, rgba(15, 23, 42, 0.95) 100%)',
        border: '1px solid var(--border-accent)',
        borderRadius: '16px',
        padding: '24px 28px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px',
        boxShadow: '0 8px 32px rgba(0, 0, 0, 0.5)'
      }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px', marginBottom: '6px' }}>
            <span style={{
              backgroundColor: 'var(--crimson-primary)',
              color: '#FFFFFF',
              fontSize: '0.7rem',
              fontWeight: 800,
              padding: '3px 8px',
              borderRadius: '4px',
              letterSpacing: '0.8px'
            }}>
              MCA COLLEGE MICROPROJECT
            </span>
            <span style={{ color: 'var(--text-gold)', fontSize: '0.8rem', fontWeight: 600 }}>
              • IPL Premier Auction Engine
            </span>
          </div>
          <h2 style={{ fontSize: '1.6rem', color: '#FFFFFF', fontWeight: 800 }}>
            Welcome, {user?.username} ({isAdmin ? 'System Administrator' : user?.team?.name || 'Franchise Representative'})
          </h2>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem' }}>
            Live relational database statistics, real-time bid engine, and purse balance tracking.
          </p>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button
            onClick={handleManualRefresh}
            className="btn btn-secondary"
            disabled={refreshing}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <RefreshCw size={16} className={refreshing ? 'animate-spin' : ''} />
            <span>Refresh</span>
          </button>

          <button
            onClick={() => navigate('/auction')}
            className="btn btn-primary"
            style={{ display: 'flex', alignItems: 'center', gap: '8px', padding: '10px 20px' }}
          >
            <Gavel size={18} />
            <span>Enter Auction Arena</span>
          </button>
        </div>
      </div>

      {error && (
        <div style={{
          padding: '12px 18px',
          backgroundColor: 'rgba(239, 68, 68, 0.15)',
          border: '1px solid #EF4444',
          borderRadius: '8px',
          color: '#EF4444',
          display: 'flex',
          alignItems: 'center',
          gap: '10px'
        }}>
          <AlertCircle size={20} />
          <span>{error}</span>
        </div>
      )}

      {/* Top 6 Summary Cards */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
        gap: '16px'
      }}>
        <SummaryCard
          title="Total Franchises"
          value={summary.total_teams}
          subtitle="Registered Teams"
          icon={Shield}
          accentColor="#3B82F6"
          onClick={() => navigate('/teams')}
        />
        <SummaryCard
          title="Total Players"
          value={summary.total_players}
          subtitle="Registered in Pool"
          icon={Users}
          accentColor="#8B5CF6"
          onClick={() => navigate('/players')}
        />
        <SummaryCard
          title="Players Sold"
          value={summary.players_sold}
          subtitle={`${((summary.players_sold / (summary.total_players || 1)) * 100).toFixed(0)}% Acquired`}
          icon={CheckCircle2}
          accentColor="#10B981"
          onClick={() => navigate('/purchases')}
        />
        <SummaryCard
          title="Players Unsold"
          value={summary.players_unsold}
          subtitle="Awaiting Second Pass"
          icon={AlertCircle}
          accentColor="#EF4444"
          onClick={() => navigate('/players?status=UNSOLD')}
        />
        <SummaryCard
          title="Pool Remaining"
          value={summary.players_remaining}
          subtitle="Ready for Auction"
          icon={Activity}
          accentColor="#F59E0B"
          onClick={() => navigate('/players?status=AVAILABLE')}
        />
        <SummaryCard
          title="Total Spent"
          value={formatCurrency(summary.total_spending)}
          subtitle="Aggregate Expenditure"
          icon={TrendingUp}
          accentColor="var(--crimson-primary)"
          onClick={() => navigate('/reports')}
        />
      </div>

      {/* Main Grid: Active Player Spotlight & Team Spending */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.4fr 1fr',
        gap: '24px'
      }}>
        {/* Left Column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Current Live Auction Card */}
          <div className="card" style={{
            background: 'linear-gradient(180deg, #131B2E 0%, #0D1322 100%)',
            border: '1px solid rgba(225, 6, 0, 0.35)',
            position: 'relative',
            overflow: 'hidden'
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '18px',
              borderBottom: '1px solid var(--border-subtle)',
              paddingBottom: '14px'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                <div style={{
                  width: '10px',
                  height: '10px',
                  borderRadius: '50%',
                  backgroundColor: activeAuction ? '#10B981' : '#64748B',
                  boxShadow: activeAuction ? '0 0 10px #10B981' : 'none'
                }} />
                <h3 style={{ fontSize: '1.15rem', color: '#FFFFFF', fontWeight: 700 }}>
                  CURRENT AUCTION SPOTLIGHT
                </h3>
              </div>

              {activeAuction && (
                <span className={`badge ${getStatusBadgeClass(activeAuction.status)}`}>
                  {activeAuction.status}
                </span>
              )}
            </div>

            {activeAuction ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
                  <div style={{
                    width: '100px',
                    height: '115px',
                    borderRadius: '10px',
                    backgroundColor: '#1E293B',
                    border: '1px solid var(--border-subtle)',
                    overflow: 'hidden',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0
                  }}>
                    {activeAuction.player?.image_url ? (
                      <img
                        src={activeAuction.player.image_url}
                        alt={activeAuction.player.name}
                        style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                      />
                    ) : (
                      <Users size={36} color="#64748B" />
                    )}
                  </div>

                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', marginBottom: '4px' }}>
                      <span className={`badge ${getRoleBadgeClass(activeAuction.player?.role)}`}>
                        {activeAuction.player?.role}
                      </span>
                      <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                        {activeAuction.player?.nationality}
                      </span>
                    </div>
                    <h3 style={{ fontSize: '1.4rem', color: '#FFFFFF', fontWeight: 800 }}>
                      {activeAuction.player?.name}
                    </h3>
                    <div style={{ fontSize: '0.85rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                      Base Price: <strong style={{ color: '#FFFFFF' }}>{formatCurrency(activeAuction.player?.base_price)}</strong>
                    </div>
                  </div>
                </div>

                {/* Highest Bid Showcase */}
                <div style={{
                  backgroundColor: '#070B14',
                  borderRadius: '10px',
                  padding: '16px 20px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  border: '1px solid rgba(245, 158, 11, 0.2)'
                }}>
                  <div>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                      Current Highest Bid
                    </div>
                    <div style={{
                      fontSize: '1.7rem',
                      fontWeight: 800,
                      color: 'var(--gold-primary)',
                      fontFamily: 'var(--font-heading)'
                    }}>
                      {formatCurrency(activeAuction.current_bid)}
                    </div>
                  </div>

                  <div style={{ textAlign: 'right' }}>
                    <div style={{ fontSize: '0.75rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
                      Leading Franchise
                    </div>
                    <div style={{
                      fontSize: '1.1rem',
                      fontWeight: 700,
                      color: activeAuction.leading_team ? '#FFFFFF' : 'var(--text-muted)'
                    }}>
                      {activeAuction.leading_team ? (
                        <span>
                          {activeAuction.leading_team.name} ({activeAuction.leading_team.code})
                        </span>
                      ) : (
                        'No bids placed yet'
                      )}
                    </div>
                  </div>
                </div>

                <button
                  onClick={() => navigate('/auction')}
                  className="btn btn-primary"
                  style={{ width: '100%', padding: '12px', fontSize: '0.95rem' }}
                >
                  <span>Go to Live Bidding Control Center</span>
                  <ArrowRight size={18} />
                </button>
              </div>
            ) : (
              <div style={{ textAlign: 'center', padding: '36px 16px', color: 'var(--text-muted)' }}>
                <Gavel size={40} style={{ margin: '0 auto 12px', opacity: 0.4 }} />
                <h4 style={{ color: '#FFFFFF', fontSize: '1.1rem', marginBottom: '6px' }}>
                  No Active Auction Running
                </h4>
                <p style={{ fontSize: '0.85rem', maxWidth: '380px', margin: '0 auto 16px' }}>
                  All bidding is currently paused. Administrators can select an available player and start an auction.
                </p>
                {isAdmin ? (
                  <button onClick={() => navigate('/auction')} className="btn btn-primary">
                    <Plus size={16} />
                    <span>Start New Player Auction</span>
                  </button>
                ) : (
                  <span style={{ fontSize: '0.8rem', color: 'var(--gold-primary)' }}>
                    Waiting for auctioneer to bring the next player to the block.
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Franchise Budget & Spending Bar Comparison */}
          <div className="card">
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '18px'
            }}>
              <div>
                <h3 style={{ fontSize: '1.15rem', color: '#FFFFFF', fontWeight: 700 }}>
                  FRANCHISE SPENDING & PURSE COMPARISON
                </h3>
                <p style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                  Total initial purse: ₹100.00 Cr per team. Calculated dynamically from purchases.
                </p>
              </div>
              <button
                onClick={() => navigate('/teams')}
                className="btn btn-outline"
                style={{ fontSize: '0.8rem', padding: '6px 12px' }}
              >
                View All
              </button>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
              {teamsOverview.map((team) => {
                const initial = Number(team.initial_purse || 1000000000);
                const spent = Number(team.total_spent || 0);
                const remaining = Number(team.remaining_purse || 0);
                const percentSpent = Math.min(100, (spent / initial) * 100);

                return (
                  <div key={team.id} style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        <span style={{
                          padding: '2px 6px',
                          backgroundColor: '#1E293B',
                          borderRadius: '4px',
                          fontSize: '0.75rem',
                          fontWeight: 700,
                          color: 'var(--text-gold)'
                        }}>
                          {team.code}
                        </span>
                        <span style={{ fontSize: '0.9rem', color: '#FFFFFF', fontWeight: 600 }}>
                          {team.name}
                        </span>
                        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                          ({team.squad_count} players)
                        </span>
                      </div>

                      <div style={{ display: 'flex', gap: '16px', fontSize: '0.85rem' }}>
                        <span style={{ color: 'var(--text-muted)' }}>
                          Spent: <strong style={{ color: 'var(--crimson-primary)' }}>{formatCurrency(spent)}</strong>
                        </span>
                        <span style={{ color: 'var(--text-muted)' }}>
                          Purse: <strong style={{ color: '#10B981' }}>{formatCurrency(remaining)}</strong>
                        </span>
                      </div>
                    </div>

                    {/* Progress Bar */}
                    <div style={{
                      height: '8px',
                      backgroundColor: '#1E293B',
                      borderRadius: '4px',
                      overflow: 'hidden'
                    }}>
                      <div style={{
                        height: '100%',
                        width: `${percentSpent}%`,
                        background: percentSpent > 80 ? 'linear-gradient(90deg, #F59E0B, #EF4444)' : 'linear-gradient(90deg, #2563EB, #10B981)',
                        borderRadius: '4px',
                        transition: 'width 0.4s ease'
                      }} />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Recent Activity & Quick Navigation */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Quick Actions (Admin & Team) */}
          <div className="card">
            <h3 style={{ fontSize: '1.1rem', color: '#FFFFFF', fontWeight: 700, marginBottom: '14px' }}>
              QUICK ACTIONS
            </h3>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
              <button
                onClick={() => navigate('/auction')}
                className="btn btn-secondary"
                style={{ justifyContent: 'space-between', padding: '12px 16px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Gavel size={18} color="var(--crimson-primary)" />
                  <span>Auction Control Arena</span>
                </div>
                <ArrowRight size={16} />
              </button>

              <button
                onClick={() => navigate('/players')}
                className="btn btn-secondary"
                style={{ justifyContent: 'space-between', padding: '12px 16px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Users size={18} color="#8B5CF6" />
                  <span>Browse Players Pool</span>
                </div>
                <ArrowRight size={16} />
              </button>

              <button
                onClick={() => navigate('/teams')}
                className="btn btn-secondary"
                style={{ justifyContent: 'space-between', padding: '12px 16px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Shield size={18} color="#3B82F6" />
                  <span>Franchise Squads & Budgets</span>
                </div>
                <ArrowRight size={16} />
              </button>

              <button
                onClick={() => navigate('/reports')}
                className="btn btn-secondary"
                style={{ justifyContent: 'space-between', padding: '12px 16px' }}
              >
                <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                  <Award size={18} color="var(--gold-primary)" />
                  <span>Auction Reports & Analytics</span>
                </div>
                <ArrowRight size={16} />
              </button>
            </div>
          </div>

          {/* Recent Activity Log */}
          <div className="card" style={{ flex: 1 }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              marginBottom: '16px',
              borderBottom: '1px solid var(--border-subtle)',
              paddingBottom: '12px'
            }}>
              <h3 style={{ fontSize: '1.1rem', color: '#FFFFFF', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Activity size={18} color="var(--crimson-primary)" />
                <span>RECENT ACTIVITY</span>
              </h3>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Live Stream</span>
            </div>

            {!Array.isArray(activities) || activities.length === 0 ? (
              <div style={{ textAlign: 'center', padding: '24px 8px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
                No recent activity recorded yet.
              </div>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '12px', maxHeight: '420px', overflowY: 'auto' }}>
                {activities.map((act, idx) => {
                  const actionStr = String(act?.action || 'EVENT');
                  return (
                    <div
                      key={act?.id || idx}
                      style={{
                        padding: '10px 12px',
                        backgroundColor: '#090D16',
                        borderRadius: '8px',
                        borderLeft: `3px solid ${
                          actionStr.includes('SOLD') ? '#10B981' :
                          actionStr.includes('BID') ? 'var(--gold-primary)' :
                          actionStr.includes('UNSOLD') ? '#EF4444' : 'var(--blue-accent)'
                        }`
                      }}
                    >
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                        <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#FFFFFF' }}>
                          {actionStr.replaceAll('_', ' ')}
                        </span>
                        <span style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
                          {formatTimeAgo(act?.created_at)}
                        </span>
                      </div>
                      <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                        {typeof act?.details === 'object' ? (
                          act?.details?.message ||
                          (act?.details?.player && `${act?.details?.player} • ${act?.details?.team || ''}`) ||
                          JSON.stringify(act?.details || {})
                        ) : (
                          act?.details || 'System event triggered'
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
