import React from 'react';
import { useNavigate } from 'react-router-dom';
import { HelpCircle, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  const navigate = useNavigate();

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      minHeight: '60vh',
      textAlign: 'center',
      gap: '18px'
    }}>
      <div style={{
        width: '64px',
        height: '64px',
        borderRadius: '50%',
        backgroundColor: 'rgba(245, 158, 11, 0.15)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--gold-primary)'
      }}>
        <HelpCircle size={36} />
      </div>

      <h2 style={{ fontSize: '1.8rem', color: '#FFFFFF', fontWeight: 800 }}>
        404 - PAGE NOT FOUND
      </h2>

      <p style={{ color: 'var(--text-muted)', maxWidth: '440px', fontSize: '0.95rem' }}>
        The requested URL was not found on this auction system. Please check the address or return to the main dashboard.
      </p>

      <button
        onClick={() => navigate('/dashboard')}
        className="btn btn-primary"
        style={{ display: 'flex', alignItems: 'center', gap: '8px', marginTop: '10px' }}
      >
        <ArrowLeft size={18} />
        <span>Return to Dashboard</span>
      </button>
    </div>
  );
}
