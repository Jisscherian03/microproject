import React, { useState, useEffect } from 'react';
import { Gavel, Users, Shield, RefreshCw, AlertCircle, Sparkles } from 'lucide-react';
import { useAuction } from '../context/AuctionContext';
import { useAuth } from '../context/AuthContext';
import AuctionPlayerPanel from '../components/auction/AuctionPlayerPanel';
import AdminAuctionControls from '../components/auction/AdminAuctionControls';
import BidForm from '../components/auction/BidForm';
import BidHistoryTable from '../components/auction/BidHistoryTable';
import LoadingSpinner from '../components/common/LoadingSpinner';
import { formatCurrency } from '../utils/formatters';

export default function AuctionArena() {
  const { currentAuction, bids, teams, loading, refreshAuction, refreshTeams } = useAuction();
  const { isAdmin, isTeamUser, user } = useAuth();
  const [manualLoading, setManualLoading] = useState(false);

  const handleManualRefresh = async () => {
    setManualLoading(true);
    await Promise.all([refreshAuction(), refreshTeams()]);
    setManualLoading(false);
  };

  if (loading) {
    return <LoadingSpinner message="Entering Live Cricket Auction Arena..." />;
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
      {/* Arena Header Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        flexWrap: 'wrap',
        gap: '16px',
        backgroundColor: '#0F172A',
        padding: '16px 24px',
        borderRadius: '12px',
        border: '1px solid var(--border-subtle)'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
          <div style={{
            width: '42px',
            height: '42px',
            borderRadius: '10px',
            backgroundColor: 'rgba(225, 6, 0, 0.2)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'var(--crimson-primary)'
          }}>
            <Gavel size={24} />
          </div>
          <div>
            <h2 style={{ fontSize: '1.3rem', color: '#FFFFFF', fontWeight: 800 }}>
              AUCTION CONTROL CENTER
            </h2>
            <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
              Official IPL-grade real-time bidding arena with atomic transaction settlement.
            </div>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
          <button
            onClick={handleManualRefresh}
            className="btn btn-secondary"
            disabled={manualLoading}
            style={{ display: 'flex', alignItems: 'center', gap: '6px' }}
          >
            <RefreshCw size={16} className={manualLoading ? 'animate-spin' : ''} />
            <span>Sync Live State</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Left (Player + Bidding) | Right (Bids Table + Eligible Teams) */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.35fr 1fr',
        gap: '24px'
      }}>
        {/* Left Column: Player Card & Admin Controls & Bid Form */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Active Player Panel */}
          <AuctionPlayerPanel auction={currentAuction} />

          {/* Admin Controls Panel (Admin Only) */}
          {isAdmin && (
            <AdminAuctionControls
              auction={currentAuction}
              onStateChange={() => {
                refreshAuction();
                refreshTeams();
              }}
            />
          )}

          {/* Bid Submission Form */}
          <BidForm
            auction={currentAuction}
            teams={teams}
            onBidPlaced={() => {
              refreshAuction();
              refreshTeams();
            }}
          />
        </div>

        {/* Right Column: Live Bid Stream & Eligible Franchises Purses */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          {/* Live Bid History for this auction */}
          <BidHistoryTable bids={bids} />

          {/* Eligible Franchises & Remaining Purses */}
          <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
            <div style={{
              padding: '16px 20px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              backgroundColor: '#0D1322'
            }}>
              <h4 style={{ fontSize: '1rem', color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Shield size={18} color="#3B82F6" />
                <span>FRANCHISE PURSES & SQUADS ({teams.length})</span>
              </h4>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Real-time Balances</span>
            </div>

            <div style={{ maxHeight: '360px', overflowY: 'auto' }}>
              <table className="custom-table">
                <thead>
                  <tr>
                    <th>Franchise</th>
                    <th>Squad</th>
                    <th>Remaining Purse</th>
                  </tr>
                </thead>
                <tbody>
                  {teams.map((t) => {
                    const isMyTeam = isTeamUser && user?.team_id === t.id;
                    const isLeading = currentAuction?.leading_team?.id === t.id;

                    return (
                      <tr
                        key={t.id}
                        style={{
                          backgroundColor: isLeading
                            ? 'rgba(245, 158, 11, 0.08)'
                            : isMyTeam
                            ? 'rgba(37, 99, 235, 0.08)'
                            : 'transparent'
                        }}
                      >
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <span style={{
                              padding: '2px 6px',
                              backgroundColor: '#1E293B',
                              borderRadius: '4px',
                              fontSize: '0.75rem',
                              fontWeight: 700,
                              color: 'var(--text-gold)'
                            }}>
                              {t.code}
                            </span>
                            <span style={{
                              fontSize: '0.85rem',
                              fontWeight: 600,
                              color: isLeading ? 'var(--gold-primary)' : '#FFFFFF'
                            }}>
                              {t.name}
                              {isMyTeam && ' (You)'}
                              {isLeading && ' ⭐ (Leader)'}
                            </span>
                          </div>
                        </td>
                        <td style={{ fontSize: '0.85rem', color: 'var(--text-muted)' }}>
                          <strong style={{ color: '#FFFFFF' }}>{t.squad_count || 0}</strong> players
                        </td>
                        <td>
                          <strong style={{
                            fontSize: '0.9rem',
                            color: Number(t.remaining_purse) > 20000000 ? '#10B981' : '#EF4444',
                            fontFamily: 'var(--font-heading)'
                          }}>
                            {formatCurrency(t.remaining_purse)}
                          </strong>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
