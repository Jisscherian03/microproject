/**
 * Client-side formatting helpers
 */

export function formatCurrency(amount) {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return '₹0.00';
  }

  const num = Number(amount);
  const isNegative = num < 0;
  const absNum = Math.abs(num);

  let formatted = '';
  // 1 Crore = 10,000,000
  if (absNum >= 10000000) {
    formatted = `₹${(absNum / 10000000).toFixed(2)} Cr`;
  }
  // 1 Lakh = 100,000
  else if (absNum >= 100000) {
    formatted = `₹${(absNum / 100000).toFixed(2)} L`;
  } else {
    formatted = `₹${absNum.toLocaleString('en-IN', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    })}`;
  }

  return isNegative ? `-${formatted}` : formatted;
}

export function formatDateTime(dateStr) {
  if (!dateStr) return '—';
  const d = new Date(dateStr);
  return d.toLocaleString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });
}

export function formatTimeAgo(dateStr) {
  if (!dateStr) return '';
  const seconds = Math.floor((new Date() - new Date(dateStr)) / 1000);
  if (seconds < 60) return `${Math.max(1, seconds)}s ago`;
  const minutes = Math.floor(seconds / 60);
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

export function getRoleBadgeClass(role) {
  switch (role) {
    case 'Batter': return 'badge-batter';
    case 'Bowler': return 'badge-bowler';
    case 'All-rounder': return 'badge-allrounder';
    case 'Wicketkeeper': return 'badge-wicketkeeper';
    default: return 'badge-batter';
  }
}

export function getStatusBadgeClass(status) {
  switch (status) {
    case 'AVAILABLE': return 'status-available';
    case 'IN_AUCTION': return 'status-in_auction';
    case 'SOLD': return 'status-sold';
    case 'UNSOLD': return 'status-unsold';
    default: return 'status-available';
  }
}
