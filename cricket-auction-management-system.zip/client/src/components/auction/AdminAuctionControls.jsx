import React, { useState } from 'react';
import { Play, Pause, Square, CheckCircle, XCircle, PlusCircle, ShieldAlert } from 'lucide-react';
import { auctionService } from '../../services/auctionService';
import { playerService } from '../../services/playerService';
import { formatCurrency } from '../../utils/formatters';
import { useToast } from '../../context/ToastContext';
import ConfirmationModal from '../common/ConfirmationModal';

export default function AdminAuctionControls({ auction, onStateChange }) {
  const { showToast } = useToast();

  const [loading, setLoading] = useState(false);
  const [showSellModal, setShowSellModal] = useState(false);
  const [showUnsoldModal, setShowUnsoldModal] = useState(false);
  const [showNextPlayerModal, setShowNextPlayerModal] = useState(false);
  const [availablePlayers, setAvailablePlayers] = useState([]);
  const [loadingPlayers, setLoadingPlayers] = useState(false);

  const handleStart = async () => {
    if (!auction) return;
    setLoading(true);
    try {
      await auctionService.start(auction.id);
      showToast('Auction started! Bidding is OPEN.', 'success');
      if (onStateChange) onStateChange();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handlePause = async () => {
    if (!auction) return;
    setLoading(true);
    try {
      await auctionService.pause(auction.id);
      showToast('Bidding paused.', 'warning');
      if (onStateChange) onStateChange();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleResume = async () => {
    if (!auction) return;
    setLoading(true);
    try {
      await auctionService.resume(auction.id);
      showToast('Bidding resumed! OPEN.', 'success');
      if (onStateChange) onStateChange();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = async () => {
    if (!auction) return;
    setLoading(true);
    try {
      await auctionService.close(auction.id);
      showToast('Bidding closed.', 'warning');
      if (onStateChange) onStateChange();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmSell = async () => {
    if (!auction) return;
    setLoading(true);
    try {
      const res = await auctionService.sell(auction.id);
      showToast(`SOLD to ${auction.leading_team?.name}!`, 'success');
      setShowSellModal(false);
      if (onStateChange) onStateChange();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmUnsold = async () => {
    if (!auction) return;
    setLoading(true);
    try {
      await auctionService.markUnsold(auction.id);
      showToast('Player marked as UNSOLD.', 'warning');
      setShowUnsoldModal(false);
      if (onStateChange) onStateChange();
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const openNextPlayerModal = async () => {
    setShowNextPlayerModal(true);
    setLoadingPlayers(true);
    try {
      const res = await playerService.getAll({ status: 'AVAILABLE', limit: 30 });
      if (res.success && res.data) {
        setAvailablePlayers(res.data.players || []);
      }
    } catch (err) {
      showToast('Failed to load available players', 'error');
    } finally {
      setLoadingPlayers(false);
    }
  };

  const handleSelectPlayerForAuction = async (playerId) => {
    setLoading(true);
    try {
      const res = await auctionService.create(playerId);
      if (res.success) {
        showToast('Player brought to the auction block!', 'success');
        setShowNextPlayerModal(false);
        if (onStateChange) onStateChange();
      }
    } catch (err) {
      showToast(err.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  const status = auction?.status;
  const hasBids = auction && Number(auction.current_bid) > 0 && !!auction.leading_team;

  return (
    <div className="card" style={{ border: '1px solid var(--border-accent)' }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '16px',
        borderBottom: '1px solid var(--border-subtle)',
        paddingBottom: '12px'
      }}>
        <h3 style={{ fontSize: '1.15rem', color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <ShieldAlert size={20} color="var(--crimson-primary)" />
          <span>AUCTIONEER DESK (ADMIN CONTROLS)</span>
        </h3>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
          Status: <strong style={{ color: '#FFFFFF' }}>{status || 'IDLE'}</strong>
        </span>
      </div>

      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '10px' }}>
        {/* Start / Open */}
        {(status === 'READY' || status === 'DRAFT') && (
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleStart}
            disabled={loading}
          >
            <Play size={16} /> Start Bidding
          </button>
        )}

        {/* Pause Bidding */}
        {status === 'OPEN' && (
          <button
            type="button"
            className="btn btn-secondary"
            onClick={handlePause}
            disabled={loading}
          >
            <Pause size={16} /> Pause Bidding
          </button>
        )}

        {/* Resume Bidding */}
        {status === 'PAUSED' && (
          <button
            type="button"
            className="btn btn-primary"
            onClick={handleResume}
            disabled={loading}
          >
            <Play size={16} /> Resume Bidding
          </button>
        )}

        {/* Close Bidding */}
        {(status === 'OPEN' || status === 'PAUSED') && (
          <button
            type="button"
            className="btn btn-outline"
            onClick={handleClose}
            disabled={loading}
          >
            <Square size={16} /> Close Bids
          </button>
        )}

        {/* Sell to Highest Bidder */}
        {['OPEN', 'PAUSED', 'CLOSED'].includes(status) && (
          <button
            type="button"
            className="btn btn-gold"
            onClick={() => setShowSellModal(true)}
            disabled={loading || !hasBids}
            title={!hasBids ? 'Cannot sell without valid bids' : 'Finalize sale to current highest bidder'}
          >
            <CheckCircle size={16} /> Sell to Highest Bidder
          </button>
        )}

        {/* Mark Unsold */}
        {['OPEN', 'PAUSED', 'CLOSED'].includes(status) && (
          <button
            type="button"
            className="btn btn-danger"
            onClick={() => setShowUnsoldModal(true)}
            disabled={loading}
          >
            <XCircle size={16} /> Mark Unsold
          </button>
        )}

        {/* Bring Next Player */}
        <button
          type="button"
          className="btn btn-secondary"
          onClick={openNextPlayerModal}
          disabled={loading || ['OPEN', 'PAUSED'].includes(status)}
          style={{ marginLeft: 'auto' }}
        >
          <PlusCircle size={16} /> Next Player Pool
        </button>
      </div>

      {/* Confirmation Modal for Selling */}
      <ConfirmationModal
        isOpen={showSellModal}
        title="Hammer Down: Confirm Sale"
        message={`Are you sure you want to sell ${auction?.player?.name} to ${auction?.leading_team?.name} for ${formatCurrency(auction?.current_bid)}? This action will immediately deduct the purse, assign the player to the squad, and record the purchase ledger.`}
        confirmText="Confirm Sale"
        onConfirm={handleConfirmSell}
        onCancel={() => setShowSellModal(false)}
        loading={loading}
      />

      {/* Confirmation Modal for Unsold */}
      <ConfirmationModal
        isOpen={showUnsoldModal}
        title="Confirm Mark Unsold"
        message={`Mark ${auction?.player?.name} as UNSOLD? The player will remain unsold for this round.`}
        confirmText="Mark Unsold"
        isDanger={true}
        onConfirm={handleConfirmUnsold}
        onCancel={() => setShowUnsoldModal(false)}
        loading={loading}
      />

      {/* Select Next Player Modal */}
      {showNextPlayerModal && (
        <div className="modal-backdrop">
          <div className="modal-content" style={{ maxWidth: '640px' }}>
            <div style={{
              padding: '20px 24px',
              borderBottom: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between'
            }}>
              <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>
                Select Next Player for Auction Block
              </h3>
              <button
                onClick={() => setShowNextPlayerModal(false)}
                style={{ background: 'transparent', border: 'none', color: 'var(--text-muted)', cursor: 'pointer' }}
              >
                ✕
              </button>
            </div>

            <div style={{ padding: '20px 24px', maxHeight: '400px', overflowY: 'auto' }}>
              {loadingPlayers ? (
                <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text-muted)' }}>
                  Loading available players...
                </div>
              ) : availablePlayers.length === 0 ? (
                <div style={{ textAlign: 'center', padding: '24px', color: 'var(--text-muted)' }}>
                  No available players remaining in the pool!
                </div>
              ) : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  {availablePlayers.map((p) => (
                    <div
                      key={p.id}
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '12px 16px',
                        backgroundColor: '#141E33',
                        borderRadius: '8px',
                        border: '1px solid var(--border-subtle)'
                      }}
                    >
                      <div>
                        <strong style={{ color: '#FFFFFF', fontSize: '0.95rem' }}>{p.name}</strong>
                        <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>
                          {p.role} • {p.nationality} • Base: {formatCurrency(p.base_price)}
                        </div>
                      </div>
                      <button
                        type="button"
                        className="btn btn-primary"
                        style={{ fontSize: '0.8rem', padding: '6px 14px' }}
                        onClick={() => handleSelectPlayerForAuction(p.id)}
                        disabled={loading}
                      >
                        Bring to Block
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
