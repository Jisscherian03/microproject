import React, { useState, useEffect } from 'react';
import { Gavel, AlertCircle, TrendingUp, Check } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';
import { auctionService } from '../../services/auctionService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';

export default function BidForm({ auction, teams, onBidPlaced }) {
  const { user, isAdmin, isTeamUser } = useAuth();
  const { showToast } = useToast();

  const [selectedTeamId, setSelectedTeamId] = useState('');
  const [bidAmount, setBidAmount] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Determine current active team
  useEffect(() => {
    if (isTeamUser && user?.team_id) {
      setSelectedTeamId(user.team_id.toString());
    } else if (teams.length > 0 && !selectedTeamId) {
      setSelectedTeamId(teams[0].id.toString());
    }
  }, [isTeamUser, user, teams, selectedTeamId]);

  if (!auction || auction.status !== 'OPEN') {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '24px', color: 'var(--text-muted)' }}>
        <p style={{ fontSize: '0.95rem' }}>
          {auction?.status === 'PAUSED' ? '⏸️ Bidding is currently paused by admin.' :
           auction?.status === 'CLOSED' ? '🔒 Bidding is closed. Awaiting sale or unsold decision.' :
           auction?.status === 'SOLD' ? '🏆 Player has been sold!' :
           'Bidding is inactive.'}
        </p>
      </div>
    );
  }

  const currentBid = Number(auction.current_bid);
  const basePrice = Number(auction.player.base_price);
  const increment = Number(auction.settings?.minimum_bid_increment || 2000000);

  const minNextBid = currentBid === 0 ? basePrice : currentBid + increment;

  // Find selected team details
  const currentTeam = teams.find(t => t.id === parseInt(selectedTeamId, 10));
  const remainingPurse = currentTeam ? Number(currentTeam.remaining_purse) : 0;
  const isAffordable = bidAmount ? Number(bidAmount) <= remainingPurse : true;
  const isLeader = auction.leading_team?.id === parseInt(selectedTeamId, 10);

  const handleQuickBid = (amount) => {
    setBidAmount(amount.toString());
    setErrorMsg('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');

    const numericBid = Number(bidAmount);
    if (!numericBid || isNaN(numericBid)) {
      setErrorMsg('Please enter a valid bid amount.');
      return;
    }

    if (numericBid < minNextBid) {
      setErrorMsg(`Bid must be at least ${formatCurrency(minNextBid)}.`);
      return;
    }

    if (numericBid > remainingPurse) {
      setErrorMsg(`Team only has ${formatCurrency(remainingPurse)} remaining.`);
      return;
    }

    if (isLeader && !auction.settings?.allow_self_outbid) {
      setErrorMsg('This team is already the highest bidder!');
      return;
    }

    setSubmitting(true);
    try {
      const res = await auctionService.placeBid(auction.id, parseInt(selectedTeamId, 10), numericBid);
      if (res.success) {
        showToast(`Bid placed: ${formatCurrency(numericBid)}`, 'success');
        setBidAmount('');
        if (onBidPlaced) onBidPlaced();
      }
    } catch (err) {
      setErrorMsg(err.message || 'Failed to place bid');
      showToast(err.message || 'Bid rejected', 'error');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="card" style={{ border: '1px solid rgba(225, 6, 0, 0.25)' }}>
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '16px',
        borderBottom: '1px solid var(--border-subtle)',
        paddingBottom: '12px'
      }}>
        <h3 style={{ fontSize: '1.15rem', color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <Gavel size={20} color="var(--crimson-primary)" />
          <span>PLACE BID</span>
        </h3>
        <span style={{ fontSize: '0.8rem', color: 'var(--text-gold)', fontWeight: 600 }}>
          Min: {formatCurrency(minNextBid)}
        </span>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Team Selector */}
        <div className="form-group">
          <label className="form-label">Bidding Team</label>
          <select
            className="form-select"
            value={selectedTeamId}
            onChange={(e) => setSelectedTeamId(e.target.value)}
            disabled={isTeamUser || submitting}
          >
            {teams.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name} ({t.code}) — Purse: {formatCurrency(t.remaining_purse)}
              </option>
            ))}
          </select>
        </div>

        {/* Selected Team Financial Indicator */}
        {currentTeam && (
          <div style={{
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            backgroundColor: '#090D16',
            padding: '10px 14px',
            borderRadius: '8px',
            marginBottom: '16px',
            fontSize: '0.85rem'
          }}>
            <span style={{ color: 'var(--text-muted)' }}>Available Purse:</span>
            <strong style={{ color: remainingPurse > minNextBid ? '#10B981' : '#EF4444' }}>
              {formatCurrency(remainingPurse)}
            </strong>
          </div>
        )}

        {/* Quick Increment Buttons */}
        <div style={{ marginBottom: '16px' }}>
          <label className="form-label" style={{ marginBottom: '8px', display: 'block' }}>Quick Bid Options</label>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ fontSize: '0.75rem', padding: '8px 4px' }}
              onClick={() => handleQuickBid(minNextBid)}
            >
              Exact Min
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ fontSize: '0.75rem', padding: '8px 4px' }}
              onClick={() => handleQuickBid(minNextBid + 2000000)}
            >
              +₹20 L
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ fontSize: '0.75rem', padding: '8px 4px' }}
              onClick={() => handleQuickBid(minNextBid + 5000000)}
            >
              +₹50 L
            </button>
            <button
              type="button"
              className="btn btn-secondary"
              style={{ fontSize: '0.75rem', padding: '8px 4px' }}
              onClick={() => handleQuickBid(minNextBid + 10000000)}
            >
              +₹1 Cr
            </button>
          </div>
        </div>

        {/* Custom Bid Input */}
        <div className="form-group">
          <label className="form-label">Custom Bid Amount (in ₹)</label>
          <div style={{ position: 'relative' }}>
            <input
              type="number"
              className="form-input"
              style={{ width: '100%', paddingRight: '90px' }}
              placeholder={minNextBid.toString()}
              value={bidAmount}
              onChange={(e) => {
                setBidAmount(e.target.value);
                setErrorMsg('');
              }}
              min={minNextBid}
              step={increment}
              disabled={submitting}
            />
            {bidAmount && (
              <span style={{
                position: 'absolute',
                right: '12px',
                top: '50%',
                transform: 'translateY(-50%)',
                fontSize: '0.8rem',
                color: 'var(--text-gold)',
                fontWeight: 700
              }}>
                {formatCurrency(Number(bidAmount))}
              </span>
            )}
          </div>
        </div>

        {/* Error Notification */}
        {errorMsg && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            color: '#EF4444',
            fontSize: '0.85rem',
            marginBottom: '14px',
            backgroundColor: 'rgba(239, 68, 68, 0.1)',
            padding: '8px 12px',
            borderRadius: '6px'
          }}>
            <AlertCircle size={16} />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Submit Bid Button */}
        <button
          type="submit"
          className="btn btn-primary"
          style={{ width: '100%', padding: '14px', fontSize: '1rem' }}
          disabled={submitting || (isLeader && !auction.settings?.allow_self_outbid) || !isAffordable}
        >
          {submitting ? 'Submitting Bid...' :
           isLeader ? 'Your Team Leads Current Bid' :
           `Submit Bid (${bidAmount ? formatCurrency(Number(bidAmount)) : formatCurrency(minNextBid)})`}
        </button>
      </form>
    </div>
  );
}
