import React from 'react';
import { History, Shield } from 'lucide-react';
import { formatCurrency, formatDateTime, formatTimeAgo } from '../../utils/formatters';

export default function BidHistoryTable({ bids = [] }) {
  if (bids.length === 0) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '32px 16px', color: 'var(--text-muted)' }}>
        <History size={28} style={{ margin: '0 auto 8px', opacity: 0.5 }} />
        <p style={{ fontSize: '0.9rem' }}>No bids placed yet for this player.</p>
      </div>
    );
  }

  return (
    <div className="card" style={{ padding: '0', overflow: 'hidden' }}>
      <div style={{
        padding: '16px 20px',
        borderBottom: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#0D1322'
      }}>
        <h4 style={{ fontSize: '1rem', color: '#FFFFFF', display: 'flex', alignItems: 'center', gap: '8px' }}>
          <History size={18} color="var(--gold-primary)" />
          <span>LIVE BID LOG ({bids.length})</span>
        </h4>
        <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Newest First</span>
      </div>

      <div style={{ maxHeight: '340px', overflowY: 'auto' }}>
        <table className="custom-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Team</th>
              <th>Bid Amount</th>
              <th>Time</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {bids.map((bid, index) => {
              const isWinning = bid.bid_status === 'WINNING' || index === 0;
              return (
                <tr
                  key={bid.id || index}
                  style={{
                    backgroundColor: isWinning ? 'rgba(245, 158, 11, 0.05)' : 'transparent'
                  }}
                >
                  <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                    #{bids.length - index}
                  </td>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <span style={{
                        padding: '2px 6px',
                        backgroundColor: '#1E293B',
                        borderRadius: '4px',
                        fontSize: '0.75rem',
                        fontWeight: 700,
                        color: 'var(--text-gold)'
                      }}>
                        {bid.team?.code || 'TEAM'}
                      </span>
                      <strong style={{ fontSize: '0.85rem', color: '#FFFFFF' }}>
                        {bid.team?.name || 'Franchise'}
                      </strong>
                    </div>
                  </td>
                  <td>
                    <strong style={{
                      color: isWinning ? 'var(--gold-primary)' : '#FFFFFF',
                      fontSize: '0.95rem',
                      fontFamily: 'var(--font-heading)'
                    }}>
                      {formatCurrency(bid.bid_amount)}
                    </strong>
                  </td>
                  <td style={{ color: 'var(--text-muted)', fontSize: '0.8rem' }}>
                    {formatTimeAgo(bid.created_at)}
                  </td>
                  <td>
                    <span style={{
                      padding: '2px 8px',
                      borderRadius: '4px',
                      fontSize: '0.7rem',
                      fontWeight: 700,
                      backgroundColor:
                        bid.bid_status === 'WINNING' ? 'rgba(16, 185, 129, 0.2)' :
                        bid.bid_status === 'OUTBID' ? 'rgba(148, 163, 184, 0.1)' :
                        'rgba(59, 130, 246, 0.2)',
                      color:
                        bid.bid_status === 'WINNING' ? '#10B981' :
                        bid.bid_status === 'OUTBID' ? '#94A3B8' :
                        '#60A5FA'
                    }}>
                      {bid.bid_status || (index === 0 ? 'CURRENT LEAD' : 'OUTBID')}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
