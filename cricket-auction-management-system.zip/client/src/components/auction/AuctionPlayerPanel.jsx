import React from 'react';
import { Trophy, Flame, User, Globe, Activity } from 'lucide-react';
import { formatCurrency, getRoleBadgeClass, getStatusBadgeClass } from '../../utils/formatters';

export default function AuctionPlayerPanel({ auction }) {
  if (!auction || !auction.player) {
    return (
      <div className="card" style={{
        textAlign: 'center',
        padding: '60px 24px',
        backgroundColor: '#0A0F1D',
        border: '1px dashed var(--border-subtle)'
      }}>
        <div style={{
          width: '64px',
          height: '64px',
          borderRadius: '50%',
          backgroundColor: 'rgba(255, 255, 255, 0.05)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          margin: '0 auto 16px',
          color: 'var(--text-muted)'
        }}>
          <Trophy size={32} />
        </div>
        <h3 style={{ fontSize: '1.4rem', color: '#FFFFFF', marginBottom: '8px' }}>
          AUCTION BLOCK IS EMPTY
        </h3>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.95rem', maxWidth: '420px', margin: '0 auto' }}>
          No player is currently on the auction block. Administrators can select an available player to start bidding.
        </p>
      </div>
    );
  }

  const { player, current_bid, leading_team, status } = auction;

  return (
    <div className="card" style={{
      background: 'linear-gradient(180deg, #131B2E 0%, #0B101D 100%)',
      border: '1px solid rgba(225, 6, 0, 0.3)',
      boxShadow: '0 8px 30px rgba(0, 0, 0, 0.6)',
      position: 'relative',
      overflow: 'hidden',
      padding: '28px'
    }}>
      {/* Top Banner Status */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: '24px',
        borderBottom: '1px solid var(--border-subtle)',
        paddingBottom: '16px'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
          <span className={`badge ${getStatusBadgeClass(status)}`} style={{ fontSize: '0.85rem', padding: '6px 14px' }}>
            {status === 'OPEN' ? '🔥 BIDDING OPEN' : status}
          </span>
          <span className={`badge ${getRoleBadgeClass(player.role)}`}>
            {player.role}
          </span>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--text-muted)', fontSize: '0.85rem' }}>
          <Globe size={16} />
          <span>{player.nationality}</span>
          {player.age && <span>• {player.age} yrs</span>}
        </div>
      </div>

      {/* Main Grid: Player Info + Big Bid Spotlight */}
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1.2fr 1fr',
        gap: '24px',
        alignItems: 'center'
      }}>
        {/* Left: Player Details */}
        <div style={{ display: 'flex', gap: '20px', alignItems: 'center' }}>
          {/* Player Photo or Silhouette Avatar */}
          <div style={{
            width: '120px',
            height: '140px',
            borderRadius: '12px',
            backgroundColor: '#1E293B',
            border: '2px solid rgba(255, 255, 255, 0.1)',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0
          }}>
            {player.image_url ? (
              <img
                src={player.image_url}
                alt={player.name}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.parentElement.innerHTML = '<div style="color: #64748B;"><svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>';
                }}
              />
            ) : (
              <User size={54} color="#64748B" />
            )}
          </div>

          <div>
            <h2 style={{
              fontSize: '2rem',
              fontWeight: 800,
              color: '#FFFFFF',
              letterSpacing: '0.5px',
              lineHeight: 1.1
            }}>
              {player.name}
            </h2>

            <div style={{
              marginTop: '8px',
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              fontSize: '0.85rem',
              color: 'var(--text-muted)'
            }}>
              {player.batting_style && <div>Batting: <strong style={{ color: '#FFFFFF' }}>{player.batting_style}</strong></div>}
              {player.bowling_style && <div>Bowling: <strong style={{ color: '#FFFFFF' }}>{player.bowling_style}</strong></div>}
              <div>
                Base Price: <strong style={{ color: 'var(--text-gold)', fontSize: '0.95rem' }}>{formatCurrency(player.base_price)}</strong>
              </div>
            </div>

            {/* Quick Stats Pill */}
            {(player.matches > 0 || player.runs > 0 || player.wickets > 0) && (
              <div style={{
                display: 'flex',
                gap: '12px',
                marginTop: '12px',
                fontSize: '0.75rem',
                backgroundColor: 'rgba(255, 255, 255, 0.04)',
                padding: '6px 12px',
                borderRadius: '6px',
                width: 'fit-content'
              }}>
                <div>Matches: <strong>{player.matches}</strong></div>
                {player.runs > 0 && <div>Runs: <strong>{player.runs}</strong></div>}
                {player.wickets > 0 && <div>Wickets: <strong>{player.wickets}</strong></div>}
              </div>
            )}
          </div>
        </div>

        {/* Right: Current Highest Bid Spotlight */}
        <div style={{
          backgroundColor: '#090D16',
          border: '1px solid rgba(245, 158, 11, 0.3)',
          borderRadius: '16px',
          padding: '24px',
          textAlign: 'center',
          boxShadow: '0 0 30px rgba(0, 0, 0, 0.7)'
        }}>
          <span style={{
            fontSize: '0.8rem',
            fontWeight: 800,
            color: 'var(--text-muted)',
            textTransform: 'uppercase',
            letterSpacing: '1px'
          }}>
            CURRENT HIGHEST BID
          </span>

          <div style={{
            fontSize: '2.8rem',
            fontWeight: 900,
            fontFamily: 'var(--font-heading)',
            color: current_bid > 0 ? 'var(--gold-primary)' : 'var(--text-muted)',
            margin: '8px 0',
            textShadow: current_bid > 0 ? '0 0 25px var(--gold-glow)' : 'none'
          }}>
            {formatCurrency(current_bid)}
          </div>

          {leading_team ? (
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: '10px',
              backgroundColor: 'rgba(245, 158, 11, 0.1)',
              border: '1px solid rgba(245, 158, 11, 0.3)',
              padding: '8px 16px',
              borderRadius: '9999px'
            }}>
              <span style={{
                width: '10px',
                height: '10px',
                borderRadius: '50%',
                backgroundColor: '#10B981',
                boxShadow: '0 0 8px #10B981'
              }} />
              <span style={{ fontSize: '0.9rem', color: '#FFFFFF', fontWeight: 700 }}>
                Leader: {leading_team.name} ({leading_team.code})
              </span>
            </div>
          ) : (
            <div style={{ fontSize: '0.85rem', color: 'var(--text-dark)' }}>
              Awaiting opening bid (Min: {formatCurrency(player.base_price)})
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
