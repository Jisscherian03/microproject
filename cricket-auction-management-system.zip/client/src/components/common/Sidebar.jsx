import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Gavel,
  LayoutDashboard,
  Users,
  Shield,
  History,
  ShoppingBag,
  BarChart3,
  Settings,
  LogOut,
  Trophy
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Sidebar() {
  const { user, isAdmin, isTeamUser, logout } = useAuth();

  const navLinks = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/auction', label: 'Auction Arena', icon: Gavel, highlight: true },
    { path: '/players', label: 'Players Pool', icon: Users },
    { path: '/teams', label: 'Teams & Purses', icon: Shield },
    ...(isTeamUser && user?.team_id ? [
      { path: `/teams/${user.team_id}`, label: 'My Squad', icon: Trophy }
    ] : []),
    { path: '/bids', label: 'Bid History', icon: History },
    { path: '/purchases', label: 'Purchases Ledger', icon: ShoppingBag },
    { path: '/reports', label: 'Analytics & Reports', icon: BarChart3 },
    ...(isAdmin ? [
      { path: '/settings', label: 'Auction Settings', icon: Settings }
    ] : [])
  ];

  return (
    <aside style={{
      width: '260px',
      backgroundColor: 'var(--bg-sidebar)',
      borderRight: '1px solid var(--border-subtle)',
      display: 'flex',
      flexDirection: 'column',
      height: '100vh',
      flexShrink: 0
    }}>
      {/* Brand Header */}
      <div style={{
        padding: '24px 20px',
        borderBottom: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        gap: '12px'
      }}>
        <div style={{
          width: '42px',
          height: '42px',
          borderRadius: '10px',
          background: 'linear-gradient(135deg, var(--crimson-primary), #990000)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 4px 15px var(--crimson-glow)'
        }}>
          <Gavel size={22} color="#FFFFFF" />
        </div>
        <div>
          <h2 style={{
            fontSize: '1.15rem',
            lineHeight: 1.1,
            color: '#FFFFFF',
            fontWeight: 800
          }}>
            CRICKET AUCTION
          </h2>
          <span style={{
            fontSize: '0.7rem',
            color: 'var(--gold-primary)',
            fontWeight: 700,
            letterSpacing: '1px'
          }}>
            IPL PREMIER LEAGUE
          </span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav style={{
        flex: 1,
        padding: '16px 12px',
        overflowY: 'auto',
        display: 'flex',
        flexDirection: 'column',
        gap: '6px'
      }}>
        {navLinks.map((link) => {
          const Icon = link.icon;
          return (
            <NavLink
              key={link.path}
              to={link.path}
              style={({ isActive }) => ({
                display: 'flex',
                alignItems: 'center',
                gap: '12px',
                padding: '12px 16px',
                borderRadius: '8px',
                textDecoration: 'none',
                fontSize: '0.9rem',
                fontWeight: isActive ? 600 : 500,
                color: isActive ? '#FFFFFF' : 'var(--text-muted)',
                backgroundColor: isActive
                  ? (link.highlight ? 'rgba(225, 6, 0, 0.2)' : 'rgba(255, 255, 255, 0.06)')
                  : 'transparent',
                borderLeft: isActive ? '3px solid var(--crimson-primary)' : '3px solid transparent',
                transition: 'all 0.2s ease'
              })}
            >
              <Icon size={18} />
              <span>{link.label}</span>
              {link.highlight && (
                <span style={{
                  marginLeft: 'auto',
                  fontSize: '0.65rem',
                  fontWeight: 800,
                  backgroundColor: 'var(--crimson-primary)',
                  color: '#FFFFFF',
                  padding: '2px 6px',
                  borderRadius: '4px',
                  letterSpacing: '0.5px'
                }}>
                  LIVE
                </span>
              )}
            </NavLink>
          );
        })}
      </nav>

      {/* User Footer */}
      <div style={{
        padding: '16px 20px',
        borderTop: '1px solid var(--border-subtle)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        <div style={{ overflow: 'hidden' }}>
          <div style={{
            fontSize: '0.85rem',
            fontWeight: 700,
            color: '#FFFFFF',
            whiteSpace: 'nowrap',
            textOverflow: 'ellipsis',
            overflow: 'hidden'
          }}>
            {user?.username}
          </div>
          <div style={{
            fontSize: '0.7rem',
            color: isAdmin ? 'var(--crimson-primary)' : 'var(--gold-primary)',
            fontWeight: 700,
            textTransform: 'uppercase'
          }}>
            {isAdmin ? 'System Admin' : user?.team_name || 'Team Owner'}
          </div>
        </div>

        <button
          onClick={logout}
          title="Logout"
          style={{
            background: 'transparent',
            border: 'none',
            color: 'var(--text-muted)',
            cursor: 'pointer',
            padding: '8px',
            borderRadius: '6px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transition: 'color 0.2s'
          }}
          onMouseEnter={(e) => e.currentTarget.style.color = '#EF4444'}
          onMouseLeave={(e) => e.currentTarget.style.color = 'var(--text-muted)'}
        >
          <LogOut size={18} />
        </button>
      </div>
    </aside>
  );
}
