import React from 'react';

export default function SummaryCard({
  title,
  value,
  subtitle,
  icon: Icon,
  accentColor = 'var(--crimson-primary)',
  onClick
}) {
  return (
    <div
      onClick={onClick}
      className="card"
      style={{
        display: 'flex',
        flexDirection: 'column',
        gap: '12px',
        cursor: onClick ? 'pointer' : 'default',
        position: 'relative',
        overflow: 'hidden'
      }}
    >
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: '4px',
        height: '100%',
        backgroundColor: accentColor
      }} />

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{
          fontSize: '0.8rem',
          fontWeight: 700,
          color: 'var(--text-muted)',
          textTransform: 'uppercase',
          letterSpacing: '0.8px'
        }}>
          {title}
        </span>
        {Icon && (
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '8px',
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: accentColor
          }}>
            <Icon size={20} />
          </div>
        )}
      </div>

      <div style={{
        fontSize: '1.8rem',
        fontWeight: 800,
        fontFamily: 'var(--font-heading)',
        color: '#FFFFFF',
        letterSpacing: '0.5px'
      }}>
        {value}
      </div>

      {subtitle && (
        <div style={{
          fontSize: '0.78rem',
          color: 'var(--text-muted)'
        }}>
          {subtitle}
        </div>
      )}
    </div>
  );
}
