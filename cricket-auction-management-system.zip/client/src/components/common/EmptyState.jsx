import React from 'react';
import { ShieldAlert } from 'lucide-react';

export default function EmptyState({
  icon: Icon = ShieldAlert,
  title = 'No records found',
  description = 'There are no items to display at this time.',
  actionText,
  onAction
}) {
  return (
    <div className="card" style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '48px 24px',
      textAlign: 'center',
      gap: '14px'
    }}>
      <div style={{
        width: '56px',
        height: '56px',
        borderRadius: '50%',
        backgroundColor: 'rgba(255, 255, 255, 0.05)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        color: 'var(--text-muted)'
      }}>
        <Icon size={28} />
      </div>

      <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF' }}>{title}</h3>
      <p style={{
        fontSize: '0.9rem',
        color: 'var(--text-muted)',
        maxWidth: '400px',
        lineHeight: 1.5
      }}>
        {description}
      </p>

      {actionText && onAction && (
        <button
          type="button"
          className="btn btn-primary"
          onClick={onAction}
          style={{ marginTop: '8px' }}
        >
          {actionText}
        </button>
      )}
    </div>
  );
}
