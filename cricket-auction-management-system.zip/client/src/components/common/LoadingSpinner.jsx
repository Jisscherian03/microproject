import React from 'react';

export default function LoadingSpinner({ message = 'Loading auction data...' }) {
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '48px 24px',
      gap: '16px'
    }}>
      <div style={{
        width: '44px',
        height: '44px',
        border: '3px solid rgba(225, 6, 0, 0.2)',
        borderTopColor: 'var(--crimson-primary)',
        borderRadius: '50%',
        animation: 'spin 0.8s linear infinite'
      }} />
      <span style={{
        fontSize: '0.9rem',
        color: 'var(--text-muted)',
        fontWeight: 500
      }}>
        {message}
      </span>
      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
