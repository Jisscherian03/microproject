import React from 'react';
import { Wifi, WifiOff, Wallet, Shield, User, Bell } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useAuction } from '../../context/AuctionContext';
import { formatCurrency } from '../../utils/formatters';

export default function Topbar({ pageTitle = 'Dashboard' }) {
  const { user, isAdmin, isTeamUser } = useAuth();
  const { isConnected, currentAuction } = useAuction();

  return (
    <header style={{
      height: '70px',
      backgroundColor: 'var(--bg-card)',
      borderBottom: '1px solid var(--border-subtle)',
      padding: '0 28px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      position: 'sticky',
      top: 0,
      zIndex: 100
    }}>
      {/* Page Title */}
      <div>
        <h1 style={{
          fontSize: '1.4rem',
          fontWeight: 700,
          color: '#FFFFFF'
        }}>
          {pageTitle}
        </h1>
      </div>

      {/* Right Actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
        {/* Real-time Socket Status Indicator */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '6px',
          padding: '6px 12px',
          borderRadius: '20px',
          backgroundColor: isConnected ? 'rgba(16, 185, 129, 0.1)' : 'rgba(245, 158, 11, 0.1)',
          border: `1px solid ${isConnected ? 'rgba(16, 185, 129, 0.3)' : 'rgba(245, 158, 11, 0.3)'}`,
          fontSize: '0.75rem',
          fontWeight: 600,
          color: isConnected ? '#10B981' : '#F59E0B'
        }}>
          {isConnected ? <Wifi size={14} /> : <WifiOff size={14} />}
          <span>{isConnected ? 'LIVE FEED ACTIVE' : 'POLLING FALLBACK'}</span>
        </div>

        {/* Team User Remaining Purse Pill */}
        {isTeamUser && (user?.remaining_purse !== null && user?.remaining_purse !== undefined) && (
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '8px',
            padding: '6px 14px',
            borderRadius: '8px',
            backgroundColor: 'rgba(245, 158, 11, 0.15)',
            border: '1px solid rgba(245, 158, 11, 0.3)',
            color: 'var(--text-gold)',
            fontSize: '0.85rem',
            fontWeight: 700
          }}>
            <Wallet size={16} />
            <span>Purse: {formatCurrency(user.remaining_purse)}</span>
          </div>
        )}

        {/* User Role Badge */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '10px',
          paddingLeft: '12px',
          borderLeft: '1px solid var(--border-subtle)'
        }}>
          <div style={{
            width: '36px',
            height: '36px',
            borderRadius: '50%',
            backgroundColor: isAdmin ? 'rgba(225, 6, 0, 0.2)' : 'rgba(37, 99, 235, 0.2)',
            border: `1px solid ${isAdmin ? 'var(--crimson-primary)' : 'var(--blue-accent)'}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: '#FFFFFF'
          }}>
            {isAdmin ? <Shield size={18} /> : <User size={18} />}
          </div>
          <div>
            <div style={{ fontSize: '0.85rem', fontWeight: 600, color: '#FFFFFF' }}>
              {user?.username}
            </div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)' }}>
              {isAdmin ? 'Auctioneer Admin' : user?.team_name || user?.team?.name || 'Franchise Owner'}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
