import React from 'react';
import { Shield, Wallet, Users, ArrowRight, Edit } from 'lucide-react';
import { formatCurrency } from '../../utils/formatters';

export default function TeamCard({ team, isAdmin, onEdit, onViewSquad }) {
  const initial = Number(team.initial_purse || 1000000000);
  const remaining = Number(team.remaining_purse || 0);
  const spent = Number(team.total_spent || initial - remaining);
  const spentPercent = Math.min(100, Math.max(0, (spent / initial) * 100));

  return (
    <div className="card" style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      padding: '22px',
      position: 'relative'
    }}>
      {/* Top Header */}
      <div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '16px'
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{
              width: '44px',
              height: '44px',
              borderRadius: '10px',
              backgroundColor: '#1E293B',
              border: '1px solid var(--border-subtle)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontWeight: 800,
              fontSize: '1rem',
              color: 'var(--text-gold)',
              fontFamily: 'var(--font-heading)'
            }}>
              {team.code}
            </div>

            <div>
              <h3 style={{ fontSize: '1.2rem', color: '#FFFFFF', fontWeight: 700 }}>
                {team.name}
              </h3>
              <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                Squad: <strong style={{ color: '#FFFFFF' }}>{team.squad_count || 0}</strong> players
              </span>
            </div>
          </div>

          {isAdmin && onEdit && (
            <button
              type="button"
              className="btn btn-secondary"
              style={{ padding: '6px 10px' }}
              title="Edit Team"
              onClick={() => onEdit(team.id)}
            >
              <Edit size={15} />
            </button>
          )}
        </div>

        {/* Financial Metrics */}
        <div style={{
          backgroundColor: '#090D16',
          borderRadius: '8px',
          padding: '14px',
          marginBottom: '16px',
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '12px'
        }}>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Remaining Purse
            </div>
            <strong style={{
              fontSize: '1.1rem',
              color: '#10B981',
              fontFamily: 'var(--font-heading)'
            }}>
              {formatCurrency(remaining)}
            </strong>
          </div>

          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Total Spent
            </div>
            <strong style={{
              fontSize: '1.1rem',
              color: 'var(--crimson-primary)',
              fontFamily: 'var(--font-heading)'
            }}>
              {formatCurrency(spent)}
            </strong>
          </div>
        </div>

        {/* Budget Progress Bar */}
        <div style={{ marginBottom: '16px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: 'var(--text-muted)', marginBottom: '6px' }}>
            <span>Budget Utilized</span>
            <span>{spentPercent.toFixed(1)}%</span>
          </div>
          <div style={{
            height: '6px',
            backgroundColor: '#1E293B',
            borderRadius: '9999px',
            overflow: 'hidden'
          }}>
            <div style={{
              height: '100%',
              width: `${spentPercent}%`,
              background: 'linear-gradient(90deg, #10B981, var(--crimson-primary))',
              borderRadius: '9999px',
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>
      </div>

      {/* Action Footer */}
      <button
        type="button"
        className="btn btn-outline"
        style={{ width: '100%', fontSize: '0.85rem' }}
        onClick={() => onViewSquad(team.id)}
      >
        <span>View Full Squad & Details</span>
        <ArrowRight size={16} />
      </button>
    </div>
  );
}
