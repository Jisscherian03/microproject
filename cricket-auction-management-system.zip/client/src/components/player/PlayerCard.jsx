import React from 'react';
import { User, Globe, Trophy, Edit, Trash2 } from 'lucide-react';
import { formatCurrency, getRoleBadgeClass, getStatusBadgeClass } from '../../utils/formatters';

export default function PlayerCard({ player, isAdmin, onEdit, onDelete, onView }) {
  return (
    <div className="card" style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between',
      position: 'relative',
      padding: '20px',
      height: '100%'
    }}>
      {/* Status & Role Pill */}
      <div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          marginBottom: '14px'
        }}>
          <span className={`badge ${getStatusBadgeClass(player.status)}`}>
            {player.status}
          </span>
          <span className={`badge ${getRoleBadgeClass(player.role)}`}>
            {player.role}
          </span>
        </div>

        {/* Player Photo + Info */}
        <div style={{ display: 'flex', gap: '14px', alignItems: 'center', marginBottom: '14px' }}>
          <div style={{
            width: '64px',
            height: '74px',
            borderRadius: '8px',
            backgroundColor: '#1E293B',
            overflow: 'hidden',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            flexShrink: 0,
            border: '1px solid var(--border-subtle)'
          }}>
            {player.image_url ? (
              <img
                src={player.image_url}
                alt={player.name}
                style={{ width: '100%', height: '100%', objectFit: 'cover' }}
                onError={(e) => {
                  e.target.style.display = 'none';
                  e.target.parentElement.innerHTML = '<div style="color: #64748B;"><svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>';
                }}
              />
            ) : (
              <User size={32} color="#64748B" />
            )}
          </div>

          <div>
            <h3 style={{
              fontSize: '1.15rem',
              color: '#FFFFFF',
              fontWeight: 700,
              lineHeight: 1.2
            }}>
              {player.name}
            </h3>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '0.8rem',
              color: 'var(--text-muted)',
              marginTop: '4px'
            }}>
              <Globe size={14} />
              <span>{player.nationality}</span>
              {player.age && <span>• {player.age}y</span>}
            </div>
          </div>
        </div>

        {/* Batting & Bowling Styles */}
        <div style={{
          fontSize: '0.78rem',
          color: 'var(--text-muted)',
          display: 'flex',
          flexDirection: 'column',
          gap: '3px',
          marginBottom: '14px',
          backgroundColor: '#090D16',
          padding: '8px 12px',
          borderRadius: '6px'
        }}>
          {player.batting_style && <div>Bat: <span style={{ color: '#E2E8F0' }}>{player.batting_style}</span></div>}
          {player.bowling_style && <div>Bowl: <span style={{ color: '#E2E8F0' }}>{player.bowling_style}</span></div>}
        </div>
      </div>

      {/* Pricing & Sold Indicator */}
      <div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          paddingTop: '12px',
          borderTop: '1px solid var(--border-subtle)',
          marginBottom: '12px'
        }}>
          <div>
            <div style={{ fontSize: '0.7rem', color: 'var(--text-muted)', textTransform: 'uppercase' }}>
              Base Price
            </div>
            <strong style={{ fontSize: '0.95rem', color: 'var(--text-gold)', fontFamily: 'var(--font-heading)' }}>
              {formatCurrency(player.base_price)}
            </strong>
          </div>

          {player.status === 'SOLD' && player.purchase && (
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: '0.7rem', color: '#10B981', textTransform: 'uppercase', fontWeight: 700 }}>
                Sold For ({player.purchase.team.code})
              </div>
              <strong style={{ fontSize: '1.05rem', color: '#10B981', fontFamily: 'var(--font-heading)' }}>
                {formatCurrency(player.purchase.final_price)}
              </strong>
            </div>
          )}
        </div>

        {/* Card Actions */}
        <div style={{ display: 'flex', gap: '8px', justifyContent: 'flex-end' }}>
          {onView && (
            <button
              type="button"
              className="btn btn-outline"
              style={{ fontSize: '0.8rem', padding: '6px 12px', flex: 1 }}
              onClick={() => onView(player.id)}
            >
              View
            </button>
          )}

          {isAdmin && onEdit && (
            <button
              type="button"
              className="btn btn-secondary"
              style={{ padding: '6px 10px' }}
              title="Edit Player"
              onClick={() => onEdit(player.id)}
            >
              <Edit size={15} />
            </button>
          )}

          {isAdmin && onDelete && player.status !== 'SOLD' && (
            <button
              type="button"
              className="btn btn-danger"
              style={{ padding: '6px 10px' }}
              title="Delete Player"
              onClick={() => onDelete(player.id)}
            >
              <Trash2 size={15} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
