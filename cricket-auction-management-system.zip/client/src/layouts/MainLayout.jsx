import React from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from '../components/common/Sidebar';
import Topbar from '../components/common/Topbar';
import ErrorBoundary from '../components/common/ErrorBoundary';

export default function MainLayout() {
  const location = useLocation();

  // Determine page title based on path
  const getPageTitle = (pathname) => {
    if (pathname.startsWith('/dashboard')) return 'Live Auction Dashboard';
    if (pathname.startsWith('/auction')) return 'Auction Control Arena';
    if (pathname.startsWith('/players/new')) return 'Register New Player';
    if (pathname.includes('/players') && pathname.includes('/edit')) return 'Edit Player Details';
    if (pathname.startsWith('/players')) return 'Players Registration Pool';
    if (pathname.startsWith('/teams/new')) return 'Register New Franchise';
    if (pathname.includes('/teams') && pathname.includes('/edit')) return 'Edit Franchise Details';
    if (pathname.startsWith('/teams/')) return 'Team Squad & Financials';
    if (pathname.startsWith('/teams')) return 'Franchise Management';
    if (pathname.startsWith('/bids')) return 'Auction Bid History';
    if (pathname.startsWith('/purchases')) return 'Official Purchase Ledger';
    if (pathname.startsWith('/reports')) return 'Analytics & Reports';
    if (pathname.startsWith('/settings')) return 'Auction Configuration';
    return 'Cricket Auction Management';
  };

  return (
    <div className="app-container">
      <Sidebar />
      <div className="main-content">
        <Topbar pageTitle={getPageTitle(location.pathname)} />
        <main className="page-body">
          <ErrorBoundary>
            <Outlet />
          </ErrorBoundary>
        </main>
      </div>
    </div>
  );
}
