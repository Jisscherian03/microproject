-- =====================================================================
-- Cricket Auction Management System - Database Schema
-- Database: cricket_auction_db (MySQL 8.0+ with InnoDB Engine)
-- =====================================================================

CREATE DATABASE IF NOT EXISTS cricket_auction_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE cricket_auction_db;

-- Safely clean up any incompatible legacy tables
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS purchases;
DROP TABLE IF EXISTS bids;
DROP TABLE IF EXISTS auctions;
DROP TABLE IF EXISTS players;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS teams;
DROP TABLE IF EXISTS auction_settings;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. TEAMS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS teams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    team_name VARCHAR(100) NOT NULL,
    team_code VARCHAR(10) NOT NULL UNIQUE,
    logo_url VARCHAR(500) NULL,
    initial_purse DECIMAL(14, 2) NOT NULL DEFAULT 1000000000.00,
    remaining_purse DECIMAL(14, 2) NOT NULL DEFAULT 1000000000.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_teams_initial_purse CHECK (initial_purse >= 0),
    CONSTRAINT chk_teams_remaining_purse CHECK (remaining_purse >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2. USERS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('ADMIN', 'TEAM_USER') NOT NULL DEFAULT 'TEAM_USER',
    team_id INT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_users_team FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE SET NULL,
    INDEX idx_users_role (role),
    INDEX idx_users_team (team_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3. PLAYERS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS players (
    id INT AUTO_INCREMENT PRIMARY KEY,
    player_name VARCHAR(100) NOT NULL,
    image_url VARCHAR(500) NULL,
    nationality VARCHAR(50) NOT NULL,
    age INT NULL,
    role ENUM('Batter', 'Bowler', 'All-rounder', 'Wicketkeeper') NOT NULL,
    batting_style VARCHAR(50) NULL,
    bowling_style VARCHAR(50) NULL,
    base_price DECIMAL(14, 2) NOT NULL,
    status ENUM('AVAILABLE', 'IN_AUCTION', 'SOLD', 'UNSOLD') NOT NULL DEFAULT 'AVAILABLE',
    matches_played INT NOT NULL DEFAULT 0,
    runs_scored INT NOT NULL DEFAULT 0,
    wickets_taken INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_players_age CHECK (age IS NULL OR age > 0),
    CONSTRAINT chk_players_base_price CHECK (base_price >= 0),
    INDEX idx_players_status (status),
    INDEX idx_players_role (role),
    INDEX idx_players_nationality (nationality)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 4. AUCTIONS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auctions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    player_id INT NOT NULL,
    current_bid DECIMAL(14, 2) NOT NULL DEFAULT 0.00,
    highest_bid_team_id INT NULL,
    status ENUM('DRAFT', 'READY', 'OPEN', 'PAUSED', 'CLOSED', 'SOLD', 'UNSOLD') NOT NULL DEFAULT 'DRAFT',
    started_at TIMESTAMP NULL,
    closed_at TIMESTAMP NULL,
    created_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_auctions_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE RESTRICT,
    CONSTRAINT fk_auctions_highest_team FOREIGN KEY (highest_bid_team_id) REFERENCES teams(id) ON DELETE SET NULL,
    CONSTRAINT fk_auctions_creator FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE RESTRICT,
    CONSTRAINT chk_auctions_current_bid CHECK (current_bid >= 0),
    INDEX idx_auctions_status (status),
    INDEX idx_auctions_player (player_id),
    INDEX idx_auctions_highest_team (highest_bid_team_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 5. BIDS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS bids (
    id INT AUTO_INCREMENT PRIMARY KEY,
    auction_id INT NOT NULL,
    team_id INT NOT NULL,
    bid_amount DECIMAL(14, 2) NOT NULL,
    bid_status ENUM('VALID', 'OUTBID', 'WINNING', 'REJECTED') NOT NULL DEFAULT 'VALID',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_bids_auction FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE CASCADE,
    CONSTRAINT fk_bids_team FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE RESTRICT,
    CONSTRAINT chk_bids_amount CHECK (bid_amount > 0),
    INDEX idx_bids_auction (auction_id),
    INDEX idx_bids_team (team_id),
    INDEX idx_bids_created (created_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 6. PURCHASES TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS purchases (
    id INT AUTO_INCREMENT PRIMARY KEY,
    auction_id INT NOT NULL,
    player_id INT NOT NULL UNIQUE,
    team_id INT NOT NULL,
    final_price DECIMAL(14, 2) NOT NULL,
    purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_purchases_auction FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchases_player FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE RESTRICT,
    CONSTRAINT fk_purchases_team FOREIGN KEY (team_id) REFERENCES teams(id) ON DELETE RESTRICT,
    CONSTRAINT chk_purchases_final_price CHECK (final_price > 0),
    INDEX idx_purchases_team (team_id),
    INDEX idx_purchases_player (player_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 7. AUCTION SETTINGS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS auction_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    minimum_bid_increment DECIMAL(14, 2) NOT NULL DEFAULT 2000000.00,
    maximum_squad_size INT NOT NULL DEFAULT 25,
    min_batters INT NOT NULL DEFAULT 4,
    min_bowlers INT NOT NULL DEFAULT 4,
    min_allrounders INT NOT NULL DEFAULT 2,
    min_wicketkeepers INT NOT NULL DEFAULT 1,
    allow_self_outbid BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT chk_settings_increment CHECK (minimum_bid_increment > 0),
    CONSTRAINT chk_settings_squad_size CHECK (maximum_squad_size >= 11)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 8. AUDIT LOGS TABLE
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50) NOT NULL,
    entity_id INT NULL,
    details JSON NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_audit_entity (entity_type, entity_id),
    INDEX idx_audit_action (action),
    INDEX idx_audit_created (created_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
