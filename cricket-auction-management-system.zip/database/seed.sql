-- =====================================================================
-- Cricket Auction Management System - Development Seed Data
-- =====================================================================

USE cricket_auction_db;

-- Clear previous data in correct foreign key order
SET FOREIGN_KEY_CHECKS = 0;
TRUNCATE TABLE audit_logs;
TRUNCATE TABLE purchases;
TRUNCATE TABLE bids;
TRUNCATE TABLE auctions;
TRUNCATE TABLE players;
TRUNCATE TABLE users;
TRUNCATE TABLE teams;
TRUNCATE TABLE auction_settings;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 1. AUCTION SETTINGS
-- ---------------------------------------------------------------------
INSERT INTO auction_settings (id, minimum_bid_increment, maximum_squad_size, min_batters, min_bowlers, min_allrounders, min_wicketkeepers, allow_self_outbid)
VALUES (1, 2000000.00, 25, 4, 4, 2, 1, FALSE);

-- ---------------------------------------------------------------------
-- 2. TEAMS (8 Teams, Initial Purse: ₹100 Cr each)
-- ---------------------------------------------------------------------
INSERT INTO teams (id, team_name, team_code, logo_url, initial_purse, remaining_purse) VALUES
(1, 'Chennai Super Kings', 'CSK', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 880000000.00),
(2, 'Mumbai Indians', 'MI', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 850000000.00),
(3, 'Royal Challengers Bengaluru', 'RCB', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 885000000.00),
(4, 'Kolkata Knight Riders', 'KKR', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 920000000.00),
(5, 'Rajasthan Royals', 'RR', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 1000000000.00),
(6, 'Sunrisers Hyderabad', 'SRH', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 1000000000.00),
(7, 'Delhi Capitals', 'DC', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 1000000000.00),
(8, 'Gujarat Titans', 'GT', 'https://images.unsplash.com/photo-1540747913346-19e32dc3e97e?w=150&auto=format&fit=crop&q=60', 1000000000.00, 1000000000.00);

-- ---------------------------------------------------------------------
-- 3. USERS (Bcrypt hash for 'Admin@123' and 'Team@123')
-- Hash for 'Admin@123': $2b$10$w099z2.Z4N3F5/QkQkK0n.kF/xS8l9e8o0jLz3wT2tqY0QzKj6Oeq (replaced dynamically by seed.js)
-- ---------------------------------------------------------------------
INSERT INTO users (id, username, password_hash, role, team_id) VALUES
(1, 'admin', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'ADMIN', NULL),
(2, 'csk_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 1),
(3, 'mi_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 2),
(4, 'rcb_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 3),
(5, 'kkr_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 4),
(6, 'rr_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 5),
(7, 'srh_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 6),
(8, 'dc_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 7),
(9, 'gt_owner', '$2b$10$Q7wE3zR4yT5uI6oP7aS8dOHc6L4yQ3wE2rT1yU0iO9pA8sD7fG6hJ', 'TEAM_USER', 8);

-- ---------------------------------------------------------------------
-- 4. PLAYERS (48 Realistic Cricket Players across all categories)
-- ---------------------------------------------------------------------
INSERT INTO players (id, player_name, nationality, age, role, batting_style, bowling_style, base_price, status, matches_played, runs_scored, wickets_taken) VALUES
-- Sold historical players for initial demonstration
(1, 'Ruturaj Gaikwad', 'India', 27, 'Batter', 'Right-hand bat', 'Right-arm offbreak', 20000000.00, 'SOLD', 52, 1797, 0),
(2, 'Jasprit Bumrah', 'India', 30, 'Bowler', 'Right-hand bat', 'Right-arm fast', 20000000.00, 'SOLD', 120, 56, 145),
(3, 'Virat Kohli', 'India', 35, 'Batter', 'Right-hand bat', 'Right-arm medium', 20000000.00, 'SOLD', 237, 7263, 4),
(4, 'Andre Russell', 'West Indies', 35, 'All-rounder', 'Right-hand bat', 'Right-arm fast', 20000000.00, 'SOLD', 112, 2262, 96),
(5, 'Steve Smith', 'Australia', 34, 'Batter', 'Right-hand bat', 'Right-arm legbreak', 20000000.00, 'UNSOLD', 103, 2485, 9),

-- Currently in auction pool
(6, 'Rohit Sharma', 'India', 37, 'Batter', 'Right-hand bat', 'Right-arm offbreak', 20000000.00, 'IN_AUCTION', 243, 6211, 15),
(7, 'MS Dhoni', 'India', 42, 'Wicketkeeper', 'Right-hand bat', 'Right-arm medium', 20000000.00, 'AVAILABLE', 250, 5082, 0),
(8, 'Hardik Pandya', 'India', 30, 'All-rounder', 'Right-hand bat', 'Right-arm fast-medium', 20000000.00, 'AVAILABLE', 123, 2309, 53),
(9, 'Ravindra Jadeja', 'India', 35, 'All-rounder', 'Left-hand bat', 'Slow left-arm orthodox', 20000000.00, 'AVAILABLE', 226, 2692, 152),
(10, 'Rishabh Pant', 'India', 26, 'Wicketkeeper', 'Left-hand bat', 'None', 20000000.00, 'AVAILABLE', 98, 2838, 0),
(11, 'Suryakumar Yadav', 'India', 33, 'Batter', 'Right-hand bat', 'Right-arm medium', 20000000.00, 'AVAILABLE', 139, 3249, 0),
(12, 'Shubman Gill', 'India', 24, 'Batter', 'Right-hand bat', 'Right-arm offbreak', 20000000.00, 'AVAILABLE', 91, 2790, 0),
(13, 'KL Rahul', 'India', 32, 'Wicketkeeper', 'Right-hand bat', 'None', 20000000.00, 'AVAILABLE', 118, 4163, 0),
(14, 'Shreyas Iyer', 'India', 29, 'Batter', 'Right-hand bat', 'Right-arm legbreak', 20000000.00, 'AVAILABLE', 101, 2776, 0),
(15, 'Sanju Samson', 'India', 29, 'Wicketkeeper', 'Right-hand bat', 'None', 20000000.00, 'AVAILABLE', 152, 3888, 0),
(16, 'Mohammed Shami', 'India', 33, 'Bowler', 'Right-hand bat', 'Right-arm fast', 20000000.00, 'AVAILABLE', 110, 79, 127),
(17, 'Mohammed Siraj', 'India', 30, 'Bowler', 'Right-hand bat', 'Right-arm fast', 20000000.00, 'AVAILABLE', 79, 87, 78),
(18, 'Yuzvendra Chahal', 'India', 33, 'Bowler', 'Right-hand bat', 'Right-arm legbreak', 20000000.00, 'AVAILABLE', 145, 37, 187),
(19, 'Kuldeep Yadav', 'India', 29, 'Bowler', 'Left-hand bat', 'Left-arm unorthodox', 15000000.00, 'AVAILABLE', 73, 57, 71),
(20, 'Axar Patel', 'India', 30, 'All-rounder', 'Left-hand bat', 'Slow left-arm orthodox', 20000000.00, 'AVAILABLE', 136, 1418, 112),
(21, 'Travis Head', 'Australia', 30, 'Batter', 'Left-hand bat', 'Right-arm offbreak', 20000000.00, 'AVAILABLE', 25, 597, 3),
(22, 'Pat Cummins', 'Australia', 31, 'Bowler', 'Right-hand bat', 'Right-arm fast', 20000000.00, 'AVAILABLE', 42, 379, 45),
(23, 'Mitchell Starc', 'Australia', 34, 'Bowler', 'Left-hand bat', 'Left-arm fast', 20000000.00, 'AVAILABLE', 27, 96, 34),
(24, 'Glenn Maxwell', 'Australia', 35, 'All-rounder', 'Right-hand bat', 'Right-arm offbreak', 20000000.00, 'AVAILABLE', 124, 2719, 31),
(25, 'David Warner', 'Australia', 37, 'Batter', 'Left-hand bat', 'Right-arm legbreak', 20000000.00, 'AVAILABLE', 176, 6397, 0),
(26, 'Jos Buttler', 'England', 33, 'Wicketkeeper', 'Right-hand bat', 'None', 20000000.00, 'AVAILABLE', 96, 3223, 0),
(27, 'Sam Curran', 'England', 25, 'All-rounder', 'Left-hand bat', 'Left-arm medium-fast', 20000000.00, 'AVAILABLE', 46, 613, 42),
(28, 'Liam Livingstone', 'England', 30, 'All-rounder', 'Right-hand bat', 'Right-arm legbreak / offbreak', 15000000.00, 'AVAILABLE', 32, 828, 11),
(29, 'Phil Salt', 'England', 27, 'Wicketkeeper', 'Right-hand bat', 'None', 15000000.00, 'AVAILABLE', 21, 653, 0),
(30, 'Heinrich Klaasen', 'South Africa', 32, 'Wicketkeeper', 'Right-hand bat', 'Right-arm offbreak', 20000000.00, 'AVAILABLE', 35, 893, 0),
(31, 'Kagiso Rabada', 'South Africa', 28, 'Bowler', 'Left-hand bat', 'Right-arm fast', 20000000.00, 'AVAILABLE', 69, 186, 106),
(32, 'Quinton de Kock', 'South Africa', 31, 'Wicketkeeper', 'Left-hand bat', 'None', 20000000.00, 'AVAILABLE', 96, 2907, 0),
(33, 'Anrich Nortje', 'South Africa', 30, 'Bowler', 'Right-hand bat', 'Right-arm fast', 15000000.00, 'AVAILABLE', 40, 24, 53),
(34, 'Trent Boult', 'New Zealand', 34, 'Bowler', 'Right-hand bat', 'Left-arm fast-medium', 20000000.00, 'AVAILABLE', 88, 13, 105),
(35, 'Kane Williamson', 'New Zealand', 33, 'Batter', 'Right-hand bat', 'Right-arm offbreak', 20000000.00, 'AVAILABLE', 77, 2101, 0),
(36, 'Devon Conway', 'New Zealand', 32, 'Batter', 'Left-hand bat', 'Right-arm medium', 15000000.00, 'AVAILABLE', 23, 924, 0),
(37, 'Rashid Khan', 'Afghanistan', 25, 'Bowler', 'Right-hand bat', 'Right-arm legbreak', 20000000.00, 'AVAILABLE', 109, 443, 139),
(38, 'Nicholas Pooran', 'West Indies', 28, 'Wicketkeeper', 'Left-hand bat', 'Right-arm offbreak', 20000000.00, 'AVAILABLE', 62, 1270, 0),
(39, 'Shimron Hetmyer', 'West Indies', 27, 'Batter', 'Left-hand bat', 'None', 15000000.00, 'AVAILABLE', 60, 1131, 0),
(40, 'Rinku Singh', 'India', 26, 'Batter', 'Left-hand bat', 'Right-arm offbreak', 10000000.00, 'AVAILABLE', 31, 725, 0),
(41, 'Yashasvi Jaiswal', 'India', 22, 'Batter', 'Left-hand bat', 'Right-arm legbreak', 20000000.00, 'AVAILABLE', 37, 1172, 0),
(42, 'Shivam Dube', 'India', 30, 'All-rounder', 'Left-hand bat', 'Right-arm medium', 15000000.00, 'AVAILABLE', 51, 1106, 4),
(43, 'Arshdeep Singh', 'India', 25, 'Bowler', 'Left-hand bat', 'Left-arm medium-fast', 15000000.00, 'AVAILABLE', 51, 25, 57),
(44, 'Ishan Kishan', 'India', 25, 'Wicketkeeper', 'Left-hand bat', 'None', 20000000.00, 'AVAILABLE', 91, 2324, 0),
(45, 'Venkatesh Iyer', 'India', 29, 'All-rounder', 'Left-hand bat', 'Right-arm medium', 15000000.00, 'AVAILABLE', 36, 956, 3),
(46, 'Harshal Patel', 'India', 33, 'Bowler', 'Right-hand bat', 'Right-arm medium-fast', 10000000.00, 'AVAILABLE', 91, 230, 111),
(47, 'Rahul Tewatia', 'India', 30, 'All-rounder', 'Left-hand bat', 'Right-arm legbreak', 10000000.00, 'AVAILABLE', 81, 825, 32),
(48, 'Umran Malik', 'India', 24, 'Bowler', 'Right-hand bat', 'Right-arm fast', 5000000.00, 'AVAILABLE', 25, 11, 29);

-- ---------------------------------------------------------------------
-- 5. HISTORICAL AUCTIONS & PURCHASES (Reconciles exactly with initial budgets)
-- ---------------------------------------------------------------------
-- Auction 1: Ruturaj Gaikwad -> CSK for ₹12.00 Cr
INSERT INTO auctions (id, player_id, current_bid, highest_bid_team_id, status, started_at, closed_at, created_by)
VALUES (1, 1, 120000000.00, 1, 'SOLD', NOW() - INTERVAL 2 HOUR, NOW() - INTERVAL 1 HOUR, 1);

INSERT INTO bids (auction_id, team_id, bid_amount, bid_status, created_at) VALUES
(1, 1, 20000000.00, 'OUTBID', NOW() - INTERVAL 115 MINUTE),
(1, 3, 40000000.00, 'OUTBID', NOW() - INTERVAL 110 MINUTE),
(1, 1, 80000000.00, 'OUTBID', NOW() - INTERVAL 105 MINUTE),
(1, 3, 100000000.00, 'OUTBID', NOW() - INTERVAL 100 MINUTE),
(1, 1, 120000000.00, 'WINNING', NOW() - INTERVAL 95 MINUTE);

INSERT INTO purchases (id, auction_id, player_id, team_id, final_price, purchased_at)
VALUES (1, 1, 1, 1, 120000000.00, NOW() - INTERVAL 90 MINUTE);

-- Auction 2: Jasprit Bumrah -> MI for ₹15.00 Cr
INSERT INTO auctions (id, player_id, current_bid, highest_bid_team_id, status, started_at, closed_at, created_by)
VALUES (2, 2, 150000000.00, 2, 'SOLD', NOW() - INTERVAL 90 MINUTE, NOW() - INTERVAL 60 MINUTE, 1);

INSERT INTO bids (auction_id, team_id, bid_amount, bid_status, created_at) VALUES
(2, 2, 50000000.00, 'OUTBID', NOW() - INTERVAL 85 MINUTE),
(2, 4, 100000000.00, 'OUTBID', NOW() - INTERVAL 80 MINUTE),
(2, 2, 150000000.00, 'WINNING', NOW() - INTERVAL 75 MINUTE);

INSERT INTO purchases (id, auction_id, player_id, team_id, final_price, purchased_at)
VALUES (2, 2, 2, 2, 150000000.00, NOW() - INTERVAL 70 MINUTE);

-- Auction 3: Virat Kohli -> RCB for ₹11.50 Cr
INSERT INTO auctions (id, player_id, current_bid, highest_bid_team_id, status, started_at, closed_at, created_by)
VALUES (3, 3, 115000000.00, 3, 'SOLD', NOW() - INTERVAL 60 MINUTE, NOW() - INTERVAL 40 MINUTE, 1);

INSERT INTO bids (auction_id, team_id, bid_amount, bid_status, created_at) VALUES
(3, 3, 50000000.00, 'OUTBID', NOW() - INTERVAL 55 MINUTE),
(3, 1, 80000000.00, 'OUTBID', NOW() - INTERVAL 50 MINUTE),
(3, 3, 115000000.00, 'WINNING', NOW() - INTERVAL 45 MINUTE);

INSERT INTO purchases (id, auction_id, player_id, team_id, final_price, purchased_at)
VALUES (3, 3, 3, 3, 115000000.00, NOW() - INTERVAL 40 MINUTE);

-- Auction 4: Andre Russell -> KKR for ₹8.00 Cr
INSERT INTO auctions (id, player_id, current_bid, highest_bid_team_id, status, started_at, closed_at, created_by)
VALUES (4, 4, 80000000.00, 4, 'SOLD', NOW() - INTERVAL 40 MINUTE, NOW() - INTERVAL 20 MINUTE, 1);

INSERT INTO bids (auction_id, team_id, bid_amount, bid_status, created_at) VALUES
(4, 4, 50000000.00, 'OUTBID', NOW() - INTERVAL 35 MINUTE),
(4, 2, 70000000.00, 'OUTBID', NOW() - INTERVAL 30 MINUTE),
(4, 4, 80000000.00, 'WINNING', NOW() - INTERVAL 25 MINUTE);

INSERT INTO purchases (id, auction_id, player_id, team_id, final_price, purchased_at)
VALUES (4, 4, 4, 4, 80000000.00, NOW() - INTERVAL 20 MINUTE);

-- Auction 5: Steve Smith -> UNSOLD
INSERT INTO auctions (id, player_id, current_bid, highest_bid_team_id, status, started_at, closed_at, created_by)
VALUES (5, 5, 0.00, NULL, 'UNSOLD', NOW() - INTERVAL 20 MINUTE, NOW() - INTERVAL 10 MINUTE, 1);

-- Auction 6: ACTIVE AUCTION (Rohit Sharma - Ready for live bidding)
INSERT INTO auctions (id, player_id, current_bid, highest_bid_team_id, status, started_at, closed_at, created_by)
VALUES (6, 6, 20000000.00, 2, 'OPEN', NOW() - INTERVAL 5 MINUTE, NULL, 1);

INSERT INTO bids (auction_id, team_id, bid_amount, bid_status, created_at) VALUES
(6, 2, 20000000.00, 'WINNING', NOW() - INTERVAL 2 MINUTE);

-- ---------------------------------------------------------------------
-- 6. AUDIT LOGS
-- ---------------------------------------------------------------------
INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details) VALUES
(1, 'DATABASE_SEED', 'SYSTEM', 1, '{"message": "Initial database seed populated successfully"}'),
(1, 'PLAYER_SOLD', 'PLAYER', 1, '{"player": "Ruturaj Gaikwad", "team": "CSK", "price": 120000000.00}'),
(1, 'PLAYER_SOLD', 'PLAYER', 2, '{"player": "Jasprit Bumrah", "team": "MI", "price": 150000000.00}'),
(1, 'PLAYER_SOLD', 'PLAYER', 3, '{"player": "Virat Kohli", "team": "RCB", "price": 115000000.00}'),
(1, 'PLAYER_SOLD', 'PLAYER', 4, '{"player": "Andre Russell", "team": "KKR", "price": 80000000.00}'),
(1, 'PLAYER_UNSOLD', 'PLAYER', 5, '{"player": "Steve Smith", "reason": "No bids placed"}'),
(1, 'AUCTION_OPENED', 'AUCTION', 6, '{"player": "Rohit Sharma", "opening_bid": 20000000.00}');
