# Cricket Auction Management System — REST API Specification

All API endpoints are mounted under the base prefix `/api`. JSON responses adhere to the standard format:
```json
{
  "success": true,
  "data": { ... },
  "message": "Optional human-readable confirmation message"
}
```
In case of errors:
```json
{
  "success": false,
  "error": "Detailed descriptive error message"
}
```

---

## 1. Authentication Endpoints

### 1.1 `POST /api/auth/login`
- **Access**: Public
- **Request Body**:
  ```json
  {
    "username": "admin",
    "password": "Admin@123"
  }
  ```
- **Response `200 OK`**:
  ```json
  {
    "success": true,
    "data": {
      "token": "eyJhbGciOi...",
      "user": {
        "id": 1,
        "username": "admin",
        "role": "ADMIN",
        "team_id": null
      }
    },
    "message": "Login successful"
  }
  ```

### 1.2 `POST /api/auth/logout`
- **Access**: Authenticated (`Bearer <token>`)
- **Response `200 OK`**: Logs user out and records session termination.

### 1.3 `GET /api/auth/me`
- **Access**: Authenticated (`Bearer <token>`)
- **Response `200 OK`**: Returns authenticated user profile, franchise affiliation, and current purse balance.

---

## 2. Dashboard Endpoints

### 2.1 `GET /api/dashboard/stats`
- **Access**: Public / Authenticated
- **Description**: Returns live SQL aggregates for total teams, total registered players, sold count, unsold count, remaining pool, total spending, current active auction, and franchise purse overview.

### 2.2 `GET /api/dashboard/activity`
- **Access**: Public / Authenticated
- **Query Params**: `limit` (default: 15)
- **Description**: Returns live stream of recent auction audit logs and transactions.

---

## 3. Team Management Endpoints

### 3.1 `GET /api/teams`
- **Access**: Public / Authenticated
- **Description**: Returns list of all franchises with `initial_purse`, `remaining_purse`, `total_spent`, and `squad_count`.

### 3.2 `GET /api/teams/:id`
- **Access**: Public / Authenticated
- **Description**: Returns detailed single team record.

### 3.3 `GET /api/teams/:id/squad`
- **Access**: Public / Authenticated
- **Description**: Returns official squad list of players purchased by this team.

### 3.4 `GET /api/teams/:id/summary`
- **Access**: Public / Authenticated
- **Description**: Returns spending summary, role distribution, and budget breakdown.

### 3.5 `POST /api/teams`
- **Access**: Admin Only
- **Request Body**:
  ```json
  {
    "team_name": "Lucknow Super Giants",
    "team_code": "LSG",
    "logo_url": "https://...",
    "initial_purse": 1000000000
  }
  ```

### 3.6 `PUT /api/teams/:id`
- **Access**: Admin Only
- **Request Body**: Editable team fields.

### 3.7 `DELETE /api/teams/:id`
- **Access**: Admin Only
- **Description**: Deletes team if no linked users, bids, or purchases exist; returns `400` if dependencies exist.

---

## 4. Player Management Endpoints

### 4.1 `GET /api/players`
- **Access**: Public / Authenticated
- **Query Params**:
  - `page` (default: 1)
  - `limit` (default: 12)
  - `search` (name substring)
  - `role` (`Batter`, `Bowler`, `All-rounder`, `Wicketkeeper`)
  - `status` (`AVAILABLE`, `IN_AUCTION`, `SOLD`, `UNSOLD`)
  - `nationality`
  - `sort` (`player_name`, `base_price`, `created_at`)
  - `order` (`ASC`, `DESC`)
- **Response**: Paginated player list and metadata.

### 4.2 `GET /api/players/:id`
- **Access**: Public / Authenticated
- **Description**: Returns full player profile including career matches, runs, wickets, and styles.

### 4.3 `POST /api/players`
- **Access**: Admin Only
- **Request Body**:
  ```json
  {
    "player_name": "Rinku Singh",
    "nationality": "India",
    "age": 26,
    "role": "Batter",
    "batting_style": "Left-hand bat",
    "bowling_style": "Right-arm offbreak",
    "base_price": 10000000,
    "image_url": "https://...",
    "matches_played": 31,
    "runs_scored": 725,
    "wickets_taken": 0
  }
  ```

### 4.4 `PUT /api/players/:id`
- **Access**: Admin Only
- **Description**: Updates player details. Note: If player status is `SOLD`, status cannot be reset without an explicit audit procedure.

### 4.5 `DELETE /api/players/:id`
- **Access**: Admin Only
- **Description**: Safe deletion guarded by relational integrity.

---

## 5. Auction Control & Bidding Endpoints

### 5.1 `GET /api/auctions/current`
- **Access**: Public / Authenticated
- **Description**: Returns the currently active auction (`OPEN`, `PAUSED`, `READY`, or `DRAFT`) along with current bids and settings.

### 5.2 `GET /api/auctions`
- **Access**: Public / Authenticated
- **Description**: Returns all historical and active auctions.

### 5.3 `GET /api/auctions/:id`
- **Access**: Public / Authenticated
- **Description**: Returns specific auction details.

### 5.4 `GET /api/auctions/:id/bids`
- **Access**: Public / Authenticated
- **Description**: Returns bids submitted for a specific auction.

### 5.5 `GET /api/auctions/bids/history`
- **Access**: Public / Authenticated
- **Query Params**: `team_id`, `auction_id`, `limit` (default: 100)
- **Description**: Returns chronological audit list of all bids.

### 5.6 `POST /api/auctions`
- **Access**: Admin Only
- **Request Body**: `{ "player_id": 6 }`
- **Description**: Staged an available player for auction.

### 5.7 `POST /api/auctions/:id/start`
- **Access**: Admin Only
- **Description**: Starts auction, transitions status to `OPEN`, sets player status to `IN_AUCTION`.

### 5.8 `POST /api/auctions/:id/pause`
- **Access**: Admin Only
- **Description**: Transitions status from `OPEN` to `PAUSED`.

### 5.9 `POST /api/auctions/:id/resume`
- **Access**: Admin Only
- **Description**: Transitions status from `PAUSED` to `OPEN`.

### 5.10 `POST /api/auctions/:id/close`
- **Access**: Admin Only
- **Description**: Closes bidding in preparation for the final gavel fall.

### 5.11 `POST /api/auctions/:id/sell`
- **Access**: Admin Only
- **Description**: **Atomic transaction**:
  1. Identifies highest valid bid from DB.
  2. Verifies winning team has sufficient remaining purse.
  3. Verifies no duplicate purchase exists.
  4. Inserts record into `purchases`.
  5. Deducts final price from winning team's purse.
  6. Updates player status to `SOLD`.
  7. Updates auction status to `SOLD`.
  8. Emits `auction:player_sold` WebSocket event.

### 5.12 `POST /api/auctions/:id/unsold`
- **Access**: Admin Only
- **Description**: Marks auction and player as `UNSOLD`.

### 5.13 `POST /api/auctions/:id/bids`
- **Access**: Team User (assigned team) or Admin
- **Request Body**:
  ```json
  {
    "team_id": 1,
    "bid_amount": 22000000
  }
  ```
- **Validation**:
  - Auction must be `OPEN`.
  - Amount must be $\ge$ base price (if opening bid) or current bid + increment.
  - Team purse must cover proposed bid.
  - Team must not exceed maximum squad limit.
  - Team user cannot bid on behalf of another franchise.
  - Team cannot outbid itself unless configured in settings.

---

## 6. Purchase Ledger & Reports Endpoints

### 6.1 `GET /api/purchases`
- **Query Params**: `team_id`, `role`
- **Description**: Returns all completed purchases.

### 6.2 `GET /api/reports/overview`
- **Description**: Overall financial summary (total spend, average price, top player, top spending franchise).

### 6.3 `GET /api/reports/team-spending`
- **Description**: Aggregate spending per franchise.

### 6.4 `GET /api/reports/sold-players`
- **Description**: All sold players with winning team and price.

### 6.5 `GET /api/reports/unsold-players`
- **Description**: All unsold players with base price.

### 6.6 `GET /api/reports/role-breakdown`
- **Description**: Expenditure and player counts grouped by role.

---

## 7. Auction Settings Endpoints

### 7.1 `GET /api/settings`
- **Access**: Public / Authenticated
- **Description**: Returns current increment, squad limit, and rule configs.

### 7.2 `PUT /api/settings`
- **Access**: Admin Only
- **Request Body**:
  ```json
  {
    "minimum_bid_increment": 2000000,
    "maximum_squad_size": 25,
    "min_batters": 4,
    "min_bowlers": 4,
    "min_allrounders": 2,
    "min_wicketkeepers": 1,
    "allow_self_outbid": false
  }
  ```

---

## 8. Real-time WebSocket Events (Socket.IO)

- `connect`: Emitted on client connection.
- `auction:bid_placed`: Broadcast when a valid bid is committed.
- `auction:status_changed`: Broadcast when auction status transitions (`OPEN`, `PAUSED`, `CLOSED`).
- `auction:player_sold`: Broadcast when a player is sold (triggers victory confetti).
- `auction:player_unsold`: Broadcast when marked unsold.
- `auction:created`: Broadcast when a new player is brought to the block.
