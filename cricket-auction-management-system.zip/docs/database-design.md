# Cricket Auction Management System — Database Architecture & Design

## 1. Executive Summary & Design Rationale

The **Cricket Auction Management System** utilizes **MySQL 8.0+** with the **InnoDB** storage engine. InnoDB was chosen for its full ACID transaction support, row-level pessimistic locking (`SELECT ... FOR UPDATE`), and foreign key constraint enforcement.

### Key Architectural Pillars:
1. **Financial Exactness**: All currency fields (`initial_purse`, `remaining_purse`, `base_price`, `current_bid`, `bid_amount`, `final_price`) are stored in exact `DECIMAL(14, 2)` format. Floating-point numbers (`FLOAT` or `DOUBLE`) are strictly disallowed to prevent rounding errors during multi-crore bid increments and purse deductions.
2. **Pessimistic Concurrency Control**: During high-intensity auction bidding and player hammer closing, row-level locks prevent conflicting bids and duplicate sales.
3. **Double-Sale Prevention**: The `purchases` table enforces a `UNIQUE(player_id)` constraint, making it impossible at both the application and database engine levels to sell the same player more than once.
4. **Historical Immutability & Audit Trail**: Deleting teams or players with active bids/purchases is blocked using `ON DELETE RESTRICT`. All high-stakes actions (bids, sales, state transitions) are recorded in `audit_logs`.

---

## 2. Entity Relationship Diagram (ERD)

```mermaid
erDiagram
    TEAMS ||--o{ USERS : "has representatives"
    TEAMS ||--o{ BIDS : "places"
    TEAMS ||--o{ PURCHASES : "owns acquired players"
    TEAMS ||--o{ AUCTIONS : "leads current bid"
    PLAYERS ||--o{ AUCTIONS : "auctioned in"
    PLAYERS ||--o| PURCHASES : "acquired via"
    AUCTIONS ||--o{ BIDS : "receives"
    AUCTIONS ||--o| PURCHASES : "settled into"
    USERS ||--o{ AUCTIONS : "created by"
    USERS ||--o{ AUDIT_LOGS : "performed by"

    TEAMS {
        int id PK
        varchar team_name
        varchar team_code UK
        varchar logo_url
        decimal initial_purse
        decimal remaining_purse
        timestamp created_at
        timestamp updated_at
    }

    USERS {
        int id PK
        varchar username UK
        varchar password_hash
        enum role "ADMIN, TEAM_USER"
        int team_id FK
        timestamp created_at
    }

    PLAYERS {
        int id PK
        varchar player_name
        varchar image_url
        varchar nationality
        int age
        enum role "Batter, Bowler, All-rounder, Wicketkeeper"
        varchar batting_style
        varchar bowling_style
        decimal base_price
        enum status "AVAILABLE, IN_AUCTION, SOLD, UNSOLD"
        int matches_played
        int runs_scored
        int wickets_taken
        timestamp created_at
        timestamp updated_at
    }

    AUCTIONS {
        int id PK
        int player_id FK
        decimal current_bid
        int highest_bid_team_id FK
        enum status "DRAFT, READY, OPEN, PAUSED, CLOSED, SOLD, UNSOLD"
        timestamp started_at
        timestamp closed_at
        int created_by FK
        timestamp created_at
        timestamp updated_at
    }

    BIDS {
        int id PK
        int auction_id FK
        int team_id FK
        decimal bid_amount
        enum bid_status "VALID, OUTBID, WINNING, REJECTED"
        timestamp created_at
    }

    PURCHASES {
        int id PK
        int auction_id FK
        int player_id FK, UK
        int team_id FK
        decimal final_price
        timestamp purchased_at
    }

    AUCTION_SETTINGS {
        int id PK
        decimal minimum_bid_increment
        int maximum_squad_size
        int min_batters
        int min_bowlers
        int min_allrounders
        int min_wicketkeepers
        boolean allow_self_outbid
        timestamp updated_at
    }

    AUDIT_LOGS {
        int id PK
        int user_id FK
        varchar action
        varchar entity_type
        int entity_id
        json details
        timestamp created_at
    }
```

---

## 3. Relational Table Specifications

### 3.1. `teams`
Stores franchise identities, initial purse allocations (default ₹100.00 Cr), and remaining purse balances.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `team_name`: VARCHAR(100) NOT NULL
- `team_code`: VARCHAR(10) NOT NULL UNIQUE (e.g. `CSK`, `MI`, `RCB`)
- `logo_url`: VARCHAR(500) NULL
- `initial_purse`: DECIMAL(14, 2) NOT NULL DEFAULT 1000000000.00 (`CHECK (initial_purse >= 0)`)
- `remaining_purse`: DECIMAL(14, 2) NOT NULL DEFAULT 1000000000.00 (`CHECK (remaining_purse >= 0)`)
- `created_at`, `updated_at`: TIMESTAMP

### 3.2. `users`
Authentication credentials and role assignments.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `username`: VARCHAR(50) NOT NULL UNIQUE
- `password_hash`: VARCHAR(255) NOT NULL (Bcrypt hashed)
- `role`: ENUM('ADMIN', 'TEAM_USER') NOT NULL DEFAULT 'TEAM_USER'
- `team_id`: INT NULL (Foreign Key to `teams(id) ON DELETE SET NULL`)
- `created_at`: TIMESTAMP

### 3.3. `players`
Player registry including physical attributes, playing styles, base price, and career stats.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `player_name`: VARCHAR(100) NOT NULL
- `image_url`: VARCHAR(500) NULL
- `nationality`: VARCHAR(50) NOT NULL
- `age`: INT NULL (`CHECK (age IS NULL OR age > 0)`)
- `role`: ENUM('Batter', 'Bowler', 'All-rounder', 'Wicketkeeper') NOT NULL
- `batting_style`: VARCHAR(50) NULL
- `bowling_style`: VARCHAR(50) NULL
- `base_price`: DECIMAL(14, 2) NOT NULL (`CHECK (base_price >= 0)`)
- `status`: ENUM('AVAILABLE', 'IN_AUCTION', 'SOLD', 'UNSOLD') NOT NULL DEFAULT 'AVAILABLE'
- `matches_played`: INT DEFAULT 0
- `runs_scored`: INT DEFAULT 0
- `wickets_taken`: INT DEFAULT 0
- `created_at`, `updated_at`: TIMESTAMP

### 3.4. `auctions`
Stateful auction rounds for individual players.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `player_id`: INT NOT NULL (FK to `players(id) ON DELETE RESTRICT`)
- `current_bid`: DECIMAL(14, 2) NOT NULL DEFAULT 0.00
- `highest_bid_team_id`: INT NULL (FK to `teams(id) ON DELETE SET NULL`)
- `status`: ENUM('DRAFT', 'READY', 'OPEN', 'PAUSED', 'CLOSED', 'SOLD', 'UNSOLD') NOT NULL DEFAULT 'DRAFT'
- `started_at`: TIMESTAMP NULL
- `closed_at`: TIMESTAMP NULL
- `created_by`: INT NOT NULL (FK to `users(id) ON DELETE RESTRICT`)
- `created_at`, `updated_at`: TIMESTAMP

### 3.5. `bids`
Immutable record of all bids submitted.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `auction_id`: INT NOT NULL (FK to `auctions(id) ON DELETE CASCADE`)
- `team_id`: INT NOT NULL (FK to `teams(id) ON DELETE RESTRICT`)
- `bid_amount`: DECIMAL(14, 2) NOT NULL (`CHECK (bid_amount > 0)`)
- `bid_status`: ENUM('VALID', 'OUTBID', 'WINNING', 'REJECTED') NOT NULL DEFAULT 'VALID'
- `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

### 3.6. `purchases`
Official immutable purchase ledger connecting players to their winning team.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `auction_id`: INT NOT NULL (FK to `auctions(id) ON DELETE RESTRICT`)
- `player_id`: INT NOT NULL UNIQUE (FK to `players(id) ON DELETE RESTRICT`)
- `team_id`: INT NOT NULL (FK to `teams(id) ON DELETE RESTRICT`)
- `final_price`: DECIMAL(14, 2) NOT NULL (`CHECK (final_price > 0)`)
- `purchased_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

### 3.7. `auction_settings`
Global rule parameters for increments and squad ceilings.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `minimum_bid_increment`: DECIMAL(14, 2) NOT NULL DEFAULT 2000000.00 (₹20 Lakh)
- `maximum_squad_size`: INT NOT NULL DEFAULT 25
- `min_batters`: INT NOT NULL DEFAULT 4
- `min_bowlers`: INT NOT NULL DEFAULT 4
- `min_allrounders`: INT NOT NULL DEFAULT 2
- `min_wicketkeepers`: INT NOT NULL DEFAULT 1
- `allow_self_outbid`: BOOLEAN NOT NULL DEFAULT FALSE
- `updated_at`: TIMESTAMP

### 3.8. `audit_logs`
Chronological traceability log for compliance and college evaluation.
- `id`: INT AUTO_INCREMENT PRIMARY KEY
- `user_id`: INT NULL (FK to `users(id) ON DELETE SET NULL`)
- `action`: VARCHAR(100) NOT NULL
- `entity_type`: VARCHAR(50) NOT NULL
- `entity_id`: INT NULL
- `details`: JSON NULL
- `created_at`: TIMESTAMP DEFAULT CURRENT_TIMESTAMP

---

## 4. Auction State Transitions

```mermaid
stateDiagram-v2
    [*] --> DRAFT : Admin creates auction
    DRAFT --> READY : Player staged
    READY --> OPEN : Admin clicks "Start / Open Bidding"
    OPEN --> PAUSED : Admin clicks "Pause Bidding"
    PAUSED --> OPEN : Admin clicks "Resume Bidding"
    OPEN --> CLOSED : Admin closes bidding
    CLOSED --> OPEN : Admin reopens bidding
    CLOSED --> SOLD : Admin confirms "Sell to Highest Bidder"
    CLOSED --> UNSOLD : Admin marks "Unsold (No valid bids)"
    OPEN --> SOLD : Direct Hammer Fall (with winning bid)
    OPEN --> UNSOLD : Direct Hammer Fall (no bids)
    SOLD --> [*] : Player squad updated, purse deducted
    UNSOLD --> [*] : Player returns to pool
```

---

## 5. Concurrency & Transaction Settlement

### Atomic Sale Workflow (`sellPlayer`):
1. **Acquire pessimistic locks**:
   `SELECT * FROM auctions WHERE id = ? FOR UPDATE;`
   `SELECT * FROM players WHERE id = ? FOR UPDATE;`
   `SELECT * FROM teams WHERE id = ? FOR UPDATE;`
2. **Validate invariants**:
   - Auction status must not already be `SOLD` or `UNSOLD`.
   - Player status must not be `SOLD`.
   - `purchases` record for `player_id` must not exist.
   - `team.remaining_purse >= final_price`.
3. **Execute ledger insertions**:
   - `INSERT INTO purchases (auction_id, player_id, team_id, final_price, purchased_at) VALUES (...);`
   - `UPDATE teams SET remaining_purse = remaining_purse - ? WHERE id = ?;`
   - `UPDATE players SET status = 'SOLD' WHERE id = ?;`
   - `UPDATE auctions SET status = 'SOLD', closed_at = NOW() WHERE id = ?;`
   - `UPDATE bids SET bid_status = 'WINNING' WHERE ...;`
   - `INSERT INTO audit_logs (...) VALUES (...);`
4. **Commit transaction** or **Rollback** on any exception.
5. **Broadcast WebSocket event** `auction:player_sold` to all connected clients.
